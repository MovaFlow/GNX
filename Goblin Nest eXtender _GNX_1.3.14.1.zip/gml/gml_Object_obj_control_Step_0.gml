// GNX multi-map: deferred load trigger. scr_gnx_travel sets gnx_trigger_load = true
// on the travel frame. We fire the compiled state machine HERE (next frame) so
// the button click handler that called scr_gnx_travel has fully returned and
// no same-frame Step events run on half-destroyed state.
if (global.gnx_multimap_enabled && variable_global_exists("gnx_trigger_load") && global.gnx_trigger_load)
{
    global.gnx_trigger_load = false;
    global.click_lock = true;

    // Destroy ALL gameplay instances before reinit
    with (obj_slot) instance_destroy();
    with (obj_mon) instance_destroy();
    with (obj_button) instance_destroy();
    with (obj_window) instance_destroy();
    if (instance_exists(obj_empty)) { with (obj_empty) instance_destroy(); }
    if (instance_exists(obj_pop_up)) { with (obj_pop_up) instance_destroy(); }

    // KEY FIX: the compiled state machine (load_state=6) does NOT call
    // scr_create_initials from gameplay context. It expects it to have run
    // at game start. Without this, global.slot_list holds stale destroyed
    // instance IDs and scr_create_slot crashes.
    // gnx_travel_data is protected by a guard inside scr_create_initials.
    scr_create_initials();

    // For snapshot restore: force Load Game path so compiled code calls
    // scr_load_slot (our _gnx_travel bypass consumes the snapshot).
    // For fresh map: load_file stays -1 (set by scr_create_initials),
    // so compiled code takes New Game path and creates entrance slots.
    if (variable_global_exists("gnx_travel_data") && global.gnx_travel_data != -1)
        global.load_file = 0;

    obj_np.load_state = 6; // UnknownEnum.Value_6
    exit;
}

scr_mouse_control();

// GNX-PERF: log draw stats every 120 frames (~2s) when enabled
if (global.gnx_perf_enabled)
{
    global.gnx_perf_frame++;
    if (global.gnx_perf_frame >= 120)
    {
        var _sd = global.gnx_perf_slots_drawn;
        var _sc = global.gnx_perf_slots_culled;
        var _md = global.gnx_perf_mons_drawn;
        var _mc = global.gnx_perf_mons_culled;
        var _pct = (_sd + _sc > 0) ? string(round((_sc / (_sd + _sc)) * 100)) : "0";
        var _f = file_text_open_append(GNX_LOG);
        file_text_write_string(_f, "[GNX-PERF] slots=" + string(_sd) + "/" + string(_sd + _sc)
            + " culled=" + _pct + "% mons=" + string(_md) + "/" + string(_md + _mc)
            + " fps=" + string(fps) + " fps_real=" + string(fps_real));
        file_text_writeln(_f);
        file_text_close(_f);
        global.gnx_perf_slots_drawn = 0;
        global.gnx_perf_slots_culled = 0;
        global.gnx_perf_mons_drawn = 0;
        global.gnx_perf_mons_culled = 0;
        global.gnx_perf_frame = 0;
    }
}

// GNX: per-frame quest completion check
scr_gnx_check_quest_completion("frame");

// GNX: tool system per-frame hooks (gated by gnx_has_tools inside each function)
scr_gnx_check_keybinds();
scr_gnx_apply_continuous_effects();

