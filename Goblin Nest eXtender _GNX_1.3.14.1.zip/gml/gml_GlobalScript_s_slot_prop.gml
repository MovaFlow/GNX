function scr_create_prop(arg0, arg1, arg2, arg3)
{
    var _exists = false;
    
    with (arg0)
    {
        var _prop;
        
        switch (arg1)
        {
            case UnknownEnum.Value_40:
                _prop = instance_create_depth(x, y, depth - 1, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = UnknownEnum.Value_40;
                    prop_data.prop_step = arg3;
                    prop_data.spawn = false;
                    prop_data.mon_data = arg2;
                    slot_id = other.id;
                    activate = true;
                    follow = true;
                    center = false;
                    hover = false;
                    scr_prop_draw = scr_draw_prop_infant;
                    
                    switch (arg0.slot_data.h_type)
                    {
                        case UnknownEnum.Value_5:
                            switch (prop_data.mon_data.mon_type)
                            {
                                case UnknownEnum.Value_0:
                                    sprite_index = spr_h_goblin_v_birth;
                                    
                                    if (arg0.unit_data != -1)
                                    {
                                        switch (arg0.unit_data.class)
                                        {
                                            case UnknownEnum.Value_10:
                                                sprite_index = spr_h_goblin_nyx_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_8:
                                                sprite_index = spr_h_goblin_lilith_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_13:
                                                sprite_index = spr_h_goblin_cat_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_12:
                                                sprite_index = spr_h_goblin_morrigan_v_birth;
                                                break;
                                        }
                                    }
                                    
                                    break;
                                
                                case UnknownEnum.Value_1:
                                    sprite_index = spr_h_hobgoblin_v_birth;
                                    
                                    if (arg0.unit_data != -1)
                                    {
                                        switch (arg0.unit_data.class)
                                        {
                                            case UnknownEnum.Value_10:
                                                sprite_index = spr_h_hobgoblin_nyx_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_8:
                                                sprite_index = spr_h_hobgoblin_lilith_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_13:
                                                sprite_index = spr_h_hobgoblin_cat_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_12:
                                                sprite_index = spr_h_hobgoblin_morrigan_v_birth;
                                                break;
                                        }
                                    }
                                    
                                    break;
                                
                                case UnknownEnum.Value_2:
                                    sprite_index = spr_h_tent_v_birth;
                                    
                                    if (arg0.unit_data != -1)
                                    {
                                        switch (arg0.unit_data.class)
                                        {
                                            case UnknownEnum.Value_10:
                                                sprite_index = spr_h_tent_nyx_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_8:
                                                sprite_index = spr_h_tent_lilith_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_13:
                                                sprite_index = spr_h_tent_cat_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_12:
                                                sprite_index = spr_h_tent_morrigan_v_birth;
                                                break;
                                        }
                                    }
                                    
                                    break;
                                
                                case UnknownEnum.Value_3:
                                    sprite_index = spr_h_ogre_v_birth;
                                    
                                    if (arg0.unit_data != -1)
                                    {
                                        switch (arg0.unit_data.class)
                                        {
                                            case UnknownEnum.Value_10:
                                                sprite_index = spr_h_ogre_nyx_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_8:
                                                sprite_index = spr_h_ogre_lilith_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_13:
                                                sprite_index = spr_h_ogre_cat_v_birth;
                                                break;
                                            
                                            case UnknownEnum.Value_12:
                                                sprite_index = spr_h_ogre_morrigan_v_birth;
                                                break;
                                        }
                                    }
                                    
                                    break;
                            }
                            
                            break;
                        
                        case UnknownEnum.Value_12:
                            switch (prop_data.mon_data.mon_type)
                            {
                                case UnknownEnum.Value_0:
                                    sprite_index = spr_h_goblin_v_birth_2;
                                    
                                    switch (arg0.unit_data.class)
                                    {
                                        case UnknownEnum.Value_10:
                                            sprite_index = spr_h_goblin_nyx_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_8:
                                            sprite_index = spr_h_goblin_lilith_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_13:
                                            sprite_index = spr_h_goblin_cat_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_12:
                                            sprite_index = spr_h_goblin_morrigan_v_birth_2;
                                            break;
                                    }
                                    
                                    break;
                                
                                case UnknownEnum.Value_1:
                                    sprite_index = spr_h_hobgoblin_v_birth_2;
                                    
                                    switch (arg0.unit_data.class)
                                    {
                                        case UnknownEnum.Value_10:
                                            sprite_index = spr_h_hobgoblin_nyx_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_8:
                                            sprite_index = spr_h_hobgoblin_lilith_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_13:
                                            sprite_index = spr_h_hobgoblin_cat_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_12:
                                            sprite_index = spr_h_hobgoblin_morrigan_v_birth_2;
                                            break;
                                    }
                                    
                                    break;
                                
                                case UnknownEnum.Value_2:
                                    sprite_index = spr_h_tent_v_birth_2;
                                    
                                    switch (arg0.unit_data.class)
                                    {
                                        case UnknownEnum.Value_10:
                                            sprite_index = spr_h_tent_nyx_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_8:
                                            sprite_index = spr_h_tent_lilith_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_13:
                                            sprite_index = spr_h_tent_cat_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_12:
                                            sprite_index = spr_h_tent_morrigan_v_birth_2;
                                            break;
                                    }
                                    
                                    break;
                                
                                case UnknownEnum.Value_3:
                                    sprite_index = spr_h_ogre_v_birth_2;
                                    
                                    switch (arg0.unit_data.class)
                                    {
                                        case UnknownEnum.Value_10:
                                            sprite_index = spr_h_ogre_nyx_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_8:
                                            sprite_index = spr_h_ogre_lilith_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_13:
                                            sprite_index = spr_h_ogre_cat_v_birth_2;
                                            break;
                                        
                                        case UnknownEnum.Value_12:
                                            sprite_index = spr_h_ogre_morrigan_v_birth_2;
                                            break;
                                    }
                                    
                                    break;
                            }
                            
                            break;
                        
                        case UnknownEnum.Value_27:
                            sprite_index = spr_h_tent_bind_1_birth;
                            
                            switch (arg0.unit_data.class)
                            {
                                case UnknownEnum.Value_9:
                                    sprite_index = spr_h_tent_cow_bind_1_birth;
                                    break;
                                
                                case UnknownEnum.Value_10:
                                    sprite_index = spr_h_tent_nyx_bind_1_birth;
                                    break;
                                
                                case UnknownEnum.Value_8:
                                    sprite_index = spr_h_tent_lilith_bind_1_birth;
                                    break;
                                
                                case UnknownEnum.Value_13:
                                    sprite_index = spr_h_tent_cat_bind_1_birth;
                                    break;
                                
                                case UnknownEnum.Value_12:
                                    sprite_index = spr_h_tent_morrigan_bind_1_birth;
                                    break;
                            }
                            
                            break;
                        
                        case UnknownEnum.Value_28:
                            sprite_index = spr_h_tent_bind_2_birth;
                            
                            switch (arg0.unit_data.class)
                            {
                                case UnknownEnum.Value_9:
                                    sprite_index = spr_h_tent_cow_bind_2_birth;
                                    break;
                                
                                case UnknownEnum.Value_10:
                                    sprite_index = spr_h_tent_nyx_bind_2_birth;
                                    break;
                                
                                case UnknownEnum.Value_8:
                                    sprite_index = spr_h_tent_lilith_bind_2_birth;
                                    break;
                                
                                case UnknownEnum.Value_13:
                                    sprite_index = spr_h_tent_cat_bind_2_birth;
                                    break;
                                
                                case UnknownEnum.Value_12:
                                    sprite_index = spr_h_tent_morrigan_bind_2_birth;
                                    break;
                            }
                            
                            break;
                        
                        case UnknownEnum.Value_31:
                            sprite_index = spr_h_tent_t_wall_1_birth;
                            
                            switch (arg0.unit_data.class)
                            {
                                case UnknownEnum.Value_9:
                                    sprite_index = spr_h_tent_cow_t_wall_1_birth;
                                    break;
                                
                                case UnknownEnum.Value_10:
                                    sprite_index = spr_h_tent_nyx_t_wall_1_birth;
                                    break;
                                
                                case UnknownEnum.Value_8:
                                    sprite_index = spr_h_tent_lilith_t_wall_1_birth;
                                    break;
                                
                                case UnknownEnum.Value_13:
                                    sprite_index = spr_h_tent_cat_t_wall_1_birth;
                                    break;
                                
                                case UnknownEnum.Value_12:
                                    sprite_index = spr_h_tent_morrigan_t_wall_1_birth;
                                    break;
                            }
                            
                            break;
                        
                        case UnknownEnum.Value_32:
                            sprite_index = spr_h_tent_t_wall_2_birth;
                            
                            switch (arg0.unit_data.class)
                            {
                                case UnknownEnum.Value_9:
                                    sprite_index = spr_h_tent_cow_t_wall_2_birth;
                                    break;
                                
                                case UnknownEnum.Value_10:
                                    sprite_index = spr_h_tent_nyx_t_wall_2_birth;
                                    break;
                                
                                case UnknownEnum.Value_8:
                                    sprite_index = spr_h_tent_lilith_t_wall_2_birth;
                                    break;
                                
                                case UnknownEnum.Value_13:
                                    sprite_index = spr_h_tent_cat_t_wall_2_birth;
                                    break;
                                
                                case UnknownEnum.Value_12:
                                    sprite_index = spr_h_tent_morrigan_t_wall_2_birth;
                                    break;
                            }
                            
                            break;
                        
                        case UnknownEnum.Value_29:
                            sprite_index = spr_h_tent_t_wall_3_birth;
                            
                            switch (arg0.unit_data.class)
                            {
                                case UnknownEnum.Value_9:
                                    sprite_index = spr_h_tent_t_wall_3_birth;
                                    break;
                                
                                case UnknownEnum.Value_10:
                                    sprite_index = spr_h_tent_nyx_t_wall_3_birth;
                                    break;
                                
                                case UnknownEnum.Value_8:
                                    sprite_index = spr_h_tent_lilith_t_wall_3_birth;
                                    break;
                                
                                case UnknownEnum.Value_13:
                                    sprite_index = spr_h_tent_cat_t_wall_3_birth;
                                    break;
                                
                                case UnknownEnum.Value_12:
                                    sprite_index = spr_h_tent_morrigan_t_wall_3_birth;
                                    break;
                            }
                            
                            break;
                        
                        case UnknownEnum.Value_37:
                            sprite_index = spr_h_ogre_giant_birth;
                            break;
                    }
                    
                    // GNX: birth sprite from class_registry for modded classes
                    if (arg0.unit_data != -1 && arg0.unit_data.class >= 14)
                    {
                        var _rclass = ds_map_find_value(global.class_registry, arg0.unit_data.class);
                        if (_rclass != undefined && variable_struct_exists(_rclass, "birth_spr"))
                        {
                            var _bspr = _rclass.birth_spr;
                            var _h = arg0.slot_data.h_type;
                            var _mt = prop_data.mon_data.mon_type;
                            var _resolved = -1;
                            switch (_h)
                            {
                                case UnknownEnum.Value_5:  _resolved = gnx_birth_spr_lookup(_bspr, "birth_1", _mt); break;
                                case UnknownEnum.Value_12: _resolved = gnx_birth_spr_lookup(_bspr, "birth_2", _mt); break;
                                case UnknownEnum.Value_27: _resolved = gnx_birth_spr_lookup(_bspr, "bind_1", _mt); break;
                                case UnknownEnum.Value_28: _resolved = gnx_birth_spr_lookup(_bspr, "bind_2", _mt); break;
                                case UnknownEnum.Value_31: _resolved = gnx_birth_spr_lookup(_bspr, "t_wall_1", _mt); break;
                                case UnknownEnum.Value_32: _resolved = gnx_birth_spr_lookup(_bspr, "t_wall_2", _mt); break;
                                case UnknownEnum.Value_29: _resolved = gnx_birth_spr_lookup(_bspr, "t_wall_3", _mt); break;
                                case UnknownEnum.Value_37: _resolved = gnx_birth_spr_lookup(_bspr, "giant", _mt); break;
                            }
                            if (_resolved != undefined && _resolved != -1)
                            {
                                gnx_birth_spr = _resolved;
                                // Set a dummy sprite_index for vanilla code that checks it
                                if (!is_struct(_resolved))
                                    sprite_index = _resolved;
                                else
                                    sprite_index = spr_empty;
                            }
                        }
                    }
                    
                    image_index = 0;
                    mask_index = spr_empty;
                }
                
                break;
            
            case UnknownEnum.Value_39:
                var _index = floor(slot_data.anim_struct.index);
                _prop = instance_create_depth(x, y, depth - 1, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    scr_prop_animation_end = scr_prop_destroy;
                    scr_prop_draw = scr_draw_highlight_prop;
                    prop_data.ispeed = 1;
                    follow = true;
                    activate = false;
                    slot_id = other.id;
                    
                    if (slot_id.unit_data.class == UnknownEnum.Value_9)
                        sprite_index = spr_milk_cow;
                    else
                        sprite_index = spr_milk;
                    
                    image_index = 0;
                    
                    if (_index == 2)
                    {
                        prop_data.shift_x = 22;
                    }
                    else
                    {
                        prop_data.shift_x = 23;
                        image_xscale = -1;
                    }
                }
                
                break;
            
            case UnknownEnum.Value_37:
                var _xshift = 0;
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = -52;
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.ispeed = 1;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_fire_lamp;
                }
                
                break;
            
            case UnknownEnum.Value_36:
                var _xshift = 0;
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = irandom_range(-15, -18);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.ispeed = 1;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_lamp;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_0:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_1:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_20:
                var _xshift = irandom_range(-1, 1);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_2:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_3:
                var _xshift = irandom_range(-2, 2);
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = 1;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_4:
                var _xshift = irandom_range(-2, 2);
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_5:
                var _xshift = irandom_range(-2, 2);
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_6:
                var _xshift = 0;
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y;
                
                if (arg2 == UnknownEnum.Value_7)
                    _y = irandom_range(-47, -53);
                else
                    _y = irandom_range(-10, -16);
                
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_7:
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y;
                
                if (arg2 == UnknownEnum.Value_7)
                    _y = irandom_range(-47, -53);
                else
                    _y = irandom_range(-10, -16);
                
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_14:
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-10, -16);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_17:
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-10, -16);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_8:
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-10, -16);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_15:
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-47, -53);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_16:
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = -39;
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_9:
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-47, -53);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_10:
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-10, -16);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_11:
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-10, -16);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_12:
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-10, -16);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_13:
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-47, -53);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_18:
                var _xshift = irandom_range(-2, 2);
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_19:
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-47, -53);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_24:
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-47, -53);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                scr_check_steam_achievement(UnknownEnum.Value_12);
                break;
            
            case UnknownEnum.Value_28:
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-47, -53);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_25:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_26:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_21:
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-10, -16);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_27:
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = irandom_range(-10, -16);
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_22:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_23:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_29:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_30:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_31:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_32:
                var _xshift = irandom_range(-1, 1);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_33:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, depth - 2, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_34:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_35:
                var _xshift = irandom_range(-2, 2);
                var _xscale = choose(1, -1);
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x + _xshift, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1;
                    image_xscale = prop_data.xscale;
                }
                
                break;
            
            case UnknownEnum.Value_38:
                var _xshift = irandom_range(-2, 2);
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + _xshift + !max(0, _xscale);
                var _y = 0;
                _prop = instance_create_depth(x + _x, y + _y, -770, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.ispeed = 1;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_highlight_prop;
                    sprite_index = spr_beacon;
                }
                
                break;
            
            case UnknownEnum.Value_47:
                var _xscale = 1;
                var _x = floor(image_xscale * 0.5) + !max(0, _xscale);
                var _y = -44;
                _prop = instance_create_depth(x + _x, y + _y, -751, obj_prop);
                
                with (_prop)
                {
                    prop_data.prop_type = arg1;
                    prop_data.prop_step = arg3;
                    prop_data.prop_pos = arg2;
                    prop_data.shift_x = _x;
                    prop_data.shift_y = _y;
                    prop_data.xscale = _xscale;
                    slot_id = other.id;
                    activate = false;
                    follow = true;
                    center = true;
                    scr_prop_draw = scr_draw_plaque_prop;
                    sprite_index = spr_between_prop;
                    image_index = arg1 - 11;
                    image_xscale = prop_data.xscale;
                }
                
                break;

            default:
                // GNX: custom decorative prop
                var _rprop = ds_map_find_value(global.prop_registry, arg1);
                if (_rprop != undefined)
                {
                    var _gy = _rprop.y_offset;
                    var _gx = _rprop.x_random_range > 0 ? irandom_range(-_rprop.x_random_range, _rprop.x_random_range) : 0;
                    var _gxs = _rprop.xscale_random ? choose(-1, 1) : 1;
                    _prop = instance_create_depth(x + _gx, y + _gy, (_rprop.position == "bot") ? -770 : -751, obj_prop);

                    with (_prop)
                    {
                        prop_data.prop_type = arg1;
                        prop_data.prop_step = arg3;
                        prop_data.prop_pos = arg2;
                        prop_data.shift_x = _gx;
                        prop_data.shift_y = _gy;
                        prop_data.xscale = _gxs;
                        slot_id = other.id;
                        activate = false;
                        follow = true;
                        center = true;
                        gnx_prop_spr = _rprop.sprite;
                        scr_prop_draw = scr_draw_gnx_prop;
                        sprite_index = spr_between_prop;
                        image_index = 0;
                        image_xscale = _gxs;
                    }
                }
                break;
        }
        
        if (!_exists)
        {
            array_push(slot_data.prop, _prop.prop_data);
            return _prop;
        }
    }
}

function scr_clear_prop_pos(arg0, arg1)
{
    var _exists = -1;
    
    with (arg0)
    {
        for (var i = 0; i < array_length(slot_data.prop); i++)
        {
            if (slot_data.prop[i].prop_pos == arg1)
            {
                _exists = slot_data.prop[i].prop_id.prop_data.prop_type;
                
                with (slot_data.prop[i].prop_id)
                    instance_destroy();
                
                array_delete(slot_data.prop, i, 1);
                i = array_length(slot_data.prop);
            }
        }
    }
    
    return _exists;
}

function scr_prop_destroy()
{
    var _num = array_length(slot_id.slot_data.prop);
    
    for (var i = 0; i < _num; i++)
    {
        if (slot_id.slot_data.prop[i].prop_id == id)
        {
            array_delete(slot_id.slot_data.prop, i, 1);
            i = _num;
        }
    }
    
    instance_destroy();
}

function scr_draw_prop_infant()
{
    // GNX: custom birth sprite draw (SprRef-aware)
    if (variable_instance_exists(id, "gnx_birth_spr") && gnx_birth_spr != -1)
        gnx_draw_sprite_ext(gnx_birth_spr, image_index, x, y, image_xscale, image_yscale, image_angle, image_blend, image_alpha);
    else
        draw_self();
    
    if (!prop_data.spawn)
    {
        if (slot_id.hover)
        {
            // GNX: highlight pass must also use SprRef-aware draw
            if (variable_instance_exists(id, "gnx_birth_spr") && gnx_birth_spr != -1)
                scr_draw_highlight(scr_draw_prop_infant_gnx);
            else
                scr_draw_highlight(draw_self);
        }
    }
    else
    {
        draw_sprite(spr_infant_ui, 0, x + 22, y - 7);
        
        if (hover)
            draw_sprite(spr_infant_ui_sel, 0, x + 22, y - 7);
        
        draw_sprite(spr_infant_ui_head, prop_data.mon_data.mon_type, x + 22, y - 7);
    }
}

// GNX: draw callback for highlight pass on birth props with SprRef
function scr_draw_prop_infant_gnx()
{
    if (variable_instance_exists(id, "gnx_birth_spr") && gnx_birth_spr != -1)
        gnx_draw_sprite_ext(gnx_birth_spr, image_index, x, y, image_xscale, image_yscale, image_angle, image_blend, image_alpha);
    else
        draw_self();
}

function scr_draw_highlight_prop(arg0)
{
    draw_self();
    
    if (arg0 && slot_id.hover)
        scr_draw_highlight(scr_prop_draw);
}

function scr_draw_gnx_prop(arg0)
{
    if (variable_instance_exists(id, "gnx_prop_spr") && gnx_prop_spr != -1)
        gnx_draw_sprite_ext(gnx_prop_spr, 0, x, y, image_xscale, image_yscale, image_angle, image_blend, image_alpha);
    else
        draw_self();

    if (arg0 && slot_id.hover)
    {
        gpu_set_blendmode(bm_add);
        if (variable_instance_exists(id, "gnx_prop_spr") && gnx_prop_spr != -1)
            gnx_draw_sprite_ext(gnx_prop_spr, 0, x, y, image_xscale, image_yscale, image_angle, c_yellow, 0.15);
        else
            draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, image_angle, c_yellow, 0.15);
        gpu_set_blendmode(bm_normal);
    }
}

function scr_draw_plaque_prop(arg0)
{
    draw_self();
    draw_set_halign(fa_center);
    draw_set_color(c_white);
    draw_text(x + 1, y + prop_data.shift_y + 21, global.val.t_lvl);
    
    if (arg0 && slot_id.hover)
        scr_draw_highlight(scr_prop_draw);
}

function scr_check_prop_exists(arg0, arg1, arg2)
{
    var _exists = false;
    
    with (arg0)
    {
        for (var i = 0; i < array_length(slot_data.prop); i++)
        {
            if (slot_data.prop[i].prop_pos == arg1 && slot_data.prop[i].prop_id.prop_data.prop_type == arg2)
            {
                _exists = true;
                i = array_length(slot_data.prop);
            }
        }
    }
    
    return _exists;
}

enum UnknownEnum
{
    Value_0,
    Value_1,
    Value_2,
    Value_3,
    Value_4,
    Value_5,
    Value_6,
    Value_7,
    Value_8,
    Value_9,
    Value_10,
    Value_11,
    Value_12,
    Value_13,
    Value_14,
    Value_15,
    Value_16,
    Value_17,
    Value_18,
    Value_19,
    Value_20,
    Value_21,
    Value_22,
    Value_23,
    Value_24,
    Value_25,
    Value_26,
    Value_27,
    Value_28,
    Value_29,
    Value_30,
    Value_31,
    Value_32,
    Value_33,
    Value_34,
    Value_35,
    Value_36,
    Value_37,
    Value_38,
    Value_39,
    Value_40,
    Value_47 = 47
}
