function scr_patch_update_pre(arg0)
{
    var _var = arg0.global_list.val.version;

    while (_var < 1.33)
    {
        switch (_var)
        {
            case 1.01:
                arg0.global_list.new_guide_list = [];
                var _slot_list = arg0.slot_list;
                var _num = array_length(_slot_list);
                
                for (var i = 0; i < _num; i++)
                {
                    var _data = _slot_list[i];
                    var _prop_num = array_length(_data.slot_data.prop);
                    
                    for (var ii = 0; ii < _prop_num; ii++)
                    {
                        if (_data.slot_data.prop[ii].prop_type > 13)
                        {
                            if (_data.slot_data.prop[ii].prop_type == 15)
                                arg0.slot_list[i].slot_data.prop[ii].prop_type = 37;
                            else
                                arg0.slot_list[i].slot_data.prop[ii].prop_type += 23;
                        }
                    }
                }
                
                break;
            
            case 1.08:
                for (var i = 0; i < array_length(arg0.slot_list); i++)
                {
                    if (arg0.slot_list[i].slot_data.slot_type == 0 || arg0.slot_list[i].slot_data.slot_type == 1)
                        arg0.slot_list[i].slot_data.base_type = 0;
                }
                
                break;
            
            case 1.29:
                arg0.global_list.front_row_save = [];
                arg0.global_list.back_row_save = [];
                break;
        }
        
        _var += 0.01;
    }
    
    // GNX: orphaned cell pass — mark for post-pass rebuild
    var _gnx_sn = array_length(arg0.slot_list);
    var _gnx_orphaned = ds_map_create();

    for (var _gnx_i = 0; _gnx_i < _gnx_sn; _gnx_i++)
    {
        var _gnx_entry = arg0.slot_list[_gnx_i];
        var _gnx_sd = _gnx_entry.slot_data;

        if (!variable_struct_exists(_gnx_sd, "h_type"))
            continue;

        var _gnx_am = variable_struct_exists(_gnx_sd, "anim_struct") ? _gnx_sd.anim_struct : -1;

        if (_gnx_am == -1)
            continue;

        if (ds_map_exists(global.cell_registry, _gnx_sd.h_type))
            continue;

        var _gnx_old_h = _gnx_sd.h_type;
        var _gnx_fb;

        switch (_gnx_sd.slot_type)
        {
            case 1: _gnx_fb = 19; break;
            case 2: _gnx_fb = 31; break;
            default: _gnx_fb = 1; break;
        }

        _gnx_sd.anim_struct = -1;
        _gnx_sd.h_type = _gnx_fb;
        _gnx_sd.gnx_rebuild = _gnx_fb;
        _gnx_sd.gnx_had_unit = is_struct(_gnx_entry.unit_data);
        _gnx_sd.prop = [];
        arg0.slot_list[_gnx_i].unit_data = -1;
        ds_map_add(_gnx_orphaned, _gnx_i, true);

        var _gnx_lf = file_text_open_append(GNX_LOG);
        file_text_write_string(_gnx_lf, "[GNX-SANITIZE] orphaned cell h=" + string(_gnx_old_h) + " -> rebuild as h=" + string(_gnx_fb) + "\n");
        file_text_close(_gnx_lf);
    }

    // GNX: drop goblins in orphaned cells
    if (ds_map_size(_gnx_orphaned) > 0)
    {
        var _gnx_ml = arg0.mon_list;
        var _gnx_mn = array_length(_gnx_ml);
        var _gnx_clean = [];

        for (var _gnx_i = 0; _gnx_i < _gnx_mn; _gnx_i++)
        {
            var _gnx_mon = _gnx_ml[_gnx_i];

            if (_gnx_mon.slot_pos != -1 && ds_map_exists(_gnx_orphaned, _gnx_mon.slot_pos))
            {
                var _gnx_lf = file_text_open_append(GNX_LOG);
                file_text_write_string(_gnx_lf, "[GNX-SANITIZE] goblin dropped (slot=" + string(_gnx_mon.slot_pos) + ")\n");
                file_text_close(_gnx_lf);
            }
            else
                array_push(_gnx_clean, _gnx_mon);
        }

        arg0.mon_list = _gnx_clean;
    }

    ds_map_destroy(_gnx_orphaned);

    // GNX: orphaned unit class pass — replace with fresh peasant
    for (var _gnx_i = 0; _gnx_i < _gnx_sn; _gnx_i++)
    {
        var _gnx_ud = arg0.slot_list[_gnx_i].unit_data;

        if (!is_struct(_gnx_ud))
            continue;

        var _gnx_ct = variable_struct_exists(_gnx_ud, "class") ? _gnx_ud.class : -1;

        if (_gnx_ct < 14 || ds_map_exists(global.class_registry, _gnx_ct))
            continue;

        var _gnx_lf = file_text_open_append(GNX_LOG);
        file_text_write_string(_gnx_lf, "[GNX-SANITIZE] orphaned unit class=" + string(_gnx_ct) + " -> fresh peasant (slot=" + string(_gnx_i) + ")\n");
        file_text_close(_gnx_lf);
        arg0.slot_list[_gnx_i].unit_data = scr_create_unit_base(0, 1);
    }

    // GNX: unit_list sweep — replace orphaned classes with fresh peasants
    var _gnx_ul = arg0.global_list.unit_list;
    var _gnx_un = array_length(_gnx_ul);

    for (var _gnx_i = 0; _gnx_i < _gnx_un; _gnx_i++)
    {
        var _gnx_ud = _gnx_ul[_gnx_i];

        if (!is_struct(_gnx_ud))
            continue;

        var _gnx_ct = variable_struct_exists(_gnx_ud, "class") ? _gnx_ud.class : -1;

        if (_gnx_ct < 14 || ds_map_exists(global.class_registry, _gnx_ct))
            continue;

        _gnx_ul[_gnx_i] = scr_create_unit_base(0, 1);
    }

    // GNX: sanitize stage_info encounter unit_lists (orphaned class from removed mod)
    var _gnx_si_arr = arg0.global_list.val.stage_info;
    if (is_array(_gnx_si_arr))
    {
        for (var _gnx_sg = 0; _gnx_sg < array_length(_gnx_si_arr); _gnx_sg++)
        {
            var _gnx_sg_data = _gnx_si_arr[_gnx_sg];
            if (_gnx_sg_data == -1 || !is_struct(_gnx_sg_data)) continue;
            if (!variable_struct_exists(_gnx_sg_data, "info")) continue;

            var _gnx_sg_info = _gnx_sg_data.info;
            if (!is_array(_gnx_sg_info)) continue;

            for (var _gnx_sg_lvl = 0; _gnx_sg_lvl < array_length(_gnx_sg_info); _gnx_sg_lvl++)
            {
                var _gnx_enc = _gnx_sg_info[_gnx_sg_lvl];
                if (_gnx_enc == -1 || !is_struct(_gnx_enc)) continue;
                if (!variable_struct_exists(_gnx_enc, "unit_list")) continue;

                var _gnx_enc_ul = _gnx_enc.unit_list;
                if (!is_array(_gnx_enc_ul)) continue;

                for (var _gnx_eu = 0; _gnx_eu < array_length(_gnx_enc_ul); _gnx_eu++)
                {
                    var _gnx_eu_data = _gnx_enc_ul[_gnx_eu];
                    if (!is_struct(_gnx_eu_data)) continue;

                    var _gnx_eu_class = variable_struct_exists(_gnx_eu_data, "class") ? _gnx_eu_data.class : -1;
                    if (_gnx_eu_class < 14 || ds_map_exists(global.class_registry, _gnx_eu_class)) continue;

                    _gnx_enc_ul[_gnx_eu] = scr_create_unit_base(0, 0);
                    var _gnx_lf = file_text_open_append(GNX_LOG);
                    file_text_write_string(_gnx_lf, "[GNX-SANITIZE] raid encounter class=" + string(_gnx_eu_class) + " -> vanilla goblin (stage=" + string(_gnx_sg) + " lvl=" + string(_gnx_sg_lvl) + ")\n");
                    file_text_close(_gnx_lf);
                }
            }
        }
    }

    // GNX: sanitize raid formation rows (front/back row entries with orphaned class)
    var _gnx_row_arrs = [
        arg0.global_list.front_row,
        arg0.global_list.back_row,
        arg0.global_list.front_row_save,
        arg0.global_list.back_row_save,
    ];
    var _gnx_row_labels = ["front_row", "back_row", "front_row_save", "back_row_save"];

    for (var _gnx_ri = 0; _gnx_ri < 4; _gnx_ri++)
    {
        var _gnx_row = _gnx_row_arrs[_gnx_ri];
        if (!is_array(_gnx_row)) continue;

        var _gnx_row_clean = [];
        for (var _gnx_re = 0; _gnx_re < array_length(_gnx_row); _gnx_re++)
        {
            var _gnx_rentry = _gnx_row[_gnx_re];
            var _gnx_keep = true;

            if (is_struct(_gnx_rentry) && variable_struct_exists(_gnx_rentry, "unit_data") && is_struct(_gnx_rentry.unit_data))
            {
                var _gnx_rc = variable_struct_exists(_gnx_rentry.unit_data, "class") ? _gnx_rentry.unit_data.class : -1;
                if (_gnx_rc >= 14 && !ds_map_exists(global.class_registry, _gnx_rc))
                {
                    _gnx_keep = false;
                    var _gnx_lf = file_text_open_append(GNX_LOG);
                    file_text_write_string(_gnx_lf, "[GNX-SANITIZE] raid row class=" + string(_gnx_rc) + " dropped from " + _gnx_row_labels[_gnx_ri] + "\n");
                    file_text_close(_gnx_lf);
                }
            }

            if (_gnx_keep)
                array_push(_gnx_row_clean, _gnx_rentry);
        }

        // write cleaned array back into the struct field
        if (_gnx_ri == 0)
            arg0.global_list.front_row = _gnx_row_clean;
        else if (_gnx_ri == 1)
            arg0.global_list.back_row = _gnx_row_clean;
        else if (_gnx_ri == 2)
            arg0.global_list.front_row_save = _gnx_row_clean;
        else
            arg0.global_list.back_row_save = _gnx_row_clean;
    }


    // GNX: sanitize orphaned custom props (from removed mods)
    for (var _gnx_si = 0; _gnx_si < array_length(arg0.slot_list); _gnx_si++)
    {
        var _gnx_sd = arg0.slot_list[_gnx_si].slot_data;
        if (!variable_struct_exists(_gnx_sd, "prop") || !is_array(_gnx_sd.prop))
            continue;

        for (var _gnx_pi = array_length(_gnx_sd.prop) - 1; _gnx_pi >= 0; _gnx_pi--)
        {
            var _gnx_pt = _gnx_sd.prop[_gnx_pi].prop_type;
            if (_gnx_pt >= 100 && !ds_map_exists(global.prop_registry, _gnx_pt))
            {
                var _gnx_lf = file_text_open_append(GNX_LOG);
                file_text_write_string(_gnx_lf, "[GNX-SANITIZE] orphaned prop type=" + string(_gnx_pt) + " removed (slot=" + string(_gnx_si) + ")\n");
                file_text_close(_gnx_lf);
                array_delete(_gnx_sd.prop, _gnx_pi, 1);
            }
        }
    }

    return arg0;
}

function scr_patch_update_post(arg0)
{
    while (global.val.version < 1.33)
    {
        switch (global.val.version)
        {
            case 0.43:
                if (!variable_struct_exists(global.val, "alpha_type"))
                {
                    global.val.alpha_type = 0;
                    global.val.mon_alpha = 1;
                    global.val.crate_alpha_type = 0;
                    global.val.crate_alpha = 1;
                }
                
                global.val.goblin.stat = [1, 1, 2, 3];
                global.val.hobgoblin.stat = [4, 5, 4, 5];
                global.val.tentacle.stat = [3, 3, 4, 4];
                global.val.ogre.stat = [6, 6, 7, 7];
                
                with (obj_slot)
                {
                    if (slot_data.anim_struct != -1 && slot_data.h_type == 4)
                    {
                        var _a = slot_data.mod_index[3];
                        slot_data.mod_index[3] = 0;
                        slot_data.mod_index[4] = _a;
                    }
                }
                
                var _exists = 0;
                var _num = ds_list_size(global.inv_list);
                
                for (var i = 0; i < _num; i++)
                {
                    if (ds_list_find_value(global.inv_list, i).item_type == 2)
                    {
                        _exists++;
                        
                        if (_exists >= 2)
                        {
                            ds_list_delete(global.inv_list, i);
                            i--;
                            _num--;
                        }
                    }
                }
                
                scr_sort_item_button();
                _num = array_length(global.val.shop_item[0]);
                
                for (var i = 0; i < _num; i++)
                {
                    if (global.val.shop_item[0][i][0] == 2)
                    {
                        _exists++;
                        
                        if (_exists >= 2)
                        {
                            array_delete(global.val.shop_item[0], i, 1);
                            i--;
                            _num--;
                            
                            for (var ii = 0; ii < array_length(obj_np.obj_raid.raid_data.shop_item); ii++)
                            {
                                if (obj_np.obj_raid.raid_data.shop_item[ii].item_type == 2)
                                    obj_np.obj_raid.raid_data.shop_item[ii] = -1;
                            }
                        }
                    }
                }
                
                break;
            
            case 1.01:
                if (!variable_struct_exists(global.val, "demo"))
                    global.val.demo = true;
                
                var _exists = false;
                
                for (var i = 0; i < array_length(global.unlock.utility); i++)
                {
                    if (global.unlock.utility[i] == 10)
                    {
                        _exists = true;
                        i = array_length(global.unlock.utility);
                    }
                }
                
                if (_exists)
                {
                    array_push(global.val.guide_unlock.cell, 10);
                    ds_list_add(global.new_guide_list, 10);
                }
                
                with (obj_prop)
                {
                    if (prop_data.prop_type != 40 && prop_data.prop_type != 39 && prop_data.prop_type != 37)
                        prop_data.ispeed = 0;
                }
                
                for (var i = 0; i < array_length(global.unlock.edit_top); i++)
                {
                    if (global.unlock.edit_top[i] == 15)
                        global.unlock.edit_top[i] = 37;
                }
                
                break;
            
            case 1.05:
                if (global.val.stage_info[4] != -1 && global.val.stage_info[4].max_lvl != 0)
                    global.val.stage_info[4].info[1] = scr_stage_encounter_data(4, 1, false);
                
                break;
            
            case 1.08:
                global.val.hobgoblin.num = [-1, -1, -1, -1];
                global.val.hobgoblin.lvl = [0, 0, 0, 0];
                global.val.hobgoblin.expe = [0, 0, 0, 0];
                global.val.hobgoblin.skill_lvl = [0, 0, 0, 0];
                global.val.hobgoblin.skill_exp = [0, 0, 0, 0];
                global.val.tentacle.num = [-1, -1, -1, -1];
                global.val.tentacle.lvl = [0, 0, 0, 0];
                global.val.tentacle.expe = [0, 0, 0, 0];
                global.val.tentacle.skill_lvl = [0, 0, 0, 0];
                global.val.tentacle.skill_exp = [0, 0, 0, 0];
                global.val.ogre.num = [-1, -1, -1, -1];
                global.val.ogre.lvl = [0, 0, 0, 0];
                global.val.ogre.expe = [0, 0, 0, 0];
                global.val.ogre.skill_lvl = [0, 0, 0, 0];
                global.val.ogre.skill_exp = [0, 0, 0, 0];
                global.val.mon_num[1] = -1;
                global.val.mon_num[2] = -1;
                global.val.mon_num[3] = -1;
                
                if (instance_exists(obj_prop))
                {
                    with (obj_prop)
                    {
                        if (slot_id.slot_data.slot_type == 5 && (sprite_index == spr_between_prop || sprite_index == spr_fire_lamp))
                        {
                            depth = -751;
                            
                            for (var i = 0; i < array_length(global.prop_order_bot); i++)
                            {
                                if (prop_data.prop_type == global.prop_order_bot[i])
                                    depth = -770;
                            }
                        }
                    }
                }
                
                break;
            
            case 1.09:
                with (obj_slot)
                {
                    if (unit_data != -1 && unit_data.lvl == 6)
                    {
                        unit_data.preg_c_max = 10;
                        unit_data.preg_c = unit_data.preg_c_max;
                    }
                }
                
                for (var i = 0; i < ds_list_size(global.unit_list); i++)
                {
                    var _id = ds_list_find_value(global.unit_list, i);
                    
                    if (_id != -1 && _id.lvl == 6)
                    {
                        _id.preg_c_max = 10;
                        _id.preg_c = _id.preg_c_max;
                    }
                }
                
                for (var i = 0; i < array_length(global.val.cage); i++)
                {
                    var _id = global.val.cage[i];
                    
                    if (_id != -1 && _id.lvl == 6)
                    {
                        _id.preg_c_max = 10;
                        _id.preg_c = _id.preg_c_max;
                    }
                }
                
                break;
            
            case 1.11:
                var _l_num = 0;
                var _m_num = 0;
                
                with (obj_slot)
                {
                    if (unit_data != -1 && unit_data.class == 8 && unit_data.lvl == 5)
                    {
                        if (_l_num != 0)
                            scr_occupy_slot(id, -1, false, -1);
                        
                        _l_num++;
                    }
                    
                    if (unit_data != -1 && unit_data.class == 12 && unit_data.lvl == 5)
                    {
                        if (_m_num != 0)
                            scr_occupy_slot(id, -1, false, -1);
                        
                        _m_num++;
                    }
                }
                
                for (var i = 0; i < ds_list_size(global.unit_list); i++)
                {
                    var _id = ds_list_find_value(global.unit_list, i);
                    
                    if (_id != -1 && _id.class == 8 && _id.lvl == 5)
                    {
                        if (_l_num != 0)
                            ds_list_set(global.unit_list, i, -1);
                        
                        _l_num++;
                    }
                    
                    if (_id != -1 && _id.class == 12 && _id.lvl == 5)
                    {
                        if (_m_num != 0)
                            ds_list_set(global.unit_list, i, -1);
                        
                        _m_num++;
                    }
                }
                
                for (var i = 0; i < array_length(global.val.cage); i++)
                {
                    var _id = global.val.cage[i];
                    
                    if (_id != -1 && _id.class == 8 && _id.lvl == 5)
                    {
                        if (_l_num != 0)
                            global.val.cage[i] = -1;
                        
                        _l_num++;
                    }
                    
                    if (_id != -1 && _id.class == 12 && _id.lvl == 5)
                    {
                        if (_m_num != 0)
                            global.val.cage[i] = -1;
                        
                        _m_num++;
                    }
                }
                
                if (global.val.show_head)
                {
                    with (obj_button)
                    {
                        if (interact_type == 20 && drag_type == 2 && follow)
                            instance_destroy();
                    }
                    
                    scr_create_slot_head(true, -1);
                    
                    with (obj_button)
                    {
                        if (interact_type == 32 && button_num == 3)
                        {
                            image_index = (button_num * 2) + 1;
                            switch_type = true;
                        }
                    }
                }
                
                for (var i = 0; i < ds_list_size(global.noti_list); i++)
                {
                    var _id = ds_list_find_value(global.noti_list, i);
                    
                    for (var ii = 0; ii < ds_list_size(global.noti_list); ii++)
                    {
                        if (ii != i && _id.noti_type == ds_list_find_value(global.noti_list, ii))
                        {
                            ds_list_delete(global.noti_list, ii);
                            
                            if (ii < i)
                                i--;
                            
                            ii--;
                        }
                    }
                }
                
                break;
            
            case 1.12:
                var _h_num = 0;
                var _n_num = 0;
                var _s_num = 0;
                var _m_num = 0;
                var _b_num = 0;
                var _l_num = 0;
                
                with (obj_slot)
                {
                    if (unit_data != -1 && unit_data.class == 9 && unit_data.lvl == 5)
                    {
                        if (_h_num != 0)
                            scr_occupy_slot(id, -1, false, -1);
                        
                        _h_num++;
                    }
                    
                    if (unit_data != -1 && unit_data.class == 10 && unit_data.lvl == 5)
                    {
                        if (_n_num != 0)
                            scr_occupy_slot(id, -1, false, -1);
                        
                        _n_num++;
                    }
                    
                    if (unit_data != -1 && unit_data.class == 11 && unit_data.lvl == 5)
                    {
                        if (_s_num != 0)
                            scr_occupy_slot(id, -1, false, -1);
                        
                        _s_num++;
                    }
                    
                    if (unit_data != -1 && unit_data.class == 13 && unit_data.lvl == 5)
                    {
                        if (_b_num != 0)
                            scr_occupy_slot(id, -1, false, -1);
                        
                        _b_num++;
                    }
                    
                    if (unit_data != -1 && unit_data.class == 12 && unit_data.lvl == 5)
                    {
                        if (_m_num != 0)
                            scr_occupy_slot(id, -1, false, -1);
                        
                        _m_num++;
                    }
                    
                    if (unit_data != -1 && unit_data.class == 8 && unit_data.lvl == 5)
                    {
                        if (_l_num != 0)
                            scr_occupy_slot(id, -1, false, -1);
                        
                        _l_num++;
                    }
                }
                
                for (var i = 0; i < ds_list_size(global.unit_list); i++)
                {
                    var _id = ds_list_find_value(global.unit_list, i);
                    
                    if (_id != -1 && _id.class == 9 && _id.lvl == 5)
                    {
                        if (_h_num != 0)
                            ds_list_set(global.unit_list, i, -1);
                        
                        _h_num++;
                    }
                    
                    if (_id != -1 && _id.class == 10 && _id.lvl == 5)
                    {
                        if (_n_num != 0)
                            ds_list_set(global.unit_list, i, -1);
                        
                        _n_num++;
                    }
                    
                    if (_id != -1 && _id.class == 11 && _id.lvl == 5)
                    {
                        if (_s_num != 0)
                            ds_list_set(global.unit_list, i, -1);
                        
                        _s_num++;
                    }
                    
                    if (_id != -1 && _id.class == 12 && _id.lvl == 5)
                    {
                        if (_m_num != 0)
                            ds_list_set(global.unit_list, i, -1);
                        
                        _m_num++;
                    }
                    
                    if (_id != -1 && _id.class == 13 && _id.lvl == 5)
                    {
                        if (_b_num != 0)
                            ds_list_set(global.unit_list, i, -1);
                        
                        _b_num++;
                    }
                    
                    if (_id != -1 && _id.class == 8 && _id.lvl == 5)
                    {
                        if (_l_num != 0)
                            ds_list_set(global.unit_list, i, -1);
                        
                        _l_num++;
                    }
                }
                
                break;
            
            case 1.13:
                with (obj_slot)
                {
                    if (unit_data != -1 && unit_data.class >= 8 && unit_data.lvl == 6 && unit_data.preg_c_max == 10)
                    {
                        var _new = unit_data.class;
                        var _unit_id = scr_create_unit_base(_new, 7);
                        unit_data = _unit_id;
                        
                        if (slot_data.h_type == 37)
                            bar_glow_rep = -1;
                    }
                }
                
                for (var i = 0; i < ds_list_size(global.unit_list); i++)
                {
                    var _id = ds_list_find_value(global.unit_list, i);
                    
                    if (_id != -1 && _id.class >= 8 && _id.lvl == 6 && _id.preg_c_max == 10)
                    {
                        var _new = scr_create_unit_base(_id.class, 7);
                        ds_list_replace(global.unit_list, i, _new);
                    }
                }
                
                for (var i = 0; i < array_length(global.val.cage); i++)
                {
                    var _id = global.val.cage[i];
                    
                    if (_id != -1 && _id.class >= 8 && _id.lvl == 6 && _id.preg_c_max == 10)
                    {
                        var _new = scr_create_unit_base(_id.class, 7);
                        global.val.cage[i] = _new;
                    }
                }
                
                if (global.val.show_head)
                {
                    with (obj_button)
                    {
                        if (interact_type == 20 && drag_type == 2 && follow)
                            instance_destroy();
                    }
                    
                    scr_create_slot_head(true, -1);
                    
                    with (obj_button)
                    {
                        if (interact_type == 32 && button_num == 3)
                        {
                            image_index = (button_num * 2) + 1;
                            switch_type = true;
                        }
                    }
                }
                
                break;
            
            case 1.14:
                if (!variable_struct_exists(global.val, "ui_place"))
                    global.val.ui_place = false;
                
                with (obj_slot)
                {
                    if (unit_data != -1 && unit_data.class == 9 && unit_data.lvl == 7)
                        unit_data.leg = 2;
                    
                    if (slot_data.slot_type == 1 && slot_data.h_type == 37)
                        array_insert(slot_data.mod_index, 1, 0);
                }
                
                for (var i = 0; i < ds_list_size(global.unit_list); i++)
                {
                    var _id = ds_list_find_value(global.unit_list, i);
                    
                    if (_id != -1 && _id.class == 9 && _id.lvl == 7)
                    {
                        _id.leg = 2;
                        ds_list_set(global.unit_list, i, _id);
                    }
                }
                
                for (var i = 0; i < array_length(global.val.cage); i++)
                {
                    var _id = global.val.cage[i];
                    
                    if (_id != -1 && _id.class == 9 && _id.lvl == 7)
                    {
                        _id.leg = 2;
                        global.val.cage[i] = _id;
                    }
                }
                
                break;
            
            case 1.15:
                with (obj_slot)
                {
                    if (slot_data.slot_type == 1 && slot_data.h_type == 37)
                    {
                        var _num = 0;
                        
                        for (var i = 0; i < array_length(slot_data.prop); i++)
                        {
                            if (slot_data.prop[i].prop_type == 40 && _num > 0)
                            {
                                with (slot_data.prop[i].prop_id)
                                    instance_destroy();
                                
                                array_delete(slot_data.prop, i, 1);
                                i--;
                            }
                            else
                            {
                                _num++;
                            }
                        }
                    }
                }
                
                break;
            
            case 1.16:
                with (obj_slot)
                {
                    if (slot_data.slot_type == 3)
                    {
                        array_push(slot_data.mod_index, false);
                        array_push(slot_data.mod_index, false);
                        array_push(slot_data.mod_index, true);
                        array_push(slot_data.mod_index, false);
                    }
                }
                
                break;
            
            case 1.23:
                with (obj_slot)
                {
                    if (slot_data.slot_type == 0 && slot_data.h_type == 11)
                    {
                        var _unit_id = unit_data;
                        scr_occupy_slot(id, -1, false, -1);
                        scr_occupy_slot(id, _unit_id, false, -1);
                    }
                }
                
                if (!variable_struct_exists(global.val, "ct_lvl"))
                    global.val.ct_lvl = 0;
                
                if (!variable_struct_exists(global.val, "t_lvl"))
                    global.val.t_lvl = 0;
                
                if (!variable_struct_exists(global.val, "old_t_lvl"))
                    global.val.old_t_lvl = 0;
                
                if (global.val.stage_info[4] != -1)
                {
                    global.val.old_t_lvl = global.val.stage_info[4].max_lvl;
                    global.val.t_lvl = global.val.old_t_lvl;
                    global.val.ct_lvl = min(global.val.t_lvl, 25);
                    global.val.stage_info[4] = -1;
                    global.val.stage_lvl_sel[4] = 0;
                    scr_set_stage_data(4, 0, false);
                    
                    if (global.val.t_lvl > 24)
                    {
                        global.val.stage_info[4].max_lvl = 1;
                        global.val.stage_lvl_sel[4] = min(global.val.stage_lvl_sel[4] + 1, 2);
                        scr_set_stage_data(4, 1, false);
                    }
                    
                    scr_add_event(50, false);
                }
                
                break;
            
            case 1.29:
                with (obj_slot)
                {
                    if (slot_data.slot_type == 1 && slot_data.h_type == 41)
                        array_push(slot_data.mod_index, 0);
                }
                
                break;
            
            case 1.3:
                for (var i = 0; i < ds_list_size(global.front_row_save); i++)
                {
                    var _info = ds_list_find_value(global.front_row_save, i);
                    
                    if (_info.num <= 0)
                    {
                        ds_list_delete(global.front_row_save, i);
                        i--;
                    }
                }
                
                for (var i = 0; i < ds_list_size(global.back_row_save); i++)
                {
                    var _info = ds_list_find_value(global.back_row_save, i);
                    
                    if (_info.num <= 0)
                    {
                        ds_list_delete(global.back_row_save, i);
                        i--;
                    }
                }
                
                for (var i = 0; i < ds_list_size(global.front_row); i++)
                {
                    var _info = ds_list_find_value(global.front_row, i);
                    
                    if (_info.num <= 0)
                    {
                        ds_list_delete(global.front_row, i);
                        i--;
                    }
                }
                
                for (var i = 0; i < ds_list_size(global.back_row); i++)
                {
                    var _info = ds_list_find_value(global.back_row, i);
                    
                    if (_info.num <= 0)
                    {
                        ds_list_delete(global.back_row, i);
                        i--;
                    }
                }
                
                break;
            
            case 1.31:
                var _base = 0;
                var _base_2 = 0;
                var _coin = 0;
                var _new_coin = 0;
                var _f_num = max(0, global.val.floor - 4);
                
                for (var i = 0; i < _f_num; i++)
                {
                    if (i == 0)
                    {
                        _coin = 25000;
                        _new_coin = 15000;
                    }
                    else
                    {
                        _coin = _coin * 2;
                        _new_coin = min(5000000, _new_coin * 2);
                    }
                    
                    _base += _coin;
                    _base_2 += _new_coin;
                }
                
                global.val.money += _base;
                global.val.money -= _base_2;
                break;
        }
        
        global.val.version += 0.01;
    }
    
    // GNX: rebuild orphaned cells — proper init via game's own functions
    with (obj_slot)
    {
        if (variable_struct_exists(slot_data, "gnx_rebuild"))
        {
            scr_set_slot_h_data(id, slot_data.gnx_rebuild);

            if (slot_data.gnx_had_unit)
                scr_occupy_slot(id, scr_create_unit_base(0, 1), false, 0);
        }
    }

    scr_gnx_apply_unlocks();
    scr_gnx_apply_prop_unlocks();
    scr_gnx_migrate_prop_unlocks();
    return arg0;
}

function scr_demo_to_full()
{
    if (1 && global.val.demo)
    {
        global.val.demo = 0;
        var _exists = false;
        var _num = array_length(global.val.shop_item[0]);
        
        for (var i = 0; i < _num; i++)
        {
            if (global.val.shop_item[0][i][0] == 2)
            {
                _exists = true;
                i = _num;
            }
        }
        
        if (!_exists)
        {
            _num = ds_list_size(global.inv_list);
            
            for (var i = 0; i < _num; i++)
            {
                if (ds_list_find_value(global.inv_list, i).item_type == 2)
                {
                    _exists = true;
                    i = _num;
                }
            }
        }
        
        if (_exists)
            scr_add_event(22, false);
        
        if (global.val.stage_info[1] != -1)
            scr_add_event(23, false);
        
        var _a = global.val.shop_item[0];
        scr_set_shop_list();
        global.val.shop_item[0] = _a;
        var _stage = -1;
        
        for (var i = 0; i < 2; i++)
        {
            _stage = i;
            
            if (global.val.stage_info[_stage] != -1)
            {
                var _max = floor(((global.val.stage_info[_stage].max_lvl * 0.4) + 1) * 9);
                
                if (global.val.stage_info[_stage].expe >= _max)
                {
                    global.val.stage_info[_stage].expe = 0;
                    global.val.stage_info[_stage].max_lvl++;
                    global.val.stage_lvl_sel[_stage] = min(global.val.stage_lvl_sel[_stage] + 1, 2);
                    scr_add_new_stage();
                    scr_set_stage_data(_stage, global.val.stage_info[_stage].max_lvl, false);
                }
            }
        }
        
        var _st_1_1 = global.val.stage_item[0][0];
        var _st_1_2 = global.val.stage_item[0][1];
        var _st_2_1 = global.val.stage_item[1][0];
        scr_set_encounter_reward();
        global.val.stage_item[0][0] = _st_1_1;
        global.val.stage_item[0][1] = _st_1_2;
        global.val.stage_item[1][0] = _st_2_1;
        scr_add_event(49, false);
        
        with (obj_button)
        {
            if (interact_type == 33)
            {
                for (var i = 0; i < ds_list_size(global.noti_list); i++)
                {
                    var _noti = ds_list_find_value(global.noti_list, i);
                    
                    if (_noti.noti_type == 49)
                    {
                        scr_create_textbox(_noti, -1, obj_np);
                        instance_destroy();
                        i = ds_list_size(global.noti_list);
                    }
                }
            }
        }
    }
}

