function scr_create_initials()
{
    randomize();
    global.val = {};
    global.val.sfx_vol = 0.5;
    global.val.bgm_vol = 0.5;
    global.val.money = 0;
    global.val.food = 0;
    global.val.play_time = 0;
    global.val.day_timer = 0;
    global.val.day = 1;
    global.val.floor = 0;
    global.val.mood = 80;
    global.val.mood_red = 0;
    global.val.camera_click = 2;
    global.val.select_click = 1;
    global.val.show_head = false;
    global.val.stage_info = [-1, -1, -1, -1, -1];
    global.val.stage_lvl_sel = [0, 0, 0, 0, 0];
    global.val.cage = [-1];
    global.val.quest_new = false;
    global.val.quest_clear = false;
    global.val.troop_size = 0;
    global.val.cart_spd = 1;
    global.val.add_range = 0;
    global.val.orb_num = 4;
    global.val.elf_num = 0;
    global.val.raid_num = 0;
    global.val.birth_num = 0;
    global.val.cap_num = 0;
    global.val.alpha_type = 0;
    global.val.mon_alpha = 1;
    global.val.crate_alpha_type = 0;
    global.val.crate_alpha = 1;
    global.val.ui_place = false;
    global.val.t_lvl = 0;
    global.val.old_t_lvl = 0;
    global.val.ct_lvl = 0;
    global.val.demo = 0;
    global.val.version = 1.33;
    global.val.language = 0;
    global.val.goblin = 
    {
        num: [0, -1, -1, -1],
        stat: [1, 1, 2, 3],
        lvl: [0, 0, 0, 0],
        expe: [0, 0, 0, 0],
        skill_lvl: [0, 0, 0, 0],
        skill_exp: [0, 0, 0, 0]
    };
    global.val.hobgoblin = 
    {
        num: [-1, -1, -1, -1],
        stat: [4, 5, 4, 5],
        lvl: [0, 0, 0, 0],
        expe: [0, 0, 0, 0],
        skill_lvl: [0, 0, 0, 0],
        skill_exp: [0, 0, 0, 0]
    };
    global.val.tentacle = 
    {
        num: [-1, -1, -1, -1],
        stat: [3, 3, 4, 4],
        lvl: [0, 0, 0, 0],
        expe: [0, 0, 0, 0],
        skill_lvl: [0, 0, 0, 0],
        skill_exp: [0, 0, 0, 0]
    };
    global.val.ogre = 
    {
        num: [-1, -1, -1, -1],
        stat: [6, 6, 7, 7],
        lvl: [0, 0, 0, 0],
        expe: [0, 0, 0, 0],
        skill_lvl: [0, 0, 0, 0],
        skill_exp: [0, 0, 0, 0]
    };
    global.val.mon_num = [0, -1, -1, -1];
    global.val.nest_num = [5, 0, 0, 0, 0];
    global.unlock = 
    {
        breed: [],
        utility: [],
        pleasure: [],
        b_breed: [],
        b_utility: [],
        b_other: [],
        t_breed: [],
        t_utility: [],
        edit_between: [],
        edit_top: [],
        edit_mid: [],
        edit_bot: [],
        entrance: false,
        raid: false,
        unit: false,
        timer: false,
        boss: [-1, -1, -1, -1, -1, -1]
    };
    global.val.br_unlock = [[[-1, -1], [-1, -1], [-1, -1], [-1, -1]], [[-1, -1], [-1, -1], [-1, -1], [-1, -1]], [[-1, -1], [-1, -1], [-1, -1], [-1, -1]], [[-1, -1], [-1, -1], [-1, -1], [-1, -1]]];
    // GNX: separate br_unlock for modded classes (vanilla slots are fully occupied)
    // each [type][class] entry is an array of GNX class_ids that can birth this monster class
    global.gnx_br_unlock = [];
    for (var _t = 0; _t < 4; _t++)
    {
        global.gnx_br_unlock[_t] = [];
        for (var _c = 0; _c < 4; _c++)
            global.gnx_br_unlock[_t][_c] = [];
    }
    global.val.guide_unlock =
    {
        num: 0,
        cell: []
    };
    global.unit_list = ds_list_create();
    global.front_row = ds_list_create();
    global.back_row = ds_list_create();
    global.new_button_list = ds_list_create();
    global.noti_list = ds_list_create();
    global.inv_list = ds_list_create();
    global.raid_inv_list = ds_list_create();
    global.quest_list = ds_list_create();
    global.new_guide_list = ds_list_create();
    global.front_row_save = ds_list_create();
    global.back_row_save = ds_list_create();
    
    for (var i = 0; i < 5; i++)
        ds_list_add(global.unit_list, -1);
    
    scr_set_encounter_reward();
    scr_set_shop_list();
    global.load_file = -1;
    global.mask_collision = false;
    global.dirt_fix = 0;
    global.death_fix = 0;
    global.trans_lock = false;
    global.camera_lock = false;
    global.click_lock = false;
    global.drag_lock = false;
    global.speed_lock = false;
    global.speed_save = false;
    global.build_side = false;
    global.w_spd = 1;
    global.zoom_target = 0;
    global.muffle = 1;
    global.breed_order = [1, 2, 7, 8, 9, 13, 14];
    global.utility_order = [5, 12, 4, 10, 11];
    global.pleasure_order = [3, 6, 15];
    global.b_breed_order = [19, 18, 23, 20, 21, 22];
    global.b_utility_order = [17, 24, 25];
    global.b_pleasure_order = [36, 37, 38, 42, 41, 40, 39];
    global.t_breed_order = [31, 32, 29, 27, 28];
    global.t_utility_order = [34, 30, 33];
    global.between_order = [0, 1, 2, 3, 4];
    global.prop_order_top = [37, 9, 13, 19, 24, 28, 6, 15, 16, 47];
    global.prop_order_mid = [10, 7, 14, 17, 8, 11, 12, 36, 21, 27];
    global.prop_order_bot = [0, 1, 20, 2, 3, 30, 31, 18, 4, 5, 22, 23, 25, 29, 32, 33, 34, 35, 26, 38];
    global.guide_order_cell = [10, 12, 11, 17, 33, 30, 24, 25, 41, 42, 40, 39];
    global.base_raid_time = [2760, 3240, 4000, 5100, 4800];
    var _goblin_alpha_c = make_color_rgb(35, 101, 0);
    var _hobgoblin_alpha_c = make_color_rgb(11, 105, 183);
    var _ogre_alpha_c = make_color_rgb(127, 105, 52);
    global.mon_alpha_c = [_goblin_alpha_c, _hobgoblin_alpha_c, -1, _ogre_alpha_c];
    var _start_x = -1;
    global.slot_x = [];
    global.slot_list = [];
    global.slot_x[0] = _start_x;
    global.slot_list[0] = ds_list_create();
    var _c_1 = make_color_rgb(153, 0, 38);
    var _c_2 = make_color_rgb(216, 42, 13);
    var _c_3 = make_color_rgb(222, 161, 0);
    var _c_4 = make_color_rgb(1, 221, 0);
    global.mood_c = [_c_1, _c_2, _c_3, _c_4];
    global.max_exp = [50, 100, 150, 200, 250, 1];
    global.max_troop = [10, 25, 50, 90, 150, 220, 320, -1];
    global.bar_c = make_color_rgb(219, 173, 40);
    scr_set_mon_skill();
    scr_set_mon_range();
    scr_stage_raid_reward();
    scr_set_trade_list();
    // GNX: classes registered with trade_stage go here, keyed by stage (0-4)
    global.gnx_trade_list = [[], [], [], [], []];
    // GNX: per-mod persistent state (inside global.val -> auto-saved)
    global.val.gnx_mod_data = {};
    // GNX: runtime alias map for fast access (not saved, rebuilt on load)
    global.gnx_mod_state = {};
    global.cell_registry = ds_map_create();
    global.class_registry = ds_map_create();
    global.bl_lookup = ds_map_create();
    global.gnx_cov = ds_map_create();
    global.gnx_cov_tick = 0;
    global.gnx_seen = ds_map_create();
    global.gnx_seen_base = ds_map_create();
    global.gnx_expected = ds_list_create();
    global.use_legacy_dispatch = false;
    var _cell = 
    {
        h_type: 1,
        slot_type: 0,
        name: "WALL 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_1_back, false, -1], [2, spr_slot_wall_1_handc, true, -1], [5, spr_slot_wall_1_extra, false, -1], [7, -1, false, -1, false], [8, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts_wall,
            hand_x: [17, 6],
            hand_y: [-42, -40],
            hand_xscale: [1, 1],
            hand_angle: [90, 0],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-31, -30],
            sp_x: 22,
            sp_y: [-28, -33],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 1, _cell);
    _cell = 
    {
        h_type: 2,
        slot_type: 0,
        name: "WALL 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_2_back, false, -1], [3, spr_slot_wall_2_legc, true, -1], [2, spr_slot_wall_2_handc, true, -1], [7, -1, false, -1, false], [8, -1, false, -1, false], [9, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts_wall,
            hand_x: [17, 6, 17],
            hand_y: [-42, -40, -13],
            hand_xscale: [1, 1, 1],
            hand_angle: [90, 0, 90],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-31, -30],
            sp_x: 22,
            sp_y: [-28, -33],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 2, _cell);
    _cell = 
    {
        h_type: 7,
        slot_type: 0,
        name: "WALL 3",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_3_back, false, -1], [3, spr_slot_wall_3_legc, true, -1], [2, spr_slot_wall_3_handc, true, -1], [8, -1, false, -1, false], [7, -1, false, -1, false], [9, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts_wall,
            hand_x: [17, 6],
            hand_y: [-39, -20],
            hand_xscale: [-1, -1],
            hand_angle: [90, 0],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-30, -23],
            sp_x: 22,
            sp_y: [-30, -26],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 7, _cell);
    _cell = 
    {
        h_type: 8,
        slot_type: 0,
        name: "WALL 4",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_4_back, false, -1], [2, spr_slot_wall_4_handc, true, -1], [5, spr_slot_wall_4_extra, false, -1], [7, -1, false, -1, false], [8, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts_wall,
            hand_x: [17, 6],
            hand_y: [-38, -35],
            hand_xscale: [-1, -1],
            hand_angle: [90, 0],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-30, -23],
            sp_x: 22,
            sp_y: [-30, -26],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 8, _cell);
    _cell = 
    {
        h_type: 9,
        slot_type: 0,
        name: "M.PRESS 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[0, spr_slot_press_1_back, false, -1], [5, spr_slot_press_1_extra, false, -1], [12, spr_dirt_mp, false, -1, false], [9, -1, -2, -1, false], [6, -1, false, -1, true], [8, -1, false, -1, false], [2, spr_slot_press_1_handc, true, -1], [7, -1, false, -1, false], [11, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [3],
            hand_y: [-11],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [2, 3],
                frame_3: [3, 4]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-17, -14],
            sp_x: 22,
            sp_y: [-17, -14],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 9, _cell);
    _cell = 
    {
        h_type: 13,
        slot_type: 0,
        name: "PRONE 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[10, -1, -2, -1, false, -1], [0, spr_slot_prone_1_back, false, -1], [12, spr_dirt_prone, false, -1, false], [6, -1, false, -1, false], [8, -1, false, -1, false], [2, spr_slot_prone_1_handc, true, -1], [7, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [4],
            hand_y: [-23],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [2, 3],
                frame_3: [3, 4]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-22, -25],
            sp_x: 22,
            sp_y: [-22, -25],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 13, _cell);
    _cell = 
    {
        h_type: 14,
        slot_type: 0,
        name: "RIDE",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_back, false, -1, false], [5, spr_slot_ride_extra, false, -1], [8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-5, -25],
            sp_x: 22,
            sp_y: [-5, -25],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 14, _cell);
    _cell = 
    {
        h_type: 3,
        slot_type: 0,
        name: "T.FRAME 1",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[0, spr_slot_tf_1_back, false, -1], [8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [5, spr_slot_tf_1_extra, false, -1], [12, spr_dirt_tf, false, -1, false], [6, -1, false, -1, false], [2, spr_slot_tf_1_handc, true, -1], [7, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej_2, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [7, 17],
            hand_y: [-21, -11],
            hand_xscale: [-1, -1],
            hand_angle: [0, 90],
            hand_frames: 
            {
                frame_2: [3, 4],
                frame_3: [3, 4]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-24],
            sp_x: 22,
            sp_y: [-16],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 3, _cell);
    _cell = 
    {
        h_type: 6,
        slot_type: 0,
        name: "BJ 1",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[0, spr_slot_bj_1_back, false, -1], [12, spr_dirt_wall, false, -1, false], [2, spr_slot_bj_1_handc, true, -1], [10, -1, -2, -1, false, -1], [7, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [7, 17],
            hand_y: [-29, -12],
            hand_xscale: [-1, -1],
            hand_angle: [0, 90],
            hand_frames: 
            {
                frame_1: 0,
                frame_2: [3, 4],
                frame_3: [3, 4]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-22],
            sp_x: 22,
            sp_y: [-22],
            sp_anim_x: 0,
            sp_anim_y: 2
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 6, _cell);
    _cell = 
    {
        h_type: 15,
        slot_type: 0,
        name: "FOREPLAY",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [0, spr_slot_foreplay, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-34],
            sp_x: 22,
            sp_y: [-34],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 15, _cell);
    _cell = 
    {
        h_type: 20,
        slot_type: 0,
        name: "OGRE FRONT",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [6, -1, false, -1, false], [8, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_big_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_ogre_front,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-10],
            sp_x: 38,
            sp_y: [-10],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 20, _cell);
    _cell = 
    {
        h_type: 21,
        slot_type: 0,
        name: "OGRE BEHIND",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, true], [10, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_big_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_ogre_behind,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 21, _cell);
    _cell = 
    {
        h_type: 22,
        slot_type: 0,
        name: "OGRE BEHIND 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [10, -1, false, -1, false], [6, -1, false, -1, true], [8, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_big_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_ogre_behind,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-19],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 22, _cell);
    _cell = 
    {
        h_type: 37,
        slot_type: 0,
        name: "GIANT",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_giant, false, -1, false], [13, 0, true, -1], [5, spr_slot_giant_extra, false, -1], [2, spr_slot_giant_control, true, -1, false], [3, spr_slot_giant_control, true, -1, false], [7, -1, true, -1, false], [10, -1, -2, -1, false], [6, -1, true, -1, false], [8, -1, true, -1, false], [9, -1, false, -1, false], [11, -1, false, -1, false], [1, spr_slot_giant_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_giant_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_giant_birth, scr_slot_h_giant_birth_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_giant,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-17],
            sp_x: 38,
            sp_y: [-17],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 37, _cell);
    _cell.physical.sign_y_base = -92;
    _cell.physical.sign_y_jitter = 1;
    _cell = 
    {
        h_type: 39,
        slot_type: 0,
        name: "LILITH SHRINE",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[0, spr_slot_l_shrine, false, -1], [12, spr_dirt_l_shrine, false, -1, false], [10, -1, false, -1, false], [8, -1, false, -1, false], [6, -1, false, -1, true], [7, -1, false, -1, false], [1, spr_slot_lilith_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_l_shrine,
            hand_x: [20],
            hand_y: [-78],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_1: [0],
                frame_2: [0, 1, 4],
                frame_3: [2]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-30],
            sp_x: 38,
            sp_y: [-30],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "fixed",
            phase_1: 
            {
                spr_array: [-1, spr_h_lilith_shrine_idle_head, spr_h_lilith_shrine_idle_breast, spr_h_lilith_hand, spr_h_lilith_shrine_idle_leg, -1],
                spr_c_array: [-1, -1, spr_h_lilith_shrine_idle_breast_c, spr_h_lilith_hand_c, spr_h_lilith_shrine_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_lilith_shrine_loop_head, spr_h_lilith_shrine_loop_hand, spr_h_lilith_hand, spr_h_lilith_shrine_loop_leg, -1],
                spr_c_array: [-1, -1, spr_h_lilith_shrine_loop_hand, spr_h_lilith_hand_c, spr_h_lilith_shrine_loop_leg_c, -1]
            }
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 39, _cell);
    _cell.physical.sign_y_base = -92;
    _cell.physical.sign_y_jitter = 1;
    _cell.physical.slot_range = 1;
    _cell.physical.scr_slot_base = scr_slot_h_lilith_idle;
    _cell.physical.candle_index = 0;
    _cell.physical.dirt_fix_inc = true;
    _cell = 
    {
        h_type: 5,
        slot_type: 0,
        name: "BIRTH 1",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_birth_back, false, -1], [5, spr_slot_birth_extra, false, -1], [10, -1, -2, -1, false, -1], [7, -1, -2, -1, false], [6, -1, -2, -1, false], [8, -1, -2, -1, false], [1, spr_slot_birth_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_birth_idle,
                h: [scr_slot_birth_spawn_loop, scr_slot_non_h_base_wait, scr_slot_birth_spawn_ej]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [7],
            hand_y: [-34],
            hand_xscale: [1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [0],
                frame_3: [0]
            },
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 5, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell = 
    {
        h_type: 12,
        slot_type: 0,
        name: "BIRTH 2",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_birth_2_back, false, -1], [8, -1, -2, -1, false], [6, -1, -2, -1, false], [10, -1, -2, -1, false, -1], [5, spr_slot_birth_2_front, false, -1], [1, spr_slot_birth_2_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_birth_idle,
                h: [scr_slot_birth_spawn_loop, scr_slot_non_h_base_wait, scr_slot_birth_spawn_ej]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 12, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell = 
    {
        h_type: 4,
        slot_type: 0,
        name: "MILK 1",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_milk_1_back, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, false], [10, -1, -2, -1, false, -1], [2, spr_slot_milk_1_handc, true, -1], [7, -1, false, -1, false], [1, spr_slot_milk_1_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_milk_idle,
                h: [scr_slot_h_milk_loop]
            },
            scr_draw_special: scr_draw_slot_milk,
            hand_x: [8],
            hand_y: [-26],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [2],
                frame_3: [2]
            },
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 4, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.milk_step = 0;
    _cell = 
    {
        h_type: 10,
        slot_type: 0,
        name: "DISPLAY",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_display_back, false, -1], [11, -1, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, true], [10, -1, -2, -1, false, -1], [1, spr_slot_display_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_display_idle
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 10, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell = 
    {
        h_type: 11,
        slot_type: 0,
        name: "DRINK",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_drink_back, false, -1], [2, spr_slot_drink_handc, true, -1], [7, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, -2, -1, true], [1, spr_slot_drink_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_drink_idle,
                h: [scr_slot_h_drink_loop]
            },
            scr_draw_special: scr_draw_slot_drink,
            hand_x: [6],
            hand_y: [-48],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [3, 4],
                frame_3: [3, 4]
            },
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 11, _cell);
    _cell.physical.sign_y_base = -86;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.drink_num = 0;
    _cell.physical.mon_index = [0, 0];
    _cell.physical.slot_range = 3;
    _cell = 
    {
        h_type: 18,
        slot_type: 1,
        name: "G.BANG 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 3,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [10, -1, false, -1, false], [6, -1, -2, -1, false], [8, -1, false, -1, false], [0, spr_slot_gb_1_back, false, -1], [1, spr_slot_gb_sign, true, -1], [4, 0, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_gb_1_sloop, scr_slot_h_gb_1_floop, scr_slot_h_gb_1_ej]
            },
            scr_draw_special: scr_draw_slot_gb_1,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-31, -33],
            sp_x: 22,
            sp_y: [-28, -33],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 18, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.set_timer = 0;
    _cell = 
    {
        h_type: 19,
        slot_type: 1,
        name: "G.BANG 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_gb_2_back, false, -1], [10, -1, false, -1, false], [6, -1, false, -1, true], [8, -1, false, -1, false], [1, spr_slot_gb_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_gb_2_idle,
                h: [scr_slot_h_gb_2_sloop, scr_slot_h_gb_2_floop, scr_slot_h_gb_2_ej]
            },
            scr_draw_special: scr_draw_slot_gb_2,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-14, -18],
            sp_x: 38,
            sp_y: [-14, -18],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 19, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.set_timer = 0;
    _cell.physical.sp_place_init = true;
    _cell = 
    {
        h_type: 23,
        slot_type: 1,
        name: "G.BANG 3",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [10, -1, false, -1, false], [6, -1, false, -1, false], [8, -1, false, -1, false], [1, spr_slot_gb_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_gb_3_sloop, scr_slot_h_gb_3_floop, scr_slot_h_gb_3_ej]
            },
            scr_draw_special: scr_draw_ogre_behind,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-19, -25],
            sp_x: 38,
            sp_y: [-19, -25],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 23, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.set_timer = 0;
    _cell = 
    {
        h_type: 36,
        slot_type: 1,
        name: "DAIRY",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [5, spr_slot_cow_extra, false, -1], [10, -1, -2, -1, false], [6, -1, -2, -1, false], [8, -1, false, -1, false], [7, -1, false, -1, false], [1, spr_slot_cow_sign, true, -1], [4, 0, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_cow_state_idle, scr_slot_cow_state_loop, scr_slot_cow_state_floop, scr_slot_cow_state_ej]
            },
            scr_draw_special: scr_draw_slot_cow,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-30],
            sp_x: 22,
            sp_y: [-16],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 36, _cell);
    _cell.human_spr = 
    {
        mode: "fixed",
        phase_1: 
        {
            spr_array: [-1, spr_cow_idle_head, spr_cow_breast, -1, -1, -1],
            spr_c_array: [-1, -1, -1, spr_cow_idle_hand, spr_cow_idle_leg, -1]
        },
        phase_2: 
        {
            spr_array: [-1, spr_cow_loop_head, spr_cow_breast, -1, -1, -1],
            spr_c_array: [-1, -1, -1, spr_cow_loop_hand, spr_cow_loop_leg, -1]
        }
    };
    _cell.physical.sign_y_base = -92;
    _cell.physical.sign_y_jitter = 1;
    _cell.physical.blink_spr = spr_cow_blink;
    _cell.physical.anim_struct_overrides = 
    {
        milk_index: -1,
        milk_timer: -1,
        milk_spd: -1,
        blink_index: -1,
        blink_timer: 0
    };
    _cell.physical.del_item_type = 2;
    _cell = 
    {
        h_type: 38,
        slot_type: 1,
        name: "CHAINS",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_chain_bg, false, -1], [5, spr_slot_chain_extra, false, -1], [6, -1, false, -1, false], [8, -1, false, -1, false], [1, spr_slot_chain_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_chain_idle,
                h: [scr_slot_h_chain_sloop, scr_slot_h_chain_floop, scr_slot_h_chain_ej]
            },
            scr_draw_special: scr_draw_slot_chain,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: [32, 42],
            sq_y: [-36, -36],
            sp_x: [32, 42],
            sp_y: [-36, -36],
            sp_anim_x: -1,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "fixed",
            phase_1: 
            {
                spr_array: [-1, -1, spr_h_morrigan_chain_idle_breast, -1, spr_h_morrigan_chain_idle_leg, -1],
                spr_c_array: [-1, -1, spr_h_morrigan_chain_idle_breast_c, -1, spr_h_morrigan_chain_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, -1, spr_h_morrigan_chain_loop_breast, -1, spr_h_morrigan_chain_loop_leg, -1],
                spr_c_array: [-1, -1, spr_h_morrigan_chain_loop_breast_c, -1, spr_h_morrigan_chain_loop_leg_c, -1]
            }
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 38, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.set_timer = 0;
    _cell.physical.sp_place_init = true;
    _cell = 
    {
        h_type: 40,
        slot_type: 1,
        name: "S.SHRINE",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_v_shrine, false, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 40, _cell);
    _cell.physical.slot_h = false;
    _cell.physical.death_fix_inc = true;
    _cell = 
    {
        h_type: 41,
        slot_type: 1,
        name: "F.SHRINE",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_f_shrine, false, -1], [14, 0, true, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 41, _cell);
    _cell.physical.slot_h = false;
    _cell.physical.slot_range = 5;
    _cell = 
    {
        h_type: 42,
        slot_type: 1,
        name: "R.SHRINE",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_r_shrine, false, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 42, _cell);
    _cell.physical.slot_h = false;
    _cell.physical.scr_slot_step = scr_slot_h_r_shrine_idle;
    _cell = 
    {
        h_type: 17,
        slot_type: 1,
        name: "CAGE",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[5, spr_slot_carry_extra, false, -1], [8, -1, false, -1, false], [10, -1, false, -1, false], [6, -1, false, -1, false], [0, spr_slot_carry_back, false, -1], [1, spr_slot_carry_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_carry_idle,
                h: [scr_slot_carry_load, scr_slot_carry_active]
            },
            scr_draw_special: scr_draw_slot_carry,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 17, _cell);
    _cell.physical.sign_y_base = -90;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.visual = true;
    _cell.physical.anim_struct_overrides = 
    {
        char_state: 0
    };
    _cell.physical.slot_range = 2;
    _cell.physical.scr_slot_step = scr_slot_state;
    _cell = 
    {
        h_type: 24,
        slot_type: 1,
        name: "DISPLAY_B",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, -2, -1, false], [10, -1, false, -1, false], [0, spr_slot_patrol_back, false, -1], [6, -1, -2, -1, false], [7, -1, -2, -1, false], [1, spr_slot_patrol_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_patrol_idle,
                h: [scr_slot_patrol_active]
            },
            scr_draw_special: scr_draw_slot_patrol,
            hand_x: [32],
            hand_y: [-71],
            hand_xscale: [1],
            hand_angle: [90],
            hand_frames: 
            {
                frame_1: [1]
            },
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 24, _cell);
    _cell.physical.sign_y_base = -90;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.visual = true;
    _cell.physical.anim_struct_overrides = 
    {
        char_state: 0
    };
    _cell.physical.slot_range = 1;
    _cell = 
    {
        h_type: 25,
        slot_type: 1,
        name: "CLONE_B",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[0, -1, false, -1], [1, spr_slot_clone_sign, true, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_clone,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 25, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.slot_h = false;
    _cell.physical.scr_slot_step = scr_slot_h_clone_idle;
    _cell.physical.clone_wait = 0;
    _cell = 
    {
        h_type: 27,
        slot_type: 3,
        name: "BIND 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, false, -1, true], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-26],
            sp_x: 22,
            sp_y: [-26],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 27, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = -1;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 28,
        slot_type: 3,
        name: "BIND 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[10, -1, -2, -1, false, -1], [6, -1, false, -1, true], [8, -1, false, -1, false], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-26],
            sp_x: 22,
            sp_y: [-25],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 28, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = -1;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 29,
        slot_type: 3,
        name: "T.WALL 3",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[10, -1, -2, -1, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, false], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-34],
            sp_x: 22,
            sp_y: [-34],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 29, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = spr_slot_wall_tent;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 31,
        slot_type: 3,
        name: "T.WALL 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [2, spr_empty, true, -1], [7, -1, false, -1, false], [3, spr_empty, true, -1], [9, -1, false, -1, false], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [4],
            hand_y: [-42],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3],
                frame_4: [1]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-42],
            sp_x: 22,
            sp_y: [-42],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 31, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = spr_slot_wall_tent;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 32,
        slot_type: 3,
        name: "T.WALL 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [2, spr_empty, true, -1], [7, -1, false, -1, false], [3, spr_empty, true, -1], [9, -1, false, -1, false], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [4, 9],
            hand_y: [-43, -52],
            hand_xscale: [1, 1],
            hand_angle: [0, 90],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3],
                frame_4: [1]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-40],
            sp_x: 22,
            sp_y: [-40],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 32, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = spr_slot_wall_tent;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 30,
        slot_type: 3,
        name: "MILK 2",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[6, -1, false, -1, false], [10, -1, -2, -1, false, -1], [1, spr_slot_milk_2_sign, true, -1], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_milk_2_idle,
                h: [scr_slot_h_milk_2_loop]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 30, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.slot_front = spr_slot_wall_tent_2;
    _cell.physical.milk_num = 0;
    _cell = 
    {
        h_type: 33,
        slot_type: 3,
        name: "RECOVER",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, false, -1, true], [1, spr_slot_recover_sign, true, -1], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_recover_idle
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 33, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.slot_front = spr_slot_wall_tent_2;
    _cell.physical.bar_glow_rep = 0;
    _cell = 
    {
        h_type: 34,
        slot_type: 3,
        name: "CLEAN",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_clean_back, false, -1], [1, spr_slot_clean_sign, true, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 34, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.slot_front = -1;
    _cell.physical.slot_range = 2;
    _cell.physical.slot_h = false;
    _cell.physical.scr_slot_step = scr_slot_clean_idle;
    var _class = 
    {
        name: "peasant",
        is_special: false,
        has_hair: true,
        fap_mul: 1,
        bap_mul: 0,
        hand_sprite: -1,
        hand_color: -1,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_peasant_idle_hair,
                    head: spr_h_peasant_idle_head,
                    breast: spr_h_peasant_idle_breast,
                    leg: spr_h_peasant_idle_leg_1,
                    leg_part: spr_h_peasant_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_peasant_idle_hair,
                    head: spr_h_peasant_idle_head,
                    breast: spr_h_peasant_idle_breast,
                    leg: spr_h_peasant_idle_leg_2,
                    leg_part: spr_h_peasant_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_peasant_loop_hair,
                    head: spr_h_peasant_loop_head,
                    breast: spr_h_peasant_loop_breast,
                    leg: spr_h_peasant_loop_leg_1,
                    leg_part: spr_h_peasant_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_peasant_loop_hair,
                    head: spr_h_peasant_loop_head,
                    breast: spr_h_peasant_loop_breast,
                    leg: spr_h_peasant_loop_leg_2,
                    leg_part: spr_h_peasant_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                hair: spr_h_peasant_big_start_hair,
                head: spr_h_peasant_big_start_head,
                breast: spr_h_peasant_big_start_breast,
                leg_1: spr_h_peasant_big_start_leg_1,
                leg_2: spr_h_peasant_big_start_leg_2
            },
            idle: 
            {
                hair: spr_h_peasant_big_idle_hair,
                head: spr_h_peasant_big_idle_head,
                breast: spr_h_peasant_big_idle_breast,
                leg_1: spr_h_peasant_big_idle_leg_1,
                leg_2: spr_h_peasant_big_idle_leg_2
            },
            loop: 
            {
                hair: spr_h_peasant_big_loop_hair,
                head: spr_h_peasant_big_loop_head,
                breast: spr_h_peasant_big_loop_breast,
                leg_any: spr_h_peasant_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: spr_h_peasant_tent_idle_hair,
                    head: spr_h_peasant_tent_idle_head,
                    breast: spr_h_peasant_tent_idle_breast,
                    hand: -1,
                    leg: spr_h_peasant_tent_idle_leg,
                    leg_part: spr_h_peasant_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_peasant_tent_loop_hair,
                    head: spr_h_peasant_tent_loop_head,
                    breast: spr_h_peasant_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_peasant_tent_loop_leg_v1,
                    leg_part: spr_h_peasant_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_peasant_tent_loop_hair,
                    head: spr_h_peasant_tent_loop_head,
                    breast: spr_h_peasant_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_peasant_tent_loop_leg_v2,
                    leg_part: spr_h_peasant_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_any: 
                {
                    hair: spr_h_peasant_tent_birth_hair,
                    head: spr_h_peasant_tent_birth_head,
                    breast: spr_h_peasant_tent_birth_breast,
                    hand: -1,
                    leg: spr_h_peasant_tent_birth_leg,
                    leg_part: spr_h_peasant_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 0, _class);
    _class = 
    {
        name: "cleric",
        is_special: false,
        has_hair: false,
        fap_mul: 1,
        bap_mul: 4,
        hand_sprite: -1,
        hand_color: spr_h_cleric_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_cleric_idle_head,
                    breast: spr_h_cleric_idle_breast,
                    leg: spr_h_cleric_idle_leg_1,
                    leg_part: spr_h_cleric_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_cleric_idle_head,
                    breast: spr_h_cleric_idle_breast,
                    leg: spr_h_cleric_idle_leg_2,
                    leg_part: spr_h_cleric_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_cleric_loop_head,
                    breast: spr_h_cleric_loop_breast,
                    leg: spr_h_cleric_loop_leg_1,
                    leg_part: spr_h_cleric_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_cleric_loop_head,
                    breast: spr_h_cleric_loop_breast,
                    leg: spr_h_cleric_loop_leg_2,
                    leg_part: spr_h_cleric_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                head: spr_h_cleric_big_start_head,
                breast: spr_h_cleric_big_start_breast,
                leg_any: spr_h_cleric_big_start_leg
            },
            idle: 
            {
                head: spr_h_cleric_big_idle_head,
                breast: spr_h_cleric_big_idle_breast,
                leg_any: spr_h_cleric_big_idle_leg
            },
            loop: 
            {
                head: spr_h_cleric_big_loop_head,
                breast: spr_h_cleric_big_loop_breast,
                leg_any: spr_h_cleric_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_cleric_tent_idle_head,
                    breast: spr_h_cleric_tent_idle_breast,
                    hand: spr_h_cleric_hand,
                    leg: spr_h_cleric_tent_idle_leg,
                    leg_part: spr_h_cleric_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_cleric_tent_loop_head,
                    breast: spr_h_cleric_tent_loop_breast,
                    hand: spr_h_cleric_hand,
                    leg: spr_h_cleric_tent_loop_leg,
                    leg_part: spr_h_cleric_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_cleric_tent_birth_head,
                    breast: spr_h_cleric_tent_birth_breast,
                    hand: spr_h_cleric_hand,
                    leg: spr_h_cleric_tent_birth_leg,
                    leg_part: spr_h_cleric_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 1, _class);
    _class = 
    {
        name: "knight",
        is_special: false,
        has_hair: true,
        fap_mul: 3,
        bap_mul: 1,
        hand_sprite: -1,
        hand_color: spr_h_knight_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_idle_hair,
                    head: spr_h_knight_idle_head,
                    breast: spr_h_knight_idle_breast,
                    leg: spr_h_knight_idle_leg_1,
                    leg_part: spr_h_knight_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_idle_hair,
                    head: spr_h_knight_idle_head,
                    breast: spr_h_knight_idle_breast,
                    leg: spr_h_knight_idle_leg_2,
                    leg_part: spr_h_knight_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_loop_hair,
                    head: spr_h_knight_loop_head,
                    breast: spr_h_knight_loop_breast,
                    leg: spr_h_knight_loop_leg_1,
                    leg_part: spr_h_knight_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_loop_hair,
                    head: spr_h_knight_loop_head,
                    breast: spr_h_knight_loop_breast,
                    leg: spr_h_knight_loop_leg_2,
                    leg_part: spr_h_knight_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                hair: spr_h_knight_big_start_hair,
                head: spr_h_knight_big_start_head,
                breast: spr_h_knight_big_start_breast,
                leg_any: spr_h_knight_big_start_leg
            },
            idle: 
            {
                hair: spr_h_knight_big_idle_hair,
                head: spr_h_knight_big_idle_head,
                breast: spr_h_knight_big_idle_breast,
                leg_1: spr_h_knight_big_idle_leg_1,
                leg_2: spr_h_knight_big_idle_leg_2
            },
            loop: 
            {
                hair: spr_h_knight_big_loop_hair,
                head: spr_h_knight_big_loop_head,
                breast: spr_h_knight_big_loop_breast,
                leg_any: spr_h_knight_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_tent_idle_hair,
                    head: spr_h_knight_tent_idle_head,
                    breast: spr_h_knight_tent_idle_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_idle_leg_v1,
                    leg_part: spr_h_knight_tent_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_tent_idle_hair,
                    head: spr_h_knight_tent_idle_head,
                    breast: spr_h_knight_tent_idle_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_idle_leg_v2,
                    leg_part: spr_h_knight_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_tent_loop_hair,
                    head: spr_h_knight_tent_loop_head,
                    breast: spr_h_knight_tent_loop_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_loop_leg_v1,
                    leg_part: spr_h_knight_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_tent_loop_hair,
                    head: spr_h_knight_tent_loop_head,
                    breast: spr_h_knight_tent_loop_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_loop_leg_v2,
                    leg_part: spr_h_knight_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_tent_birth_hair,
                    head: spr_h_knight_tent_birth_head,
                    breast: spr_h_knight_tent_birth_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_birth_leg_v1,
                    leg_part: spr_h_knight_tent_birth_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_tent_birth_hair,
                    head: spr_h_knight_tent_birth_head,
                    breast: spr_h_knight_tent_birth_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_birth_leg_v2,
                    leg_part: spr_h_knight_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 2, _class);
    _class = 
    {
        name: "ranger",
        is_special: false,
        has_hair: false,
        fap_mul: 2,
        bap_mul: 5,
        hand_sprite: -1,
        hand_color: spr_h_ranger_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                cape: spr_h_ranger_idle_cape,
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_idle_head,
                    breast: spr_h_ranger_idle_breast,
                    leg: spr_h_ranger_idle_leg_1,
                    leg_part: spr_h_ranger_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_idle_head,
                    breast: spr_h_ranger_idle_breast,
                    leg: spr_h_ranger_idle_leg_2,
                    leg_part: spr_h_ranger_idle_leg_part
                }
            },
            phase_2: 
            {
                cape: spr_h_ranger_loop_cape,
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_loop_head,
                    breast: spr_h_ranger_loop_breast,
                    leg: spr_h_ranger_loop_leg_1,
                    leg_part: spr_h_ranger_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_loop_head,
                    breast: spr_h_ranger_loop_breast,
                    leg: spr_h_ranger_loop_leg_2,
                    leg_part: spr_h_ranger_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                head: spr_h_ranger_big_start_head,
                breast: spr_h_ranger_big_start_breast,
                leg_any: spr_h_ranger_big_start_leg
            },
            idle: 
            {
                head: spr_h_ranger_big_idle_head,
                breast: spr_h_ranger_big_idle_breast,
                leg_1: spr_h_ranger_big_idle_leg_1,
                leg_2: spr_h_ranger_big_idle_leg_2
            },
            loop: 
            {
                head: spr_h_ranger_big_loop_head,
                breast: spr_h_ranger_big_loop_breast,
                leg_any: spr_h_ranger_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_idle_head,
                    breast: spr_h_ranger_tent_idle_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_idle_leg_v1,
                    leg_part: spr_h_ranger_tent_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_idle_head,
                    breast: spr_h_ranger_tent_idle_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_idle_leg_v2,
                    leg_part: spr_h_ranger_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_loop_head,
                    breast: spr_h_ranger_tent_loop_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_loop_leg_v1,
                    leg_part: spr_h_ranger_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_loop_head,
                    breast: spr_h_ranger_tent_loop_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_loop_leg_v2,
                    leg_part: spr_h_ranger_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_birth_head,
                    breast: spr_h_ranger_tent_birth_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_birth_leg_v1,
                    leg_part: spr_h_ranger_tent_birth_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_birth_head,
                    breast: spr_h_ranger_tent_birth_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_birth_leg_v2,
                    leg_part: spr_h_ranger_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 3, _class);
    _class = 
    {
        name: "nun",
        is_special: false,
        has_hair: false,
        fap_mul: 0,
        bap_mul: 2,
        hand_sprite: -1,
        hand_color: -1,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_idle_head,
                    breast: spr_h_nun_idle_breast,
                    leg: spr_h_nun_idle_leg_1,
                    leg_part: spr_h_nun_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_idle_head,
                    breast: spr_h_nun_idle_breast,
                    leg: spr_h_nun_idle_leg_2,
                    leg_part: spr_h_nun_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_loop_head,
                    breast: spr_h_nun_loop_breast,
                    leg: spr_h_nun_loop_leg_1,
                    leg_part: spr_h_nun_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_loop_head,
                    breast: spr_h_nun_loop_breast,
                    leg: spr_h_nun_loop_leg_2,
                    leg_part: spr_h_nun_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                head: spr_h_nun_big_start_head,
                breast: spr_h_nun_big_start_breast,
                leg_any: spr_h_nun_big_start_leg
            },
            idle: 
            {
                head: spr_h_nun_big_idle_head,
                breast: spr_h_nun_big_idle_breast,
                leg_1: spr_h_nun_big_idle_leg_1,
                leg_2: spr_h_nun_big_idle_leg_2
            },
            loop: 
            {
                head: spr_h_nun_big_loop_head,
                breast: spr_h_nun_big_loop_breast,
                leg_any: spr_h_nun_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_idle_head,
                    breast: spr_h_nun_tent_idle_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_idle_leg_v1,
                    leg_part: spr_h_nun_tent_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_idle_head,
                    breast: spr_h_nun_tent_idle_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_idle_leg_v2,
                    leg_part: spr_h_nun_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_loop_head,
                    breast: spr_h_nun_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_loop_leg_v1,
                    leg_part: spr_h_nun_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_loop_head,
                    breast: spr_h_nun_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_loop_leg_v2,
                    leg_part: spr_h_nun_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_birth_head,
                    breast: spr_h_nun_tent_birth_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_birth_leg_v1,
                    leg_part: spr_h_nun_tent_birth_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_birth_head,
                    breast: spr_h_nun_tent_birth_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_birth_leg_v2,
                    leg_part: spr_h_nun_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 4, _class);
    _class = 
    {
        name: "samurai",
        is_special: false,
        has_hair: true,
        fap_mul: 6,
        bap_mul: 2,
        hand_sprite: -1,
        hand_color: spr_h_samurai_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_idle_hair,
                    head: spr_h_samurai_idle_head,
                    breast: spr_h_samurai_idle_breast,
                    leg: spr_h_samurai_idle_leg_1,
                    leg_part: spr_h_samurai_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_idle_hair,
                    head: spr_h_samurai_idle_head,
                    breast: spr_h_samurai_idle_breast,
                    leg: spr_h_samurai_idle_leg_2,
                    leg_part: spr_h_samurai_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_loop_hair,
                    head: spr_h_samurai_loop_head,
                    breast: spr_h_samurai_loop_breast,
                    leg: spr_h_samurai_loop_leg_1,
                    leg_part: spr_h_samurai_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_loop_hair,
                    head: spr_h_samurai_loop_head,
                    breast: spr_h_samurai_loop_breast,
                    leg: spr_h_samurai_loop_leg_2,
                    leg_part: spr_h_samurai_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                hair: spr_h_samurai_big_start_hair,
                head: spr_h_samurai_big_start_head,
                breast: spr_h_samurai_big_start_breast,
                leg_any: spr_h_samurai_big_start_leg
            },
            idle: 
            {
                hair: spr_h_samurai_big_idle_hair,
                head: spr_h_samurai_big_idle_head,
                breast: spr_h_samurai_big_idle_breast,
                leg_1: spr_h_samurai_big_idle_leg_1,
                leg_2: spr_h_samurai_big_idle_leg_2
            },
            loop: 
            {
                hair: spr_h_samurai_big_loop_hair,
                head: spr_h_samurai_big_loop_head,
                breast: spr_h_samurai_big_loop_breast,
                leg_any: spr_h_samurai_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_tent_idle_hair,
                    head: spr_h_samurai_tent_idle_head,
                    breast: spr_h_samurai_tent_idle_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_idle_leg_v1,
                    leg_part: spr_h_samurai_tent_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_tent_idle_hair,
                    head: spr_h_samurai_tent_idle_head,
                    breast: spr_h_samurai_tent_idle_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_idle_leg_v2,
                    leg_part: spr_h_samurai_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_tent_loop_hair,
                    head: spr_h_samurai_tent_loop_head,
                    breast: spr_h_samurai_tent_loop_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_loop_leg_v1,
                    leg_part: spr_h_samurai_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_tent_loop_hair,
                    head: spr_h_samurai_tent_loop_head,
                    breast: spr_h_samurai_tent_loop_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_loop_leg_v2,
                    leg_part: spr_h_samurai_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_tent_birth_hair,
                    head: spr_h_samurai_tent_birth_head,
                    breast: spr_h_samurai_tent_birth_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_birth_leg_v1,
                    leg_part: spr_h_samurai_tent_birth_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_tent_birth_hair,
                    head: spr_h_samurai_tent_birth_head,
                    breast: spr_h_samurai_tent_birth_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_birth_leg_v2,
                    leg_part: spr_h_samurai_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 5, _class);
    _class = 
    {
        name: "mage",
        is_special: false,
        has_hair: true,
        fap_mul: 1,
        bap_mul: 2,
        hand_sprite: -1,
        hand_color: -1,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_idle_hair,
                    head: spr_h_mage_idle_head,
                    breast: spr_h_mage_idle_breast,
                    leg: spr_h_mage_idle_leg,
                    leg_part: spr_h_mage_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_loop_hair,
                    head: spr_h_mage_loop_head,
                    breast: spr_h_mage_loop_breast,
                    leg: spr_h_mage_loop_leg,
                    leg_part: spr_h_mage_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                hair: spr_h_shaman_big_start_hair,
                head: spr_h_shaman_big_start_head,
                breast: spr_h_shaman_big_start_breast,
                leg_any: spr_h_shaman_big_start_leg
            },
            idle: 
            {
                hair: spr_h_shaman_big_idle_hair,
                head: spr_h_shaman_big_idle_head,
                breast: spr_h_shaman_big_idle_breast,
                leg_any: spr_h_shaman_big_idle_leg
            },
            loop: 
            {
                hair: spr_h_shaman_big_loop_hair,
                head: spr_h_shaman_big_loop_head,
                breast: spr_h_shaman_big_loop_breast,
                leg_any: spr_h_shaman_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_tent_idle_hair,
                    head: spr_h_mage_tent_idle_head,
                    breast: spr_h_mage_tent_idle_breast,
                    hand: -1,
                    leg: spr_h_mage_tent_idle_leg,
                    leg_part: spr_h_mage_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_tent_loop_hair,
                    head: spr_h_mage_tent_loop_head,
                    breast: spr_h_mage_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_mage_tent_loop_leg,
                    leg_part: spr_h_mage_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_tent_birth_hair,
                    head: spr_h_mage_tent_birth_head,
                    breast: spr_h_mage_tent_birth_breast,
                    hand: -1,
                    leg: spr_h_mage_tent_birth_leg,
                    leg_part: spr_h_mage_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 6, _class);
    _class = 
    {
        name: "warrior",
        is_special: false,
        has_hair: false,
        fap_mul: 5,
        bap_mul: 0,
        hand_sprite: -1,
        hand_color: spr_h_warrior_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_idle_head,
                    breast: spr_h_warrior_idle_breast,
                    leg: spr_h_warrior_idle_leg,
                    leg_part: spr_h_warrior_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_loop_head,
                    breast: spr_h_warrior_loop_breast,
                    leg: spr_h_warrior_loop_leg,
                    leg_part: spr_h_warrior_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                head: spr_h_warrior_big_start_head,
                breast: spr_h_warrior_big_start_breast,
                leg_any: spr_h_warrior_big_start_leg
            },
            idle: 
            {
                head: spr_h_warrior_big_idle_head,
                breast: spr_h_warrior_big_idle_breast,
                leg_any: spr_h_warrior_big_idle_leg
            },
            loop: 
            {
                head: spr_h_warrior_big_loop_head,
                breast: spr_h_warrior_big_loop_breast,
                leg_any: spr_h_warrior_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_tent_idle_head,
                    breast: spr_h_warrior_tent_idle_breast,
                    hand: spr_h_warrior_hand,
                    leg: spr_h_warrior_tent_idle_leg,
                    leg_part: spr_h_warrior_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_tent_loop_head,
                    breast: spr_h_warrior_tent_loop_breast,
                    hand: spr_h_warrior_hand,
                    leg: spr_h_warrior_tent_loop_leg,
                    leg_part: spr_h_warrior_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_tent_birth_head,
                    breast: spr_h_warrior_tent_birth_breast,
                    hand: spr_h_warrior_hand,
                    leg: spr_h_warrior_tent_birth_leg,
                    leg_part: spr_h_warrior_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 7, _class);
    _class = 
    {
        name: "cow",
        is_special: true,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_cow, spr_h_base_idle_breast_cow, spr_h_cow_hand, spr_h_base_idle_leg_cow, spr_h_base_idle_leg_part_cow, spr_h_base_idle_cape_cow],
                spr_c_array: [-1, spr_h_base_idle_head_cow, spr_h_base_idle_breast_c_cow, spr_h_cow_hand_c, spr_h_base_idle_leg_c_cow, spr_h_base_idle_leg_part_c_cow]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_cow, spr_h_base_loop_breast_cow, spr_h_cow_hand, spr_h_base_loop_leg_cow, spr_h_base_loop_leg_part_cow, spr_h_base_loop_cape_cow],
                spr_c_array: [-1, spr_h_base_loop_head_cow, spr_h_base_loop_breast_c_cow, spr_h_cow_hand_c, spr_h_base_loop_leg_c_cow, spr_h_base_loop_leg_part_c_cow]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_cow_big_start_head, spr_h_cow_big_start_breast, spr_h_cow_hand, spr_h_cow_big_start_leg, -1],
                spr_c_array: [-1, spr_h_cow_big_start_head, spr_h_cow_big_start_breast_c, spr_h_cow_hand_c, spr_h_cow_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_cow_big_idle_head, spr_h_cow_big_idle_breast, spr_h_cow_hand, spr_h_cow_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_cow_big_idle_head, spr_h_cow_big_idle_breast_c, spr_h_cow_hand_c, spr_h_cow_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_cow_big_loop_head, spr_h_cow_big_loop_breast, spr_h_cow_hand, spr_h_cow_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_cow_big_loop_head, spr_h_cow_big_loop_breast_c, spr_h_cow_hand_c, spr_h_cow_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_cow_tent_idle_head, spr_h_cow_tent_idle_breast, spr_h_cow_hand, spr_h_cow_tent_idle_leg, spr_h_cow_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_cow_tent_idle_head, spr_h_cow_tent_idle_breast_c, spr_h_cow_hand_c, spr_h_cow_tent_idle_leg_c, spr_h_cow_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_cow_tent_loop_head, spr_h_cow_tent_loop_breast, spr_h_cow_hand, spr_h_cow_tent_loop_leg, spr_h_cow_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_cow_tent_loop_head, spr_h_cow_tent_loop_breast_c, spr_h_cow_hand_c, spr_h_cow_tent_loop_leg_c, spr_h_cow_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_cow_tent_birth_head, spr_h_cow_tent_birth_breast, spr_h_cow_hand, spr_h_cow_tent_birth_leg, spr_h_cow_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_cow_tent_birth_head, spr_h_cow_tent_birth_breast_c, spr_h_cow_hand_c, spr_h_cow_tent_birth_leg_c, spr_h_cow_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 9, _class);
    _class = 
    {
        name: "nyx",
        is_special: true,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_nyx, spr_h_base_idle_breast_nyx, spr_h_nyx_hand, spr_h_base_idle_leg_nyx, spr_h_base_idle_leg_part_nyx, -1],
                spr_c_array: [-1, spr_h_base_idle_head_nyx, spr_h_base_idle_breast_c_nyx, spr_h_nyx_hand_c, spr_h_base_idle_leg_c_nyx, spr_h_base_idle_leg_part_c_nyx]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_nyx, spr_h_base_loop_breast_nyx, spr_h_nyx_hand, spr_h_base_loop_leg_nyx, spr_h_base_loop_leg_part_nyx, -1],
                spr_c_array: [-1, spr_h_base_loop_head_nyx, spr_h_base_loop_breast_c_nyx, spr_h_nyx_hand_c, spr_h_base_loop_leg_c_nyx, spr_h_base_loop_leg_part_c_nyx]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_nyx_big_start_head, spr_h_nyx_big_start_breast, spr_h_nyx_hand, spr_h_nyx_big_start_leg, -1],
                spr_c_array: [-1, spr_h_nyx_big_start_head, spr_h_nyx_big_start_breast_c, spr_h_nyx_hand_c, spr_h_nyx_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_nyx_big_idle_head, spr_h_nyx_big_idle_breast, spr_h_nyx_hand, spr_h_nyx_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_nyx_big_idle_head, spr_h_nyx_big_idle_breast_c, spr_h_nyx_hand_c, spr_h_nyx_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_nyx_big_loop_head, spr_h_nyx_big_loop_breast, spr_h_nyx_hand, spr_h_nyx_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_nyx_big_loop_head, spr_h_nyx_big_loop_breast_c, spr_h_nyx_hand_c, spr_h_nyx_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_nyx_tent_idle_head, spr_h_nyx_tent_idle_breast, spr_h_nyx_hand, spr_h_nyx_tent_idle_leg, spr_h_nyx_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_nyx_tent_idle_head, spr_h_nyx_tent_idle_breast_c, spr_h_nyx_hand_c, spr_h_nyx_tent_idle_leg_c, spr_h_nyx_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_nyx_tent_loop_head, spr_h_nyx_tent_loop_breast, spr_h_nyx_hand, spr_h_nyx_tent_loop_leg, spr_h_nyx_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_nyx_tent_loop_head, spr_h_nyx_tent_loop_breast_c, spr_h_nyx_hand_c, spr_h_nyx_tent_loop_leg_c, spr_h_nyx_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_nyx_tent_birth_head, spr_h_nyx_tent_birth_breast, spr_h_nyx_hand, spr_h_nyx_tent_birth_leg, spr_h_nyx_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_nyx_tent_birth_head, spr_h_nyx_tent_birth_breast_c, spr_h_nyx_hand_c, spr_h_nyx_tent_birth_leg_c, spr_h_nyx_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 10, _class);
    _class = 
    {
        name: "cat",
        is_special: true,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_cat, spr_h_base_idle_breast_cat, spr_h_cat_hand, spr_h_base_idle_leg_cat, spr_h_base_idle_leg_part_cat, -1],
                spr_c_array: [-1, spr_h_base_idle_head_cat, spr_h_base_idle_breast_c_cat, spr_h_cat_hand_c, spr_h_base_idle_leg_c_cat, spr_h_base_idle_leg_part_c_cat]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_cat, spr_h_base_loop_breast_cat, spr_h_cat_hand, spr_h_base_loop_leg_cat, spr_h_base_loop_leg_part_cat, -1],
                spr_c_array: [-1, spr_h_base_loop_head_cat, spr_h_base_loop_breast_c_cat, spr_h_cat_hand_c, spr_h_base_loop_leg_c_cat, spr_h_base_loop_leg_part_c_cat]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_cat_big_start_head, spr_h_cat_big_start_breast, spr_h_cat_hand, spr_h_cat_big_start_leg, -1],
                spr_c_array: [-1, spr_h_cat_big_start_head, spr_h_cat_big_start_breast_c, spr_h_cat_hand_c, spr_h_cat_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_cat_big_idle_head, spr_h_cat_big_idle_breast, spr_h_cat_hand, spr_h_cat_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_cat_big_idle_head, spr_h_cat_big_idle_breast_c, spr_h_cat_hand_c, spr_h_cat_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_cat_big_loop_head, spr_h_cat_big_loop_breast, spr_h_cat_hand, spr_h_cat_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_cat_big_loop_head, spr_h_cat_big_loop_breast_c, spr_h_cat_hand_c, spr_h_cat_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_cat_tent_idle_head, spr_h_cat_tent_idle_breast, spr_h_cat_hand, spr_h_cat_tent_idle_leg, spr_h_cat_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_cat_tent_idle_head, spr_h_cat_tent_idle_breast_c, spr_h_cat_hand_c, spr_h_cat_tent_idle_leg_c, spr_h_cat_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_cat_tent_loop_head, spr_h_cat_tent_loop_breast, spr_h_cat_hand, spr_h_cat_tent_loop_leg, spr_h_cat_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_cat_tent_loop_head, spr_h_cat_tent_loop_breast_c, spr_h_cat_hand_c, spr_h_cat_tent_loop_leg_c, spr_h_cat_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_cat_tent_birth_head, spr_h_cat_tent_birth_breast, spr_h_cat_hand, spr_h_cat_tent_birth_leg, spr_h_cat_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_cat_tent_birth_head, spr_h_cat_tent_birth_breast_c, spr_h_cat_hand_c, spr_h_cat_tent_birth_leg_c, spr_h_cat_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 13, _class);
    _class = 
    {
        name: "morrigan",
        is_special: true,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_morrigan, spr_h_base_idle_breast_morrigan, spr_h_morrigan_hand, spr_h_base_idle_leg_morrigan, spr_h_base_idle_leg_part_morrigan, spr_h_base_idle_cape_morrigan],
                spr_c_array: [-1, spr_h_base_idle_head_morrigan, spr_h_base_idle_breast_c_morrigan, spr_h_morrigan_hand_c, spr_h_base_idle_leg_c_morrigan, spr_h_base_idle_leg_part_c_morrigan]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_morrigan, spr_h_base_loop_breast_morrigan, spr_h_morrigan_hand, spr_h_base_loop_leg_morrigan, spr_h_base_loop_leg_part_morrigan, spr_h_base_idle_cape_morrigan],
                spr_c_array: [-1, spr_h_base_loop_head_morrigan, spr_h_base_loop_breast_c_morrigan, spr_h_morrigan_hand_c, spr_h_base_loop_leg_c_morrigan, spr_h_base_loop_leg_part_c_morrigan]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_morrigan_big_start_head, spr_h_morrigan_big_start_breast, spr_h_morrigan_hand, spr_h_morrigan_big_start_leg, -1],
                spr_c_array: [-1, spr_h_morrigan_big_start_head, spr_h_morrigan_big_start_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_morrigan_big_idle_head, spr_h_morrigan_big_idle_breast, spr_h_morrigan_hand, spr_h_morrigan_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_morrigan_big_idle_head, spr_h_morrigan_big_idle_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_morrigan_big_loop_head, spr_h_morrigan_big_loop_breast, spr_h_morrigan_hand, spr_h_morrigan_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_morrigan_big_loop_head, spr_h_morrigan_big_loop_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_morrigan_tent_idle_head, spr_h_morrigan_tent_idle_breast, spr_h_morrigan_hand, spr_h_morrigan_tent_idle_leg, spr_h_morrigan_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_morrigan_tent_idle_head, spr_h_morrigan_tent_idle_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_tent_idle_leg_c, spr_h_morrigan_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_morrigan_tent_loop_head, spr_h_morrigan_tent_loop_breast, spr_h_morrigan_hand, spr_h_morrigan_tent_loop_leg, spr_h_morrigan_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_morrigan_tent_loop_head, spr_h_morrigan_tent_loop_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_tent_loop_leg_c, spr_h_morrigan_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_morrigan_tent_birth_head, spr_h_morrigan_tent_birth_breast, spr_h_morrigan_hand, spr_h_morrigan_tent_birth_leg, spr_h_morrigan_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_morrigan_tent_birth_head, spr_h_morrigan_tent_birth_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_tent_birth_leg_c, spr_h_morrigan_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 12, _class);
    _class = 
    {
        name: "lilith",
        is_special: true,
        fap_mul: 0,
        bap_mul: 0,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_lilith, spr_h_base_idle_breast_lilith, spr_h_lilith_hand, spr_h_base_idle_leg_lilith, spr_h_base_idle_leg_part_lilith, -1],
                spr_c_array: [-1, spr_h_base_idle_head_lilith, spr_h_base_idle_breast_c_lilith, spr_h_lilith_hand_c, spr_h_base_idle_leg_c_lilith, spr_h_base_idle_leg_part_c_lilith]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_lilith, spr_h_base_loop_breast_lilith, spr_h_lilith_hand, spr_h_base_loop_leg_lilith, spr_h_base_loop_leg_part_lilith, -1],
                spr_c_array: [-1, spr_h_base_loop_head_lilith, spr_h_base_loop_breast_c_lilith, spr_h_lilith_hand_c, spr_h_base_loop_leg_c_lilith, spr_h_base_loop_leg_part_c_lilith]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_lilith_big_start_head, spr_h_lilith_big_start_breast, spr_h_lilith_hand, spr_h_lilith_big_start_leg, -1],
                spr_c_array: [-1, spr_h_lilith_big_start_head, spr_h_lilith_big_start_breast_c, spr_h_lilith_hand_c, spr_h_lilith_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_lilith_big_idle_head, spr_h_lilith_big_idle_breast, spr_h_lilith_hand, spr_h_lilith_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_lilith_big_idle_head, spr_h_lilith_big_idle_breast_c, spr_h_lilith_hand_c, spr_h_lilith_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_lilith_big_loop_head, spr_h_lilith_big_loop_breast, spr_h_lilith_hand, spr_h_lilith_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_lilith_big_loop_head, spr_h_lilith_big_loop_breast_c, spr_h_lilith_hand_c, spr_h_lilith_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_lilith_tent_idle_head, spr_h_lilith_tent_idle_breast, spr_h_lilith_hand, spr_h_lilith_tent_idle_leg, spr_h_lilith_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_lilith_tent_idle_head, spr_h_lilith_tent_idle_breast_c, spr_h_lilith_hand_c, spr_h_lilith_tent_idle_leg_c, spr_h_lilith_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_lilith_tent_loop_head, spr_h_lilith_tent_loop_breast, spr_h_lilith_hand, spr_h_lilith_tent_loop_leg, spr_h_lilith_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_lilith_tent_loop_head, spr_h_lilith_tent_loop_breast_c, spr_h_lilith_hand_c, spr_h_lilith_tent_loop_leg_c, spr_h_lilith_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_lilith_tent_birth_head, spr_h_lilith_tent_birth_breast, spr_h_lilith_hand, spr_h_lilith_tent_birth_leg, spr_h_lilith_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_lilith_tent_birth_head, spr_h_lilith_tent_birth_breast_c, spr_h_lilith_hand_c, spr_h_lilith_tent_birth_leg_c, spr_h_lilith_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 8, _class);
    _class = 
    {
        name: "giant",
        is_special: true,
        has_hair: false,
        hand_sprite: -1,
        hand_color: -1,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [spr_giant_idle_middle, spr_giant_idle_head, spr_giant_idle_breast, spr_giant_idle_hand, spr_giant_idle_leg_1, spr_giant_idle_leg_2, spr_giant_idle_middle],
                spr_c_array: [-1, -1, spr_giant_idle_breast_c, spr_giant_idle_hand_c, spr_giant_idle_leg_1_c, spr_giant_idle_leg_2_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_giant_loop_head, spr_giant_loop_breast, spr_giant_loop_hand, spr_giant_loop_leg_1, spr_giant_loop_leg_2, spr_giant_loop_middle],
                spr_c_array: [-1, -1, spr_giant_loop_breast_c, spr_giant_loop_hand_c, spr_giant_loop_leg_1_c, spr_giant_loop_leg_2_c]
            }
        }
    };
    ds_map_add(global.class_registry, 11, _class);
    global.gnx_registered_cells = [];
    global.gnx_encounter_pools = ds_map_create();
    scr_gnx_init_encounter_pools();
    scr_gnx_load_mods();
    var _gnx_ak = ds_map_find_first(global.cell_registry);
    
    while (_gnx_ak != undefined)
    {
        var _gnx_ac = ds_map_find_value(global.cell_registry, _gnx_ak);
        var _gnx_ap = _gnx_ac.physical;
        
        if (array_length(_gnx_ap.sp_y) < 2)
            _gnx_ap.sp_y = [_gnx_ap.sp_y[0], _gnx_ap.sp_y[0]];
        
        if (array_length(_gnx_ap.sq_y) < 2)
            _gnx_ap.sq_y = [_gnx_ap.sq_y[0], _gnx_ap.sq_y[0]];
        
        _gnx_ak = ds_map_find_next(global.cell_registry, _gnx_ak);
    }
    
    scr_gnx_build_expected();
    scr_gnx_test_suite();
    scr_gnx_test_dispatch_routing();
    draw_set_font(fnt_base_font_eng);
    display_set_gui_size(480, 270);
    window_set_cursor(cr_none);
    
    if (room == rm_init)
        room_goto(rm_logo);
}

function gnx_resolve_script(arg0)
{
    var _idx = asset_get_index(arg0);
    
    if (_idx < 0)
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] WARNING: script not found: " + arg0 + "\n");
        file_text_close(_log);
    }
    
    return _idx;
}

function gnx_resolve_layer_sprite(arg0, arg1, arg2)
{
    if (is_real(arg0))
        return arg0;
    
    if (!is_string(arg0))
        return -1;
    
    if (string_copy(arg0, 1, 4) == "gnx:")
    {
        var _key = string_delete(arg0, 1, 4);
        
        if (arg1 != undefined && variable_struct_exists(arg1, _key))
            return gnx_resolve_sprite(arg1, _key, arg2, -1);
        
        return -1;
    }
    
    var _idx = asset_get_index(arg0);
    return (_idx >= 0) ? _idx : -1;
}

function gnx_resolve_sprite(arg0, arg1, arg2, arg3)
{
    if (!variable_struct_exists(arg0, arg1))
        return arg3;

    var _s = variable_struct_get(arg0, arg1);
    var _xo = (is_struct(_s) && variable_struct_exists(_s, "xorig")) ? _s.xorig : 0;
    var _yo = (is_struct(_s) && variable_struct_exists(_s, "yorig")) ? _s.yorig : 0;

    // Cache key must identify the actual asset (strip/path/frames), not just the
    // "gnx:<key>" lookup name — different classes/cells reuse common key names
    // (idle_head, loop_breast, ...) for entirely different sprites in their own
    // "sprites" dict, and keying on arg1 alone caused cache collisions where the
    // second entry silently returned the first one's sprite.
    var _cache_key;

    if (is_struct(_s) && variable_struct_exists(_s, "strip"))
        _cache_key = arg2 + _s.strip;
    else if (is_struct(_s) && variable_struct_exists(_s, "frames") && is_array(_s.frames))
    {
        _cache_key = arg2;
        for (var _ci = 0; _ci < array_length(_s.frames); _ci++)
            _cache_key += "|" + string(_s.frames[_ci]);
    }
    else if (is_struct(_s) && variable_struct_exists(_s, "path"))
        _cache_key = arg2 + _s.path;
    else if (!is_struct(_s))
        _cache_key = arg2 + string(_s);
    else
        _cache_key = arg2 + arg1;

    // Cache hit: return previously loaded sprite
    if (ds_map_exists(global.gnx_sprite_cache, _cache_key))
    {
        var _cached = ds_map_find_value(global.gnx_sprite_cache, _cache_key);
        if (sprite_exists(_cached))
            return _cached;
        ds_map_delete(global.gnx_sprite_cache, _cache_key);
    }

    if (is_struct(_s) && variable_struct_exists(_s, "strip"))
    {
        var _path = arg2 + _s.strip;
        var _n_imgs = is_real(_s.frames) ? _s.frames : 1;
        _loaded = sprite_add(_path, _n_imgs, false, false, _xo, _yo);
        if (_loaded != -1)
        {
            array_push(global.gnx_runtime_sprites, _loaded);
            ds_map_set(global.gnx_sprite_cache, _cache_key, _loaded);
        }
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] " + arg1 + ": strip frames=" + string(_n_imgs) + " idx=" + string(_loaded) + "\n");
        file_text_close(_log);
        return (_loaded != -1) ? _loaded : arg3;
    }

    var _fps = [];

    if (!is_struct(_s))
    {
        array_push(_fps, arg2 + string(_s));
    }
    else if (variable_struct_exists(_s, "frames") && is_array(_s.frames))
    {
        var _fa = _s.frames;

        for (var _fi = 0; _fi < array_length(_fa); _fi++)
            array_push(_fps, arg2 + _fa[_fi]);
    }
    else if (variable_struct_exists(_s, "path"))
    {
        array_push(_fps, arg2 + _s.path);
    }
    else
    {
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] WARN " + arg1 + ": no strip/path/frames, returning fallback\n");
        file_text_close(_log);
        return arg3;
    }

    var _loaded = gnx_load_sprite_frames(_fps, _xo, _yo);
    if (_loaded != -1)
        ds_map_set(global.gnx_sprite_cache, _cache_key, _loaded);
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] " + arg1 + ": frames=" + string(array_length(_fps)) + " idx=" + string(_loaded) + " xo=" + string(_xo) + " yo=" + string(_yo) + "\n");
    file_text_close(_log);
    return (_loaded != -1) ? _loaded : arg3;
}

function gnx_load_sprite_frames(arg0, arg1, arg2)
{
    var _n = array_length(arg0);
    
    if (_n == 0)
        return -1;
    
    var _spr = sprite_add(arg0[0], 1, false, false, arg1, arg2);

    if (_spr == -1)
        return -1;

    array_push(global.gnx_runtime_sprites, _spr);

    if (_n == 1)
        return _spr;

    var _w = sprite_get_width(_spr);
    var _h = sprite_get_height(_spr);
    
    for (var _i = 1; _i < _n; _i++)
    {
        var _tmp = sprite_add(arg0[_i], 1, false, false, 0, 0);
        
        if (_tmp == -1)
            continue;
        
        var _surf = surface_create(_w, _h);
        surface_set_target(_surf);
        draw_clear_alpha(c_black, 0);
        draw_sprite(_tmp, 0, 0, 0);
        surface_reset_target();
        sprite_add_from_surface(_spr, _surf, 0, 0, _w, _h, false, false);
        surface_free(_surf);
        sprite_delete(_tmp);
    }
    
    return _spr;
}

/// @desc Records a mod-loading problem so it can be surfaced to the player
///       (not just gnx_debug.txt). Also writes to GNX_LOG.
/// @arg {string} arg0  human-readable error message
function gnx_report_mod_error(arg0)
{
    if (!variable_global_exists("gnx_mod_errors") || !is_array(global.gnx_mod_errors))
        global.gnx_mod_errors = [];

    array_push(global.gnx_mod_errors, arg0);

    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] ERROR: " + arg0 + "\n");
    file_text_close(_log);
}

function scr_gnx_load_mods()
{
    global.gnx_mods_root = program_directory + "GNX_mods/";
    var _log = file_text_open_write(GNX_LOG);
    file_text_close(_log);
    _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] loader start\n");
    file_text_write_string(_log, "[GNX] mods_root=" + global.gnx_mods_root + "\n");
    file_text_close(_log);

    global.gnx_indexed_mods = [];
    global.gnx_loaded_mods = [];
    global.gnx_runtime_sprites = [];
    global.gnx_mod_errors = [];
    global.gnx_class_name_to_id = ds_map_create();
    global.gnx_cell_name_to_id = ds_map_create();
    if (!variable_global_exists("gnx_sprite_cache") || !ds_exists(global.gnx_sprite_cache, ds_type_map))
        global.gnx_sprite_cache = ds_map_create();

    if (!directory_exists(global.gnx_mods_root))
    {
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] mods/ folder not found, no mods loaded\n");
        file_text_close(_log);
        exit;
    }

    // Auto-discover mod folders: any direct subfolder of mods/ containing a manifest.json.
    // (Replaces the old mods/index.txt list so mod managers like G3M can drop/remove
    // mod folders via extra_files without maintaining a separate index file.)
    var _name = file_find_first(global.gnx_mods_root + "*", fa_directory);

    while (_name != "")
    {
        if (_name != "." && _name != ".."
            && directory_exists(global.gnx_mods_root + _name)
            && file_exists(global.gnx_mods_root + _name + "/manifest.json"))
        {
            array_push(global.gnx_indexed_mods, _name);
        }

        _name = file_find_next();
    }

    file_find_close();

    // Deterministic load order regardless of filesystem enumeration order
    array_sort(global.gnx_indexed_mods, true);

    for (var _mi = 0; _mi < array_length(global.gnx_indexed_mods); _mi++)
        scr_gnx_load_mod(global.gnx_indexed_mods[_mi]);

    scr_gnx_resolve_birth_classes();

    ds_map_destroy(global.gnx_class_name_to_id);
    ds_map_destroy(global.gnx_cell_name_to_id);

    scr_gnx_apply_unlocks();
    scr_gnx_register_goblin_sprites();
    _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] loader done\n");
    file_text_close(_log);

    if (array_length(global.gnx_mod_errors) > 0)
    {
        var _msg = "Mod loading problem(s):\n\n";
        for (var _ei = 0; _ei < array_length(global.gnx_mod_errors); _ei++)
            _msg += "- " + global.gnx_mod_errors[_ei] + "\n";
        _msg += "\nDetails in gnx_debug.txt.";
        show_message(_msg);
    }
}

/// @desc Second-pass resolution of birth_classes string refs.
/// Called after all mods are loaded, while gnx_class_name_to_id still exists.
/// Resolves "mod_folder.ClassName" strings to integer class_ids in-place.
function scr_gnx_resolve_birth_classes()
{
    var _key = ds_map_find_first(global.class_registry);
    repeat (ds_map_size(global.class_registry))
    {
        var _rc = ds_map_find_value(global.class_registry, _key);
        if (is_struct(_rc) && variable_struct_exists(_rc, "birth_classes"))
        {
            var _bc = _rc.birth_classes;
            var _bc_len = array_length(_bc);
            var _bc_out = [];
            for (var _bi = 0; _bi < _bc_len; _bi++)
            {
                var _bv = _bc[_bi];
                if (is_string(_bv))
                {
                    var _bm = ds_map_find_value(global.gnx_class_name_to_id, _bv);
                    array_push(_bc_out, (_bm != undefined) ? _bm : _bv);
                }
                else
                    array_push(_bc_out, _bv);
            }
            _rc.birth_classes = _bc_out;
        }
        _key = ds_map_find_next(global.class_registry, _key);
    }
}

function scr_gnx_apply_unlocks()
{
    var _n = array_length(global.gnx_registered_cells);
    
    for (var _i = 0; _i < _n; _i++)
    {
        var _entry = global.gnx_registered_cells[_i];
        var _h = _entry.h_type;
        var _cat = _entry.category;
        var _arr;
        
        if (_cat == "breed")
            _arr = global.unlock.breed;
        else if (_cat == "utility")
            _arr = global.unlock.utility;
        else if (_cat == "pleasure")
            _arr = global.unlock.pleasure;
        else
            continue;
        
        var _found = false;
        
        for (var _j = 0; _j < array_length(_arr); _j++)
        {
            if (_arr[_j] == _h)
            {
                _found = true;
                break;
            }
        }
        
        if (!_found)
            array_push(_arr, _h);
    }
}

function scr_gnx_migrate_unlocks()
{
    var _cats = ["breed", "utility", "pleasure"];
    var _ci = 0;
    repeat (3)
    {
        var _fname = _cats[_ci++];
        var _src = variable_struct_get(global.unlock, _fname);
        if (!is_array(_src))
            continue;
        var _out = [];
        var _si = 0;
        repeat (array_length(_src))
        {
            var _h = _src[_si++];
            if (ds_map_find_value(global.cell_registry, _h) != undefined)
                array_push(_out, _h);
        }
        variable_struct_set(global.unlock, _fname, _out);
    }
    scr_gnx_apply_unlocks();
}

function scr_gnx_cleanup_sprites()
{
    if (!variable_global_exists("gnx_runtime_sprites"))
        return;
    var _arr = global.gnx_runtime_sprites;
    var _n = array_length(_arr);
    for (var _i = 0; _i < _n; _i++)
    {
        if (sprite_exists(_arr[_i]))
            sprite_delete(_arr[_i]);
    }
    global.gnx_runtime_sprites = [];
}

function scr_gnx_load_mod(arg0)
{
    var _manifest_path = global.gnx_mods_root + arg0 + "/manifest.json";
    
    if (!file_exists(_manifest_path))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': manifest.json not found");
        exit;
    }

    var _f = file_text_open_read(_manifest_path);
    var _raw = "";

    while (!file_text_eof(_f))
        _raw += file_text_readln(_f);

    file_text_close(_f);

    var _manifest = undefined;
    try
    {
        _manifest = json_parse(_raw);
    }
    catch (_e)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': manifest.json invalid (" + string(_e.message) + ")");
        exit;
    }

    var _versions = variable_struct_exists(_manifest, "compatible_game_versions") ? _manifest.compatible_game_versions : [];
    var _game_ver = string(global.val.version);
    var _ok = false;

    for (var _i = 0; _i < array_length(_versions); _i++)
    {
        if (_versions[_i] == _game_ver)
        {
            _ok = true;
            break;
        }
    }

    if (!_ok)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': incompatible with game version " + _game_ver + " (compatible: " + string(_versions) + ")");
        exit;
    }
    
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] loading: " + string(_manifest.name) + " v" + string(_manifest.version) + "\n");
    file_text_close(_log);

    scr_gnx_init_mod_state(arg0, _manifest);

    if (variable_struct_exists(_manifest, "classes"))
        scr_gnx_load_classes(arg0, _manifest.classes);

    if (variable_struct_exists(_manifest, "cells"))
        scr_gnx_load_cells(arg0, _manifest.cells);

    if (is_array(global.gnx_loaded_mods))
        array_push(global.gnx_loaded_mods, arg0);
}

/// @desc Initialize or merge per-mod persistent state from manifest save_state block.
///       Called during mod load. If save already has data for this mod, merges new defaults.
/// @arg {string} arg0  mod folder name (unique key)
/// @arg {struct} arg1  parsed manifest
function scr_gnx_init_mod_state(arg0, arg1)
{
    var _mod_name = arg0;
    var _has_save_state = variable_struct_exists(arg1, "save_state");
    var _defaults = {};
    var _schema_ver = 0;

    if (_has_save_state)
    {
        var _ss = arg1.save_state;
        _schema_ver = variable_struct_exists(_ss, "version") ? _ss.version : 1;
        if (variable_struct_exists(_ss, "fields"))
            _defaults = _ss.fields;
    }

    // Check if save already has data for this mod (loaded from save file)
    var _existing = variable_struct_exists(global.val.gnx_mod_data, _mod_name)
        ? variable_struct_get(global.val.gnx_mod_data, _mod_name)
        : undefined;

    if (_existing == undefined)
    {
        // Fresh init: copy all defaults + set _version
        var _state = {};
        _state._version = _schema_ver;
        var _keys = variable_struct_get_names(_defaults);
        for (var _i = 0; _i < array_length(_keys); _i++)
            variable_struct_set(_state, _keys[_i], variable_struct_get(_defaults, _keys[_i]));
        variable_struct_set(global.val.gnx_mod_data, _mod_name, _state);
        _existing = _state;
    }
    else
    {
        // Merge: add any new default fields missing from saved data
        var _keys = variable_struct_get_names(_defaults);
        for (var _i = 0; _i < array_length(_keys); _i++)
        {
            var _k = _keys[_i];
            if (!variable_struct_exists(_existing, _k))
                variable_struct_set(_existing, _k, variable_struct_get(_defaults, _k));
        }
        // Bump schema version if manifest is newer
        var _saved_ver = variable_struct_exists(_existing, "_version") ? _existing._version : 0;
        if (_schema_ver > _saved_ver)
            _existing._version = _schema_ver;
    }

    // Runtime alias for fast access (not persisted)
    variable_struct_set(global.gnx_mod_state, _mod_name, _existing);

    var _log = file_text_open_append(GNX_LOG);
    var _n_keys = array_length(variable_struct_get_names(_existing));
    file_text_write_string(_log, "[GNX] mod_state init: " + _mod_name + " v" + string(_existing._version) + " keys=" + string(_n_keys) + "\n");
    file_text_close(_log);
}

/// @desc Get a value from a mod's persistent state. Returns undefined if mod or key not found.
/// @arg {string} arg0  mod folder name
/// @arg {string} arg1  key
function scr_gnx_get_state(arg0, arg1)
{
    if (!variable_struct_exists(global.gnx_mod_state, arg0))
        return undefined;
    var _state = variable_struct_get(global.gnx_mod_state, arg0);
    if (!variable_struct_exists(_state, arg1))
        return undefined;
    return variable_struct_get(_state, arg1);
}

/// @desc Set a value in a mod's persistent state. Creates the key if it doesn't exist.
///       Returns the previous value, or undefined if key was new.
/// @arg {string} arg0  mod folder name
/// @arg {string} arg1  key
/// @arg           arg2  value
function scr_gnx_set_state(arg0, arg1, arg2)
{
    if (!variable_struct_exists(global.gnx_mod_state, arg0))
    {
        // Mod has no state struct yet -- create one on the fly
        var _state = { _version: 0 };
        variable_struct_set(global.val.gnx_mod_data, arg0, _state);
        variable_struct_set(global.gnx_mod_state, arg0, _state);
    }
    var _state = variable_struct_get(global.gnx_mod_state, arg0);
    var _prev = variable_struct_exists(_state, arg1) ? variable_struct_get(_state, arg1) : undefined;
    variable_struct_set(_state, arg1, arg2);
    return _prev;
}

function scr_gnx_load_cells(arg0, arg1)
{
    var _path = global.gnx_mods_root + arg0 + "/" + arg1;
    
    if (!file_exists(_path))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': cells file '" + arg1 + "' not found");
        exit;
    }

    var _f = file_text_open_read(_path);
    var _raw = "";

    while (!file_text_eof(_f))
        _raw += file_text_readln(_f);

    file_text_close(_f);

    var _cells;
    try
    {
        _cells = json_parse(_raw);
    }
    catch (_e)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': " + arg1 + " invalid (" + string(_e.message) + ")");
        exit;
    }

    var _count = array_length(_cells);
    
    for (var _i = 0; _i < _count; _i++)
        scr_gnx_register_cell(_cells[_i], arg0);
    
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] registered " + string(_count) + " cell(s)\n");
    file_text_close(_log);
}

function scr_gnx_register_cell(arg0, arg1)
{
    var _h;
    if (variable_struct_exists(arg0, "h_type"))
        _h = arg0.h_type;
    else
    {
        var _cname = variable_struct_exists(arg0, "name") ? arg0.name : "";
        _h = gnx_hash_cell_id(arg1 + "." + _cname);
        while (ds_map_exists(global.cell_registry, _h))
            _h = 100 + ((_h - 100 + 1) mod 9900);
    }

    if (ds_map_find_value(global.cell_registry, _h) != undefined)
    {
        scr_gnx_patch_cell(_h, arg0, arg1);
        exit;
    }

    if (variable_struct_exists(arg0, "name"))
        ds_map_add(global.gnx_cell_name_to_id, arg1 + "." + arg0.name, _h);
    
    var _phys = arg0.physical;
    var _sprites_dict = variable_struct_exists(arg0, "sprites") ? arg0.sprites : undefined;
    var _base_dir = global.gnx_mods_root + arg1 + "/";
    var _char_row = variable_struct_exists(_phys, "character_row") ? _phys.character_row : 0;
    var _spr_row_pos = _h - _char_row - 1;
    var _raw_layers = _phys.layers;
    var _n_layers = array_length(_raw_layers);
    var _spr_slot = array_create(_n_layers);
    
    for (var _li = 0; _li < _n_layers; _li++)
    {
        var _rl = _raw_layers[_li];
        var _spr = gnx_resolve_layer_sprite(_rl[1], _sprites_dict, _base_dir);
        
        if (array_length(_rl) >= 5)
            _spr_slot[_li] = [_rl[0], _spr, _rl[2], _rl[3], _rl[4]];
        else
            _spr_slot[_li] = [_rl[0], _spr, _rl[2], _rl[3]];
    }
    
    var _scr_idle = gnx_resolve_script(_phys.scr_idle);
    var _raw_h = _phys.scr_h;
    var _n_h = array_length(_raw_h);
    var _scr_h = array_create(_n_h);
    
    for (var _si = 0; _si < _n_h; _si++)
        _scr_h[_si] = gnx_resolve_script(_raw_h[_si]);
    
    var _scr_draw = gnx_resolve_script(_phys.scr_draw);
    var _sp_spr_raw = variable_struct_exists(_phys, "sp_spr") ? _phys.sp_spr : -1;
    var _sp_spr = gnx_resolve_layer_sprite(_sp_spr_raw, _sprites_dict, _base_dir);
    var _spr_wall = -1;
    
    if (_sprites_dict != undefined && variable_struct_exists(_sprites_dict, "wall"))
        _spr_wall = gnx_resolve_sprite(_sprites_dict, "wall", _base_dir, -1);
    
    var _cell = 
    {
        h_type: _h,
        slot_type: variable_struct_exists(arg0, "slot_type") ? arg0.slot_type : 0,
        name: arg0.name,
        gnx_price: variable_struct_exists(arg0, "price") ? arg0.price : 100,
        gnx_spawn_info: variable_struct_exists(arg0, "spawn_info") ? arg0.spawn_info : -1,
        physical: 
        {
            allow_preg: _phys.allow_preg,
            max_mon_num: _phys.max_mon_num,
            anal: _phys.anal,
            spr_row_pos: _spr_row_pos,
            slot_dirt_init: _phys.slot_dirt_init,
            spr_slot_template: _spr_slot,
            scr_slot_template: 
            {
                idle: _scr_idle,
                h: _scr_h
            },
            scr_draw_special: _scr_draw,
            hand_x: _phys.hand_x,
            hand_y: _phys.hand_y,
            hand_xscale: _phys.hand_xscale,
            hand_angle: _phys.hand_angle,
            sp_spr: _sp_spr,
            sq_x: _phys.sq_x,
            sq_y: _phys.sq_y,
            sp_x: _phys.sp_x,
            sp_y: _phys.sp_y,
            sp_anim_x: _phys.sp_anim_x,
            sp_anim_y: _phys.sp_anim_y
        },
        gnx_spr_wall: _spr_wall,
        human_spr: 
        {
            mode: arg0.human_spr.mode,
            base_body: arg0.human_spr.base_body
        },
        mon_spr: gnx_resolve_mon_spr(variable_struct_exists(arg0, "mon_spr") ? arg0.mon_spr : undefined, _sprites_dict, _base_dir)
    };
    var _cp = _cell.physical;
    
    if (variable_struct_exists(_phys, "hand_frames"))
        _cp.hand_frames = _phys.hand_frames;
    
    if (variable_struct_exists(_phys, "sign_y_base"))
    {
        _cp.sign_y_base = _phys.sign_y_base;
        _cp.sign_y_jitter = variable_struct_exists(_phys, "sign_y_jitter") ? _phys.sign_y_jitter : 2;
    }
    
    if (variable_struct_exists(_phys, "milk_step"))
        _cp.milk_step = _phys.milk_step;
    
    if (variable_struct_exists(_phys, "drink_num"))
        _cp.drink_num = _phys.drink_num;
    
    if (variable_struct_exists(_phys, "mon_index"))
        _cp.mon_index = _phys.mon_index;
    
    if (variable_struct_exists(_phys, "blink_spr"))
        _cp.blink_spr = gnx_resolve_layer_sprite(_phys.blink_spr, _sprites_dict, _base_dir);
    
    if (variable_struct_exists(_phys, "anim_struct_overrides"))
        _cp.anim_struct_overrides = _phys.anim_struct_overrides;
    
    if (variable_struct_exists(_phys, "visual"))
        _cp.visual = _phys.visual;
    
    if (variable_struct_exists(_phys, "slot_front"))
        _cp.slot_front = gnx_resolve_layer_sprite(_phys.slot_front, _sprites_dict, _base_dir);
    
    if (variable_struct_exists(_phys, "sp_place_init"))
        _cp.sp_place_init = _phys.sp_place_init;
    
    if (variable_struct_exists(_phys, "set_timer"))
        _cp.set_timer = _phys.set_timer;
    
    if (variable_struct_exists(_phys, "slot_range"))
        _cp.slot_range = _phys.slot_range;
    
    if (variable_struct_exists(_phys, "slot_h"))
        _cp.slot_h = _phys.slot_h;
    
    if (variable_struct_exists(_phys, "scr_slot_step"))
        _cp.scr_slot_step = asset_get_index(_phys.scr_slot_step);
    
    if (variable_struct_exists(_phys, "scr_slot_base"))
        _cp.scr_slot_base = asset_get_index(_phys.scr_slot_base);
    
    if (variable_struct_exists(_phys, "candle_index"))
        _cp.candle_index = _phys.candle_index;
    
    if (variable_struct_exists(_phys, "milk_num"))
        _cp.milk_num = _phys.milk_num;
    
    if (variable_struct_exists(_phys, "clone_wait"))
        _cp.clone_wait = _phys.clone_wait;
    
    if (variable_struct_exists(_phys, "bar_glow_rep"))
        _cp.bar_glow_rep = _phys.bar_glow_rep;
    
    if (variable_struct_exists(_phys, "extra_spawn_part"))
        _cp.extra_spawn_part = _phys.extra_spawn_part;
    
    if (variable_struct_exists(_phys, "dirt_fix_inc"))
        _cp.dirt_fix_inc = _phys.dirt_fix_inc;
    
    if (variable_struct_exists(_phys, "death_fix_inc"))
        _cp.death_fix_inc = _phys.death_fix_inc;
    
    if (variable_struct_exists(_phys, "del_item_type"))
        _cp.del_item_type = _phys.del_item_type;
    
    if (variable_struct_exists(_phys, "required_class"))
    {
        _cp.required_class = _phys.required_class;
        if (is_array(_cp.required_class))
        {
            var _rc = _cp.required_class;
            var _rc_len = array_length(_rc);
            var _rc_out = [];
            var _ri = 0;
            repeat (_rc_len)
            {
                var _rv = _rc[_ri];
                var _rm = ds_map_find_value(global.gnx_class_name_to_id, _rv);
                array_push(_rc_out, (_rm != undefined) ? _rm : _rv);
                _ri++;
            }
            _cp.required_class = _rc_out;
        }
        else
        {
            var _rm = ds_map_find_value(global.gnx_class_name_to_id, _cp.required_class);
            if (_rm != undefined)
                _cp.required_class = _rm;
        }
    }

    if (variable_struct_exists(_phys, "range_draw_func"))
        _cp.range_draw_func = gnx_resolve_script(_phys.range_draw_func);

    if (variable_struct_exists(_phys, "scr_unoccupy"))
        _cp.scr_unoccupy = gnx_resolve_script(_phys.scr_unoccupy);

    ds_map_add(global.cell_registry, _h, _cell);
    var _log2 = file_text_open_append(GNX_LOG);
    file_text_write_string(_log2, "[GNX] cell sprites h=" + string(_h) + ":");
    
    for (var _di = 0; _di < array_length(_spr_slot); _di++)
        file_text_write_string(_log2, " [" + string(_di) + "]=" + string(_spr_slot[_di][1]));
    
    file_text_write_string(_log2, "\n");
    file_text_close(_log2);
    var _cat = arg0.category;
    
    if (_cat == "breed")
        array_push(global.breed_order, _h);
    else if (_cat == "utility")
        array_push(global.utility_order, _h);
    else if (_cat == "pleasure")
        array_push(global.pleasure_order, _h);
    
    array_push(global.gnx_registered_cells, 
    {
        h_type: _h,
        category: _cat
    });
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] cell OK: h=" + string(_h) + " name=" + string(arg0.name) + " cat=" + string(_cat) + "\n");
    file_text_close(_log);
}

function scr_gnx_patch_cell(arg0, arg1, arg2)
{
    var _cell = ds_map_find_value(global.cell_registry, arg0);
    
    if (_cell == undefined)
    {
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] patch h=" + string(arg0) + " not in registry, aborting\n");
        file_text_close(_log);
        exit;
    }
    
    var _base_dir = global.gnx_mods_root + arg2 + "/";
    var _sprites_dict = variable_struct_exists(arg1, "sprites") ? arg1.sprites : undefined;
    
    if (variable_struct_exists(arg1, "name"))
        _cell.name = arg1.name;
    
    if (variable_struct_exists(arg1, "price"))
        _cell.gnx_price = arg1.price;
    
    if (variable_struct_exists(arg1, "spawn_info"))
        _cell.gnx_spawn_info = arg1.spawn_info;
    
    if (variable_struct_exists(arg1, "slot_type"))
        _cell.slot_type = arg1.slot_type;
    
    if (variable_struct_exists(arg1, "human_spr"))
    {
        var _hs = arg1.human_spr;
        
        if (variable_struct_exists(_hs, "mode"))
            _cell.human_spr.mode = _hs.mode;
        
        if (variable_struct_exists(_hs, "base_body"))
            _cell.human_spr.base_body = _hs.base_body;
    }
    
    if (variable_struct_exists(arg1, "physical"))
    {
        var _phys = arg1.physical;
        var _cp = _cell.physical;
        
        if (variable_struct_exists(_phys, "allow_preg"))
            _cp.allow_preg = _phys.allow_preg;
        
        if (variable_struct_exists(_phys, "max_mon_num"))
            _cp.max_mon_num = _phys.max_mon_num;
        
        if (variable_struct_exists(_phys, "anal"))
            _cp.anal = _phys.anal;
        
        if (variable_struct_exists(_phys, "slot_dirt_init"))
            _cp.slot_dirt_init = _phys.slot_dirt_init;
        
        if (variable_struct_exists(_phys, "hand_x"))
            _cp.hand_x = _phys.hand_x;
        
        if (variable_struct_exists(_phys, "hand_y"))
            _cp.hand_y = _phys.hand_y;
        
        if (variable_struct_exists(_phys, "hand_xscale"))
            _cp.hand_xscale = _phys.hand_xscale;
        
        if (variable_struct_exists(_phys, "hand_angle"))
            _cp.hand_angle = _phys.hand_angle;
        
        if (variable_struct_exists(_phys, "hand_frames"))
            _cp.hand_frames = _phys.hand_frames;
        
        if (variable_struct_exists(_phys, "sq_x"))
            _cp.sq_x = _phys.sq_x;
        
        if (variable_struct_exists(_phys, "sq_y"))
            _cp.sq_y = _phys.sq_y;
        
        if (variable_struct_exists(_phys, "sp_x"))
            _cp.sp_x = _phys.sp_x;
        
        if (variable_struct_exists(_phys, "sp_y"))
            _cp.sp_y = _phys.sp_y;
        
        if (variable_struct_exists(_phys, "sp_anim_x"))
            _cp.sp_anim_x = _phys.sp_anim_x;
        
        if (variable_struct_exists(_phys, "sp_anim_y"))
            _cp.sp_anim_y = _phys.sp_anim_y;
        
        if (variable_struct_exists(_phys, "character_row"))
            _cp.spr_row_pos = arg0 - _phys.character_row - 1;
        
        if (variable_struct_exists(_phys, "sp_spr"))
            _cp.sp_spr = gnx_resolve_layer_sprite(_phys.sp_spr, _sprites_dict, _base_dir);
        
        if (variable_struct_exists(_phys, "layers"))
        {
            var _raw_layers = _phys.layers;
            var _n_layers = array_length(_raw_layers);
            var _spr_slot = array_create(_n_layers);
            
            for (var _li = 0; _li < _n_layers; _li++)
            {
                var _rl = _raw_layers[_li];
                var _spr = gnx_resolve_layer_sprite(_rl[1], _sprites_dict, _base_dir);
                
                if (array_length(_rl) >= 5)
                    _spr_slot[_li] = [_rl[0], _spr, _rl[2], _rl[3], _rl[4]];
                else
                    _spr_slot[_li] = [_rl[0], _spr, _rl[2], _rl[3]];
            }
            
            _cp.spr_slot_template = _spr_slot;
        }
        
        if (variable_struct_exists(_phys, "scr_idle"))
            _cp.scr_slot_template.idle = gnx_resolve_script(_phys.scr_idle);
        
        if (variable_struct_exists(_phys, "scr_h"))
        {
            var _raw_h = _phys.scr_h;
            var _n_h = array_length(_raw_h);
            var _scr_h = array_create(_n_h);
            
            for (var _si = 0; _si < _n_h; _si++)
                _scr_h[_si] = gnx_resolve_script(_raw_h[_si]);
            
            _cp.scr_slot_template.h = _scr_h;
        }
        
        if (variable_struct_exists(_phys, "scr_draw"))
            _cp.scr_draw_special = gnx_resolve_script(_phys.scr_draw);
        
        if (variable_struct_exists(_phys, "required_class"))
        {
            _cp.required_class = _phys.required_class;
            if (is_array(_cp.required_class))
            {
                var _rc = _cp.required_class;
                var _rc_len = array_length(_rc);
                var _rc_out = [];
                var _ri = 0;
                repeat (_rc_len)
                {
                    var _rv = _rc[_ri];
                    var _rm = ds_map_find_value(global.gnx_class_name_to_id, _rv);
                    array_push(_rc_out, (_rm != undefined) ? _rm : _rv);
                    _ri++;
                }
                _cp.required_class = _rc_out;
            }
            else
            {
                var _rm = ds_map_find_value(global.gnx_class_name_to_id, _cp.required_class);
                if (_rm != undefined)
                    _cp.required_class = _rm;
            }
        }

        if (variable_struct_exists(_phys, "range_draw_func"))
            _cp.range_draw_func = gnx_resolve_script(_phys.range_draw_func);

        if (variable_struct_exists(_phys, "scr_unoccupy"))
            _cp.scr_unoccupy = gnx_resolve_script(_phys.scr_unoccupy);
    }
    
    if (variable_struct_exists(arg1, "mon_spr"))
        _cell.mon_spr = gnx_resolve_mon_spr(arg1.mon_spr, _sprites_dict, _base_dir);
    
    if (variable_struct_exists(arg1, "mon_spr_hob"))
        _cell.mon_spr_hob = gnx_resolve_mon_spr(arg1.mon_spr_hob, _sprites_dict, _base_dir);
    
    if (variable_struct_exists(arg1, "mon_spr_ogr"))
        _cell.mon_spr_ogr = gnx_resolve_mon_spr(arg1.mon_spr_ogr, _sprites_dict, _base_dir);
    
    if (_sprites_dict != undefined && variable_struct_exists(_sprites_dict, "wall"))
        _cell.gnx_spr_wall = gnx_resolve_sprite(_sprites_dict, "wall", _base_dir, -1);
    
    _cell.gnx_patched = true;
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] patched h=" + string(arg0) + " by mod=" + string(arg2) + "\n");
    file_text_close(_log);
}

function gnx_resolve_mspr_spr(arg0, arg1, arg2)
{
    if (arg0 == undefined || arg0 == -1)
        return -1;
    
    return gnx_resolve_layer_sprite(arg0, arg1, arg2);
}

function gnx_resolve_mspr_pair(arg0, arg1, arg2)
{
    if (arg0 == undefined)
        return [-1, -1];
    
    if (is_struct(arg0) && variable_struct_exists(arg0, "alpha"))
    {
        var _a = gnx_resolve_layer_sprite(arg0.alpha, arg1, arg2);
        var _l = variable_struct_exists(arg0, "line") ? gnx_resolve_layer_sprite(arg0.line, arg1, arg2) : -1;
        return [_a, _l];
    }
    
    return [gnx_resolve_layer_sprite(arg0, arg1, arg2), -1];
}

function gnx_resolve_mspr_body_variants(arg0, arg1, arg2, arg3, arg4)
{
    var _vkeys = ["leg_any", "leg_1", "leg_2", "cow", "lilith"];
    var _bsuffs = ["_any", "_leg1", "_leg2", "_cow", "_lilith"];
    
    for (var _i = 0; _i < 5; _i++)
    {
        var _entry = (arg0 != undefined && variable_struct_exists(arg0, _vkeys[_i])) ? variable_struct_get(arg0, _vkeys[_i]) : undefined;
        var _pair = gnx_resolve_mspr_pair(_entry, arg1, arg2);
        variable_struct_set(arg3, arg4 + "_body_b" + _bsuffs[_i], _pair[0]);
        variable_struct_set(arg3, arg4 + "_body_l" + _bsuffs[_i], _pair[1]);
    }
}

function gnx_resolve_mspr_hand_variants(arg0, arg1, arg2, arg3, arg4)
{
    var _vkeys = ["leg_any", "leg_1", "leg_2", "cow"];
    var _bsuffs = ["_any", "_leg1", "_leg2", "_cow"];
    
    for (var _i = 0; _i < 4; _i++)
    {
        var _entry = (arg0 != undefined && variable_struct_exists(arg0, _vkeys[_i])) ? variable_struct_get(arg0, _vkeys[_i]) : undefined;
        var _pair = gnx_resolve_mspr_pair(_entry, arg1, arg2);
        variable_struct_set(arg3, arg4 + "_hand_b" + _bsuffs[_i], _pair[0]);
        variable_struct_set(arg3, arg4 + "_hand_l" + _bsuffs[_i], _pair[1]);
    }
}

function gnx_resolve_mspr_class_variants(arg0, arg1, arg2, arg3, arg4)
{
    var _ckeys = ["default", "cow", "nyx", "lilith", "morrigan", "cat"];
    var _csuffs = ["_def", "_cow", "_nyx", "_lilith", "_morrigan", "_cat"];
    
    for (var _i = 0; _i < 6; _i++)
    {
        var _val;
        
        if (arg0 == undefined)
            _val = undefined;
        else if (is_string(arg0))
            _val = (_i == 0) ? arg0 : undefined;
        else if (is_struct(arg0))
            _val = variable_struct_exists(arg0, _ckeys[_i]) ? variable_struct_get(arg0, _ckeys[_i]) : undefined;
        else
            _val = undefined;
        
        variable_struct_set(arg3, arg4 + _csuffs[_i], gnx_resolve_mspr_spr(_val, arg1, arg2));
    }
}

function gnx_resolve_mon_spr(arg0, arg1, arg2)
{
    if (arg0 == undefined || arg0 == -1)
        return undefined;
    
    var _out = {};
    var _s = variable_struct_exists(arg0, "start") ? arg0.start : undefined;
    var _lo = variable_struct_exists(arg0, "loop") ? arg0.loop : undefined;
    gnx_resolve_mspr_body_variants((_s != undefined && variable_struct_exists(_s, "body")) ? _s.body : undefined, arg1, arg2, _out, "s");
    var _hp = gnx_resolve_mspr_pair((_s != undefined && variable_struct_exists(_s, "hand")) ? _s.hand : undefined, arg1, arg2);
    _out.s_hand_b = _hp[0];
    _out.s_hand_l = _hp[1];
    _out.s_pen = gnx_resolve_mspr_spr((_s != undefined && variable_struct_exists(_s, "pen")) ? _s.pen : undefined, arg1, arg2);
    gnx_resolve_mspr_class_variants((_s != undefined && variable_struct_exists(_s, "touch")) ? _s.touch : undefined, arg1, arg2, _out, "s_touch");
    _out.s_hand_xscale_random = _s != undefined && variable_struct_exists(_s, "hand_xscale") && _s.hand_xscale == "random";
    var _head = (_lo != undefined && variable_struct_exists(_lo, "head")) ? _lo.head : undefined;
    
    if (is_array(_head) && array_length(_head) >= 1)
    {
        var _h0 = gnx_resolve_mspr_pair(_head[0], arg1, arg2);
        var _h1 = (array_length(_head) >= 2) ? gnx_resolve_mspr_pair(_head[1], arg1, arg2) : _h0;
        _out.lo_head_b_0 = _h0[0];
        _out.lo_head_l_0 = _h0[1];
        _out.lo_head_b_1 = _h1[0];
        _out.lo_head_l_1 = _h1[1];
    }
    else
    {
        var _hp2 = gnx_resolve_mspr_pair(_head, arg1, arg2);
        _out.lo_head_b_0 = _hp2[0];
        _out.lo_head_l_0 = _hp2[1];
        _out.lo_head_b_1 = _hp2[0];
        _out.lo_head_l_1 = _hp2[1];
    }
    
    gnx_resolve_mspr_body_variants((_lo != undefined && variable_struct_exists(_lo, "body")) ? _lo.body : undefined, arg1, arg2, _out, "lo");
    gnx_resolve_mspr_hand_variants((_lo != undefined && variable_struct_exists(_lo, "hand")) ? _lo.hand : undefined, arg1, arg2, _out, "lo");
    _out.lo_pen = gnx_resolve_mspr_spr((_lo != undefined && variable_struct_exists(_lo, "pen")) ? _lo.pen : undefined, arg1, arg2);
    gnx_resolve_mspr_class_variants((_lo != undefined && variable_struct_exists(_lo, "touch")) ? _lo.touch : undefined, arg1, arg2, _out, "lo_touch");
    gnx_resolve_mspr_class_variants((_lo != undefined && variable_struct_exists(_lo, "enter")) ? _lo.enter : undefined, arg1, arg2, _out, "lo_enter");
    var _ej = variable_struct_exists(arg0, "ej") ? arg0.ej : undefined;
    
    if (_ej != undefined)
    {
        gnx_resolve_mspr_body_variants(variable_struct_exists(_ej, "body") ? _ej.body : undefined, arg1, arg2, _out, "ej");
        gnx_resolve_mspr_hand_variants(variable_struct_exists(_ej, "hand") ? _ej.hand : undefined, arg1, arg2, _out, "ej");
        _out.ej_pen = gnx_resolve_mspr_spr(variable_struct_exists(_ej, "pen") ? _ej.pen : undefined, arg1, arg2);
        gnx_resolve_mspr_class_variants(variable_struct_exists(_ej, "touch") ? _ej.touch : undefined, arg1, arg2, _out, "ej_touch");
        gnx_resolve_mspr_class_variants(variable_struct_exists(_ej, "enter") ? _ej.enter : undefined, arg1, arg2, _out, "ej_enter");
        var _ej_head = variable_struct_exists(_ej, "head") ? _ej.head : undefined;
        
        if (is_array(_ej_head) && array_length(_ej_head) >= 1)
        {
            var _h0 = gnx_resolve_mspr_pair(_ej_head[0], arg1, arg2);
            var _h1 = (array_length(_ej_head) >= 2) ? gnx_resolve_mspr_pair(_ej_head[1], arg1, arg2) : _h0;
            _out.ej_head_b_0 = _h0[0];
            _out.ej_head_l_0 = _h0[1];
            _out.ej_head_b_1 = _h1[0];
            _out.ej_head_l_1 = _h1[1];
        }
    }
    
    return _out;
}

function scr_gnx_register_goblin_sprites()
{
    var _gob = {};
    _gob.s_body_b_leg0 = spr_h_goblin_body_start_v1_alpha;
    _gob.s_body_b_leg1 = spr_h_goblin_body_start_v1_alpha;
    _gob.s_body_b_leg2 = spr_h_goblin_body_start_v2_alpha;
    _gob.s_body_b_cow = spr_h_goblin_body_start_cow_alpha;
    _gob.s_hand_b = spr_h_goblin_hand_start_alpha;
    _gob.s_pen = spr_h_goblin_pen_start;
    _gob.s_touch_def = spr_h_goblin_touch_start;
    _gob.s_touch_cow = spr_h_goblin_touch_start_cow;
    _gob.s_touch_nyx = spr_h_goblin_touch_start_nyx;
    _gob.s_touch_cat = spr_h_goblin_touch_start_cat;
    _gob.s_touch_morrigan = spr_h_goblin_touch_start_morrigan;
    _gob.s_touch_lilith = spr_h_goblin_touch_start_lilith;
    _gob.s_hand_xscale_random = true;
    _gob.lo_head_b_0 = spr_h_goblin_head_loop_d1_alpha;
    _gob.lo_head_b_1 = spr_h_goblin_head_loop_d2_alpha;
    _gob.lo_body_b_leg0 = spr_h_goblin_body_loop_v1_alpha;
    _gob.lo_body_b_leg1 = spr_h_goblin_body_loop_v1_alpha;
    _gob.lo_body_b_leg2 = spr_h_goblin_body_loop_v2_alpha;
    _gob.lo_body_b_cow = spr_h_goblin_body_loop_cow_alpha;
    _gob.lo_hand_b_leg0 = spr_h_goblin_hand_loop_v1_alpha;
    _gob.lo_hand_b_leg1 = spr_h_goblin_hand_loop_v1_alpha;
    _gob.lo_hand_b_leg2 = spr_h_goblin_hand_loop_v2_alpha;
    _gob.lo_hand_b_cow = spr_h_goblin_hand_loop_cow_alpha;
    _gob.lo_pen = spr_h_goblin_pen_loop;
    _gob.lo_touch_def = spr_h_goblin_touch_loop_v1;
    _gob.lo_touch_leg2 = spr_h_goblin_touch_loop_v2;
    _gob.lo_touch_cow = spr_h_goblin_touch_loop_cow;
    _gob.lo_touch_nyx = spr_h_goblin_touch_loop_nyx;
    _gob.lo_touch_morrigan = spr_h_goblin_touch_loop_morrigan;
    _gob.lo_touch_cat = spr_h_goblin_touch_loop_cat;
    _gob.lo_touch_lilith = spr_h_goblin_touch_loop_lilith;
    _gob.lo_enter_def = spr_h_goblin_enter_loop;
    _gob.lo_enter_cow = spr_h_goblin_enter_loop_cow;
    _gob.lo_enter_nyx = spr_h_goblin_enter_loop_nyx;
    _gob.lo_enter_morrigan = spr_h_goblin_enter_loop_morrigan;
    _gob.lo_enter_cat = spr_h_goblin_enter_loop_cat;
    _gob.lo_enter_lilith = spr_h_goblin_enter_loop_lilith;
    var _hob_def = {};
    _hob_def.s_body_b_leg1 = spr_h_hobgoblin_body_start_v1_alpha;
    _hob_def.s_body_b_leg2 = spr_h_hobgoblin_body_start_v2_alpha;
    _hob_def.s_body_b_leg0 = spr_h_hobgoblin_body_start_v3_alpha;
    _hob_def.s_body_b_cat = spr_h_hobgoblin_body_start_v3_alpha;
    _hob_def.lo_body_b_leg0 = spr_h_hobgoblin_body_loop_v3_alpha;
    _hob_def.s_hand_b = spr_h_hobgoblin_hand_start_d1_alpha;
    _hob_def.s_hand_b_cow = spr_h_hobgoblin_hand_start_cow_alpha;
    _hob_def.s_body_b_cow = spr_h_hobgoblin_body_start_cow_alpha;
    _hob_def.s_pen = spr_h_hobgoblin_pen_start;
    _hob_def.s_hand_xscale_random = true;
    _hob_def.lo_head_b_0 = spr_h_hobgoblin_head_loop_alpha;
    _hob_def.lo_head_b_1 = spr_h_hobgoblin_head_loop_alpha;
    _hob_def.lo_body_b_leg1 = spr_h_hobgoblin_body_loop_v1_alpha;
    _hob_def.lo_body_b_leg2 = spr_h_hobgoblin_body_loop_v2_alpha;
    _hob_def.lo_body_b_any = spr_h_hobgoblin_body_loop_v3_alpha;
    _hob_def.lo_body_b_cow = spr_h_hobgoblin_body_loop_cow_alpha;
    _hob_def.lo_body_b_cat = spr_h_hobgoblin_body_loop_v3_alpha;
    _hob_def.lo_hand_b_leg1 = spr_h_hobgoblin_hand_loop_v1_alpha;
    _hob_def.lo_hand_b_leg2 = spr_h_hobgoblin_hand_loop_v2_alpha;
    _hob_def.lo_hand_b_any = spr_h_hobgoblin_hand_loop_v1_alpha;
    _hob_def.lo_hand_b_cow = spr_h_hobgoblin_hand_loop_v1_d1_alpha;
    _hob_def.lo_hand_b_lilith = spr_h_hobgoblin_hand_loop_v1_d1_alpha;
    _hob_def.lo_pen = spr_h_hobgoblin_pen_loop;
    _hob_def.lo_touch_def = spr_h_hobgoblin_touch_loop;
    _hob_def.lo_touch_cow = spr_h_hobgoblin_touch_loop_cow;
    _hob_def.lo_touch_nyx = spr_h_hobgoblin_touch_loop_nyx;
    _hob_def.lo_touch_cat = spr_h_hobgoblin_touch_loop_cat;
    _hob_def.lo_touch_morrigan = spr_h_hobgoblin_touch_loop_morrigan;
    _hob_def.lo_touch_lilith = spr_h_hobgoblin_enter_loop_lilith;
    _hob_def.lo_enter_def = spr_h_hobgoblin_enter_loop;
    _hob_def.lo_enter_cow = spr_h_hobgoblin_enter_loop_cow;
    _hob_def.lo_enter_nyx = spr_h_hobgoblin_enter_loop_nyx;
    _hob_def.lo_enter_cat = spr_h_hobgoblin_enter_loop_cat;
    _hob_def.lo_enter_morrigan = spr_h_hobgoblin_enter_loop_morrigan;
    _hob_def.lo_enter_lilith = spr_h_hobgoblin_enter_loop_lilith;
    var _hob_wall = {};
    _hob_wall.ej_body_b_any = spr_h_hobgoblin_body_ej_alpha;
    _hob_wall.ej_hand_b_leg1 = spr_h_hobgoblin_hand_loop_v1_alpha;
    _hob_wall.ej_hand_b_leg2 = spr_h_hobgoblin_hand_loop_v2_alpha;
    _hob_wall.ej_hand_b_any = spr_h_hobgoblin_hand_loop_v1_alpha;
    _hob_wall.ej_hand_b_cow = spr_h_hobgoblin_hand_loop_v1_d1_alpha;
    _hob_wall.ej_hand_b_lilith = spr_h_hobgoblin_hand_loop_v1_d1_alpha;
    _hob_wall.ej_pen = spr_h_hobgoblin_pen_loop;
    _hob_wall.ej_touch_def = spr_h_hobgoblin_touch_loop;
    _hob_wall.ej_touch_cow = spr_h_hobgoblin_touch_loop_cow;
    _hob_wall.ej_touch_nyx = spr_h_hobgoblin_touch_loop_nyx;
    _hob_wall.ej_touch_cat = spr_h_hobgoblin_touch_loop_cat;
    _hob_wall.ej_touch_morrigan = spr_h_hobgoblin_touch_loop_morrigan;
    _hob_wall.ej_touch_lilith = spr_h_hobgoblin_enter_loop_lilith;
    _hob_wall.ej_enter_def = spr_h_hobgoblin_enter_loop;
    _hob_wall.ej_enter_cow = spr_h_hobgoblin_enter_loop_cow;
    _hob_wall.ej_enter_nyx = spr_h_hobgoblin_enter_loop_nyx;
    _hob_wall.ej_enter_cat = spr_h_hobgoblin_enter_loop_cat;
    _hob_wall.ej_enter_morrigan = spr_h_hobgoblin_enter_loop_morrigan;
    _hob_wall.ej_enter_lilith = spr_h_hobgoblin_enter_loop_lilith;
    var _hob_keys = variable_struct_get_names(_hob_def);
    var _ki = 0;
    
    repeat (array_length(_hob_keys))
    {
        variable_struct_set(_hob_wall, _hob_keys[_ki], variable_struct_get(_hob_def, _hob_keys[_ki]));
        _ki++;
    }
    
    var _hob_fp = {};
    var _hw_keys = variable_struct_get_names(_hob_wall);
    _ki = 0;
    
    repeat (array_length(_hw_keys))
    {
        variable_struct_set(_hob_fp, _hw_keys[_ki], variable_struct_get(_hob_wall, _hw_keys[_ki]));
        _ki++;
    }
    
    _hob_fp.lo_hand_xscale_random = true;
    _hob_fp.ej_hand_b_any = spr_h_hobgoblin_hand_ej_alpha;
    var _ogr = {};
    _ogr.s_body_b_leg1 = spr_h_ogre_body_start;
    _ogr.s_body_b_leg2 = spr_h_ogre_body_start;
    _ogr.s_body_b_any = spr_h_ogre_body_start_v3;
    _ogr.s_body_b_cow = spr_h_ogre_body_start_cow;
    _ogr.lo_body_b_leg1 = spr_h_ogre_body_loop;
    _ogr.lo_body_b_leg2 = spr_h_ogre_body_loop;
    _ogr.lo_body_b_any = spr_h_ogre_body_loop_v3;
    _ogr.lo_body_b_cow = spr_h_ogre_body_loop_cow;
    _ogr.lo_body_b_lilith = spr_h_ogre_body_loop_lilith;
    var _gob_gb1 = {};
    _gob_gb1.lo_body_b_leg0 = spr_h_goblin_gb_1_v3_loop_alpha;
    _gob_gb1.lo_body_b_leg1 = spr_h_goblin_gb_1_loop_alpha;
    _gob_gb1.lo_body_b_leg2 = spr_h_goblin_gb_1_loop_alpha;
    _gob_gb1.lo_body_b_cow = spr_h_goblin_gb_1_cow_loop_alpha;
    _gob_gb1.lo_body_b_lilith = spr_h_goblin_gb_1_lilith_loop_alpha;
    _gob_gb1.s_body_b_leg0 = spr_h_goblin_gb_1_v3_loop_alpha;
    _gob_gb1.s_body_b_leg1 = spr_h_goblin_gb_1_loop_alpha;
    _gob_gb1.s_body_b_leg2 = spr_h_goblin_gb_1_loop_alpha;
    _gob_gb1.s_body_b_cow = spr_h_goblin_gb_1_cow_loop_alpha;
    _gob_gb1.s_body_b_lilith = spr_h_goblin_gb_1_lilith_loop_alpha;
    var _hob_gb1 = {};
    _hob_gb1.lo_body_b_leg0 = spr_h_hobgoblin_gb_1_v3_loop_alpha;
    _hob_gb1.lo_body_b_leg1 = spr_h_hobgoblin_gb_1_loop_alpha;
    _hob_gb1.lo_body_b_leg2 = spr_h_hobgoblin_gb_1_loop_alpha;
    _hob_gb1.lo_body_b_lilith = spr_h_hobgoblin_gb_1_lilith_loop_alpha;
    _hob_gb1.s_body_b_leg0 = spr_h_hobgoblin_gb_1_v3_loop_alpha;
    _hob_gb1.s_body_b_leg1 = spr_h_hobgoblin_gb_1_loop_alpha;
    _hob_gb1.s_body_b_leg2 = spr_h_hobgoblin_gb_1_loop_alpha;
    _hob_gb1.s_body_b_lilith = spr_h_hobgoblin_gb_1_lilith_loop_alpha;
    var _gob_gb2 = {};
    _gob_gb2.lo_body_b_leg0 = spr_h_goblin_gb_2_v3_loop_alpha;
    _gob_gb2.lo_body_b_leg1 = spr_h_goblin_gb_2_loop_alpha;
    _gob_gb2.lo_body_b_leg2 = spr_h_goblin_gb_2_loop_alpha;
    _gob_gb2.lo_body_b_cow = spr_h_goblin_gb_2_cow_loop_alpha;
    _gob_gb2.lo_enter_def = spr_h_goblin_gb_2_loop_enter;
    _gob_gb2.lo_enter_cow = spr_h_goblin_gb_2_loop_enter_cow;
    _gob_gb2.lo_enter_nyx = spr_h_goblin_gb_2_loop_enter_nyx;
    _gob_gb2.lo_enter_lilith = spr_h_goblin_gb_2_loop_enter_lilith;
    _gob_gb2.lo_enter_morrigan = spr_h_goblin_gb_2_loop_enter_morrigan;
    _gob_gb2.lo_enter_cat = spr_h_goblin_gb_2_loop_enter_cat;
    _gob_gb2.s_body_b_leg0 = spr_h_goblin_gb_2_v3_loop_alpha;
    _gob_gb2.s_body_b_leg1 = spr_h_goblin_gb_2_loop_alpha;
    _gob_gb2.s_body_b_leg2 = spr_h_goblin_gb_2_loop_alpha;
    _gob_gb2.s_body_b_cow = spr_h_goblin_gb_2_cow_loop_alpha;
    var _gob_gb3 = {};
    _gob_gb3.lo_body_b_any = spr_h_goblin_gb_3_loop_body_alpha;
    _gob_gb3.lo_hand_b_any = spr_h_goblin_gb_3_loop_hand_alpha;
    _gob_gb3.lo_hand_b_cow = spr_h_goblin_gb_3_cow_loop_hand_alpha;
    _gob_gb3.lo_hand_b_lilith = spr_h_goblin_gb_3_lilith_loop_hand_alpha;
    _gob_gb3.lo_enter_def = spr_h_goblin_gb_3_loop_enter;
    _gob_gb3.lo_enter_cow = spr_h_goblin_gb_3_cow_loop_enter;
    _gob_gb3.lo_enter_nyx = spr_h_goblin_gb_3_nyx_loop_enter;
    _gob_gb3.lo_enter_cat = spr_h_goblin_gb_3_cat_loop_enter;
    _gob_gb3.lo_enter_morrigan = spr_h_goblin_gb_3_morrigan_loop_enter;
    _gob_gb3.lo_enter_lilith = spr_h_goblin_gb_3_lilith_loop_enter;
    _gob_gb3.s_body_b_any = spr_h_goblin_gb_3_loop_body_alpha;
    _gob_gb3.s_hand_b_any = spr_h_goblin_gb_3_loop_hand_alpha;
    var _hob_gb3 = {};
    _hob_gb3.lo_body_b_any = spr_h_hobgoblin_gb_3_loop_body_alpha;
    _hob_gb3.lo_hand_b_any = spr_h_hobgoblin_gb_3_loop_hand_alpha;
    _hob_gb3.lo_hand_b_cow = spr_h_hobgoblin_gb_3_cow_loop_hand_alpha;
    _hob_gb3.lo_hand_b_lilith = spr_h_hobgoblin_gb_3_lilith_loop_hand_alpha;
    _hob_gb3.lo_enter_def = spr_h_hobgoblin_gb_3_loop_enter;
    _hob_gb3.lo_enter_cow = spr_h_hobgoblin_gb_3_cow_loop_enter;
    _hob_gb3.lo_enter_cat = spr_h_hobgoblin_gb_3_cat_loop_enter;
    _hob_gb3.lo_enter_nyx = spr_h_hobgoblin_gb_3_nyx_loop_enter;
    _hob_gb3.lo_enter_morrigan = spr_h_hobgoblin_gb_3_morrigan_loop_enter;
    _hob_gb3.s_body_b_any = spr_h_hobgoblin_gb_3_loop_body_alpha;
    _hob_gb3.s_hand_b_any = spr_h_hobgoblin_gb_3_loop_hand_alpha;
    // Fixed-sprite cells: body_b_any only, no head/hand/linework.
    // GNX pre-switch sets body_b correctly; vanilla switch re-sets same sprite + touch (harmless).
    var _dairy_gob = {};
    _dairy_gob.s_body_b_any = spr_h_goblin_dairy_loop_alpha;
    _dairy_gob.lo_body_b_any = spr_h_goblin_dairy_loop_alpha;
    _dairy_gob.ej_body_b_any = spr_h_goblin_dairy_loop_alpha;
    var _all_cells = [[1, _gob, _hob_wall, _ogr], [2, _gob, _hob_wall, _ogr], [7, _gob, _hob_wall, _ogr], [8, _gob, _hob_wall, _ogr], [9, _gob, _hob_def, _ogr], [13, _gob, _hob_def, _ogr], [14, _gob, _hob_def, _ogr], [3, _gob, _hob_def, _ogr], [6, _gob, _hob_def, _ogr], [15, _gob, _hob_fp, _ogr], [4, _gob, _hob_def, _ogr], [5, _gob, _hob_def, _ogr], [10, _gob, _hob_def, _ogr], [11, _gob, _hob_def, _ogr], [12, _gob, _hob_def, _ogr], [18, _gob_gb1, _hob_gb1, _ogr], [19, _gob_gb2, _hob_def, _ogr], [20, _gob, _hob_def, _ogr], [21, _gob, _hob_def, _ogr], [22, _gob, _hob_def, _ogr], [23, _gob_gb3, _hob_gb3, _ogr], [36, _dairy_gob, -1, -1], [37, _gob, _hob_def, _ogr], [38, _gob, _hob_def, _ogr], [39, _gob, _hob_def, _ogr], [40, _gob, _hob_def, _ogr], [41, _gob, _hob_def, _ogr], [42, _gob, _hob_def, _ogr], [17, _gob, _hob_def, _ogr], [24, _gob, _hob_def, _ogr], [25, _gob, _hob_def, _ogr], [27, _gob, _hob_def, _ogr], [28, _gob, _hob_def, _ogr], [29, _gob, _hob_def, _ogr], [30, _gob, _hob_def, _ogr], [31, _gob, _hob_def, _ogr], [32, _gob, _hob_def, _ogr], [33, _gob, _hob_def, _ogr], [34, _gob, _hob_def, _ogr]];
    var _i = 0;
    
    repeat (array_length(_all_cells))
    {
        var _entry = _all_cells[_i];
        var _ht = _entry[0];
        
        if (ds_map_exists(global.cell_registry, _ht))
        {
            var _cell = ds_map_find_value(global.cell_registry, _ht);
            
            if (!variable_struct_exists(_cell, "mon_spr") || _cell.mon_spr == undefined)
                _cell.mon_spr = _entry[1];
            
            if (!variable_struct_exists(_cell, "mon_spr_hob") || _cell.mon_spr_hob == undefined)
                _cell.mon_spr_hob = _entry[2];
            
            if (!variable_struct_exists(_cell, "mon_spr_ogr") || _cell.mon_spr_ogr == undefined)
                _cell.mon_spr_ogr = _entry[3];
        }
        
        _i++;
    }
    
    if (ds_map_exists(global.cell_registry, 18))
        ds_map_find_value(global.cell_registry, 18).placement1_body_skip = true;
}

function gnx_pool_add(arg0, arg1, arg2, arg3, arg4, arg5)
{
    var _key = (arg0 * 100) + arg1;
    var _pool;
    
    if (ds_map_exists(global.gnx_encounter_pools, _key))
    {
        _pool = ds_map_find_value(global.gnx_encounter_pools, _key);
    }
    else
    {
        _pool = ds_list_create();
        ds_map_add(global.gnx_encounter_pools, _key, _pool);
    }
    
    ds_list_add(_pool, 
    {
        class_id: arg2,
        weight: arg3,
        min_lvl: arg4,
        max_lvl: arg5
    });
}

function gnx_pool_pick(arg0, arg1)
{
    var _key = (arg0 * 100) + arg1;
    
    if (!ds_map_exists(global.gnx_encounter_pools, _key))
    {
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] pool_pick: no pool stage=" + string(arg0) + " lvl=" + string(arg1) + "\n");
        file_text_close(_log);
        return 
        {
            class_id: 0,
            lvl: 0
        };
    }
    
    var _pool = ds_map_find_value(global.gnx_encounter_pools, _key);
    var _count = ds_list_size(_pool);
    var _total = 0;
    var _i = 0;
    
    repeat (_count)
    {
        _total += ds_list_find_value(_pool, _i).weight;
        _i++;
    }
    
    var _roll = irandom_range(1, _total);
    var _cum = 0;
    var _entry = ds_list_find_value(_pool, 0);
    _i = 0;
    
    repeat (_count)
    {
        _entry = ds_list_find_value(_pool, _i);
        _cum += _entry.weight;
        
        if (_roll <= _cum)
            break;
        
        _i++;
    }
    
    var _lvl = irandom_range(_entry.min_lvl, _entry.max_lvl);
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] pool_pick stage=" + string(arg0) + " lvl=" + string(arg1) + " roll=" + string(_roll) + "/" + string(_total) + " class=" + string(_entry.class_id) + " picked_lvl=" + string(_lvl) + "\n");
    file_text_close(_log);
    return 
    {
        class_id: _entry.class_id,
        lvl: _lvl
    };
}

function scr_gnx_init_encounter_pools()
{
    gnx_pool_add(0, 1, 0, 50, 1, 2);
    gnx_pool_add(0, 1, 4, 50, 0, 0);
    gnx_pool_add(0, 2, 0, 30, 1, 2);
    gnx_pool_add(0, 2, 4, 50, 0, 1);
    gnx_pool_add(0, 2, 2, 20, 0, 1);
    gnx_pool_add(1, 0, 0, 35, 0, 1);
    gnx_pool_add(1, 0, 6, 65, 0, 1);
    gnx_pool_add(1, 1, 2, 50, 0, 0);
    gnx_pool_add(1, 1, 6, 50, 0, 1);
    gnx_pool_add(1, 2, 6, 30, 2, 3);
    gnx_pool_add(1, 2, 2, 30, 2, 3);
    gnx_pool_add(1, 2, 7, 40, 1, 2);
    gnx_pool_add(2, 0, 1, 50, 0, 1);
    gnx_pool_add(2, 0, 2, 50, 1, 2);
    gnx_pool_add(2, 1, 3, 65, 0, 1);
    gnx_pool_add(2, 1, 1, 35, 1, 2);
    gnx_pool_add(2, 2, 5, 30, 0, 1);
    gnx_pool_add(2, 2, 3, 30, 1, 2);
    gnx_pool_add(2, 2, 1, 40, 2, 3);
    gnx_pool_add(3, 0, 0, 25, 1, 3);
    gnx_pool_add(3, 0, 1, 25, 1, 3);
    gnx_pool_add(3, 0, 2, 25, 1, 3);
    gnx_pool_add(3, 0, 3, 25, 1, 3);
    gnx_pool_add(3, 1, 4, 50, 2, 4);
    gnx_pool_add(3, 1, 5, 50, 2, 4);
    gnx_pool_add(3, 2, 0, 17, 3, 4);
    gnx_pool_add(3, 2, 1, 17, 3, 4);
    gnx_pool_add(3, 2, 2, 17, 3, 4);
    gnx_pool_add(3, 2, 3, 17, 3, 4);
    gnx_pool_add(3, 2, 4, 16, 3, 4);
    gnx_pool_add(3, 2, 5, 16, 3, 4);
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] encounter pools initialized\n");
    file_text_close(_log);
}

function gnx_resolve_class_leg_variant(arg0, arg1, arg2, arg3)
{
    if (arg0 == undefined)
        return undefined;
    
    var _out = 
    {
        hair: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "hair") ? arg0.hair : -1, arg1, arg2),
        head: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "head") ? arg0.head : -1, arg1, arg2),
        breast: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "breast") ? arg0.breast : -1, arg1, arg2),
        leg: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "leg") ? arg0.leg : -1, arg1, arg2),
        leg_part: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "leg_part") ? arg0.leg_part : -1, arg1, arg2)
    };
    
    if (arg3)
        _out.hand = gnx_resolve_layer_sprite(variable_struct_exists(arg0, "hand") ? arg0.hand : -1, arg1, arg2);
    
    return _out;
}

function gnx_resolve_class_phase(arg0, arg1, arg2, arg3)
{
    if (arg0 == undefined)
        return undefined;
    
    var _out = {};
    var _keys = ["leg_1", "leg_2", "leg_0", "leg_any"];
    var _i = 0;
    
    repeat (array_length(_keys))
    {
        var _k = _keys[_i++];
        
        if (variable_struct_exists(arg0, _k))
            variable_struct_set(_out, _k, gnx_resolve_class_leg_variant(variable_struct_get(arg0, _k), arg1, arg2, arg3));
    }
    
    if (variable_struct_exists(arg0, "cape"))
        _out.cape = gnx_resolve_layer_sprite(arg0.cape, arg1, arg2);
    
    return _out;
}

function gnx_resolve_class_big_phase(arg0, arg1, arg2)
{
    if (arg0 == undefined)
        return undefined;
    
    var _out = 
    {
        head: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "head") ? arg0.head : -1, arg1, arg2),
        breast: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "breast") ? arg0.breast : -1, arg1, arg2)
    };
    
    if (variable_struct_exists(arg0, "hair"))
        _out.hair = gnx_resolve_layer_sprite(arg0.hair, arg1, arg2);
    
    var _lkeys = ["leg_1", "leg_2", "leg_any"];
    var _i = 0;
    
    repeat (array_length(_lkeys))
    {
        var _k = _lkeys[_i++];
        
        if (variable_struct_exists(arg0, _k))
            variable_struct_set(_out, _k, gnx_resolve_layer_sprite(variable_struct_get(arg0, _k), arg1, arg2));
    }
    
    return _out;
}

function gnx_resolve_special_phase(arg0, arg1, arg2)
{
    if (arg0 == undefined)
        return undefined;
    
    var _out = 
    {
        spr_array: [],
        spr_c_array: []
    };
    
    if (variable_struct_exists(arg0, "spr_array"))
    {
        var _arr = arg0.spr_array;
        var _i = 0;
        
        repeat (array_length(_arr))
            array_push(_out.spr_array, gnx_resolve_layer_sprite(_arr[_i++], arg1, arg2));
    }
    
    if (variable_struct_exists(arg0, "spr_c_array"))
    {
        var _arr = arg0.spr_c_array;
        var _i = 0;
        
        repeat (array_length(_arr))
            array_push(_out.spr_c_array, gnx_resolve_layer_sprite(_arr[_i++], arg1, arg2));
    }
    
    return _out;
}

function gnx_hash_class_id(arg0, arg1)
{
    // arg0 = mod_name (folder), arg1 = class_name
    // Returns a stable class_id in [14, 9999] via djb2 hash, probing on collision.
    var _str = arg0 + "." + arg1;
    var _len = string_length(_str);
    var _h = 5381;
    for (var _i = 1; _i <= _len; _i++)
        _h = ((_h * 33) + ord(string_char_at(_str, _i))) & 0xFFFFFF;
    var _id = 14 + (_h mod 9986);
    while (ds_map_exists(global.class_registry, _id))
    {
        _id++;
        if (_id > 9999) _id = 14;
    }
    return _id;
}

function gnx_hash_cell_id(arg0)
{
    var _h = 5381;
    var _len = string_length(arg0);
    var _i = 1;
    repeat (_len)
    {
        _h = ((_h * 33) + ord(string_char_at(arg0, _i))) & 0xFFFFFF;
        _i++;
    }
    return 100 + (_h mod 9900);
}

function gnx_resolve_class(arg0, arg1)
{
    var _base_dir = global.gnx_mods_root + arg1 + "/";
    var _sprites = variable_struct_exists(arg0, "sprites") ? arg0.sprites : {};
    var _class_name = variable_struct_exists(arg0, "name") ? arg0.name : "UNKNOWN";
    var _allow_override = variable_struct_exists(arg0, "override") && arg0.override;
    var _class_id;
    if (_allow_override && variable_struct_exists(arg0, "class_id"))
        _class_id = arg0.class_id;
    else
        _class_id = gnx_hash_class_id(arg1, _class_name);
    ds_map_add(global.gnx_class_name_to_id, arg1 + "." + _class_name, _class_id);

    if (ds_map_exists(global.class_registry, _class_id) && !_allow_override)
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] class_id " + string(_class_id) + " hash collision (probe failed) — skipped\n");
        file_text_close(_log);
        exit;
    }

    if (_allow_override)
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] class_id " + string(_class_id) + " override\n");
        file_text_close(_log);
    }

    var _rclass = 
    {
        name: variable_struct_exists(arg0, "name") ? arg0.name : "UNKNOWN",
        is_special: variable_struct_exists(arg0, "is_special") ? arg0.is_special : false,
        has_hair: variable_struct_exists(arg0, "has_hair") ? arg0.has_hair : true,
        fap_mul: variable_struct_exists(arg0, "fap_mul") ? arg0.fap_mul : 1,
        bap_mul: variable_struct_exists(arg0, "bap_mul") ? arg0.bap_mul : 0,
        preg_c_override: variable_struct_exists(arg0, "preg_c_override") ? arg0.preg_c_override : -1,
        hand_color: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "hand_color") ? arg0.hand_color : -1, _sprites, _base_dir),
        icon_spr: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "icon") ? arg0.icon : -1, _sprites, _base_dir),
        icon_hair_spr: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "icon_hair") ? arg0.icon_hair : -1, _sprites, _base_dir),
        carry_head_spr: gnx_resolve_layer_sprite("gnx:carry_head", _sprites, _base_dir),
        carry_hair_spr: gnx_resolve_layer_sprite("gnx:carry_hair", _sprites, _base_dir)
    };
    var _log = file_text_open_append(GNX_LOG);
    var _ispr = _rclass.icon_spr;
    file_text_write_string(_log, "[GNX] class=" + string(_class_id) + " icon_spr=" + string(_ispr) + "\n");
    
    if (_ispr != -1)
        file_text_write_string(_log, "  mod  icon: xo=" + string(sprite_get_xoffset(_ispr)) + " yo=" + string(sprite_get_yoffset(_ispr)) + " w=" + string(sprite_get_width(_ispr)) + " h=" + string(sprite_get_height(_ispr)) + "\n");
    
    var _ref = spr_unit_icon_head;
    file_text_write_string(_log, "  vanilla icon (class 0 frame 0): xo=" + string(sprite_get_xoffset(_ref)) + " yo=" + string(sprite_get_yoffset(_ref)) + " w=" + string(sprite_get_width(_ref)) + " h=" + string(sprite_get_height(_ref)) + "\n");
    file_text_close(_log);
    
    if (variable_struct_exists(arg0, "clothing_standard"))
    {
        var _cs_def = arg0.clothing_standard;
        var _cs = {};
        var _sp = ["phase_1", "phase_2"];
        var _si = 0;
        
        repeat (array_length(_sp))
        {
            var _sk = _sp[_si++];
            
            if (variable_struct_exists(_cs_def, _sk))
                variable_struct_set(_cs, _sk, _rclass.is_special ? gnx_resolve_special_phase(variable_struct_get(_cs_def, _sk), _sprites, _base_dir) : gnx_resolve_class_phase(variable_struct_get(_cs_def, _sk), _sprites, _base_dir, false));
        }
        
        _rclass.clothing_standard = _cs;
    }
    
    if (variable_struct_exists(arg0, "clothing_big"))
    {
        var _cb_def = arg0.clothing_big;
        var _cb = {};
        
        if (_rclass.is_special)
        {
            var _bps = ["phase_0", "phase_1", "phase_2"];
            var _bi = 0;
            
            repeat (array_length(_bps))
            {
                var _bk = _bps[_bi++];
                
                if (variable_struct_exists(_cb_def, _bk))
                    variable_struct_set(_cb, _bk, gnx_resolve_special_phase(variable_struct_get(_cb_def, _bk), _sprites, _base_dir));
            }
        }
        else
        {
            var _bp = ["start", "idle", "loop"];
            var _bi = 0;
            
            repeat (array_length(_bp))
            {
                var _bk = _bp[_bi++];
                
                if (variable_struct_exists(_cb_def, _bk))
                    variable_struct_set(_cb, _bk, gnx_resolve_class_big_phase(variable_struct_get(_cb_def, _bk), _sprites, _base_dir));
            }
        }
        
        _rclass.clothing_big = _cb;
    }
    
    if (variable_struct_exists(arg0, "clothing_tent"))
    {
        var _ct_def = arg0.clothing_tent;
        var _ct = {};
        var _tp = ["phase_1", "phase_2", "phase_4"];
        var _ti = 0;
        
        repeat (array_length(_tp))
        {
            var _tk = _tp[_ti++];
            
            if (variable_struct_exists(_ct_def, _tk))
                variable_struct_set(_ct, _tk, _rclass.is_special ? gnx_resolve_special_phase(variable_struct_get(_ct_def, _tk), _sprites, _base_dir) : gnx_resolve_class_phase(variable_struct_get(_ct_def, _tk), _sprites, _base_dir, true));
        }
        
        _rclass.clothing_tent = _ct;
    }
    
    if (variable_struct_exists(arg0, "preg_mon_type_override"))
        _rclass.preg_mon_type_override = arg0.preg_mon_type_override;

    if (variable_struct_exists(arg0, "birth_classes"))
        _rclass.birth_classes = arg0.birth_classes;

    if (variable_struct_exists(arg0, "default_leg"))
        _rclass.default_leg = arg0.default_leg;

    if (variable_struct_exists(arg0, "trade_stage"))
    {
        var _ts = arg0.trade_stage;
        if (_ts >= 0 && _ts < array_length(global.gnx_trade_list))
            array_push(global.gnx_trade_list[_ts], _class_id);
    }

    if (variable_struct_exists(arg0, "raid_spawns"))
    {
        var _rs_arr = arg0.raid_spawns;
        var _rs_len = array_length(_rs_arr);
        var _ri = 0;
        
        repeat (_rs_len)
        {
            var _rs_e = _rs_arr[_ri++];
            var _rs_stage = _rs_e.stage;
            var _rs_level = _rs_e.level;
            
            if (_rs_level != 0)
            {
                var _rs_w = variable_struct_exists(_rs_e, "weight") ? _rs_e.weight : 10;
                var _rs_min = variable_struct_exists(_rs_e, "min_lvl") ? _rs_e.min_lvl : 0;
                var _rs_max = variable_struct_exists(_rs_e, "max_lvl") ? _rs_e.max_lvl : 1;
                gnx_pool_add(_rs_stage, _rs_level, _class_id, _rs_w, _rs_min, _rs_max);
                _log = file_text_open_append(GNX_LOG);
                file_text_write_string(_log, "[GNX] raid_spawn class=" + string(_class_id) + " stage=" + string(_rs_stage) + " level=" + string(_rs_level) + " w=" + string(_rs_w) + " lvl=" + string(_rs_min) + "-" + string(_rs_max) + "\n");
                file_text_close(_log);
            }
            else
            {
                _log = file_text_open_append(GNX_LOG);
                file_text_write_string(_log, "[GNX] raid_spawn skipped level=0 class=" + string(_class_id) + " stage=" + string(_rs_stage) + "\n");
                file_text_close(_log);
            }
        }
    }

    if (ds_map_exists(global.class_registry, _class_id))
        ds_map_replace(global.class_registry, _class_id, _rclass);
    else
        ds_map_add(global.class_registry, _class_id, _rclass);
    
    _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] class " + string(_class_id) + " registered: " + string(variable_struct_exists(arg0, "name") ? arg0.name : "?") + "\n");
    file_text_close(_log);
}

function scr_gnx_load_classes(arg0, arg1)
{
    var _path = global.gnx_mods_root + arg0 + "/" + arg1;
    
    if (!file_exists(_path))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': classes file '" + arg1 + "' not found");
        exit;
    }

    var _f = file_text_open_read(_path);
    var _json = "";

    while (!file_text_eof(_f))
        _json += file_text_readln(_f);

    file_text_close(_f);
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] classes json len=" + string(string_length(_json)) + " head=" + string_copy(_json, 1, 80) + "\n");
    file_text_close(_log);

    var _defs;
    try
    {
        _defs = json_parse(_json);
    }
    catch (_e)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': " + arg1 + " invalid (" + string(_e.message) + ")");
        exit;
    }

    if (!is_array(_defs))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': " + arg1 + " is not a JSON array");
        exit;
    }
    
    var _i = 0;

    repeat (array_length(_defs))
        gnx_resolve_class(_defs[_i++], arg0);

    // Resolve birth_classes string refs after all classes are registered
    _i = 0;
    repeat (array_length(_defs))
    {
        var _def = _defs[_i++];
        if (variable_struct_exists(_def, "class_name") && variable_struct_exists(_def, "birth_classes"))
        {
            var _cname = _def.class_name;
            var _cid = global.gnx_class_name_to_id[? (arg0 + "." + _cname)];
            if (_cid != undefined)
            {
                var _creg = global.class_registry[? _cid];
                if (_creg != undefined && variable_struct_exists(_creg, "birth_classes"))
                {
                    var _bc = _creg.birth_classes;
                    if (is_array(_bc))
                    {
                        var _bc_len = array_length(_bc);
                        var _bc_out = [];
                        var _bi = 0;
                        repeat (_bc_len)
                        {
                            var _bv = _bc[_bi];
                            var _bm = ds_map_find_value(global.gnx_class_name_to_id, _bv);
                            array_push(_bc_out, (_bm != undefined) ? _bm : _bv);
                            _bi++;
                        }
                        _creg.birth_classes = _bc_out;
                    }
                }
            }
        }
    }
}

function scr_gnx_unoccupy_log()
{
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] scr_gnx_unoccupy_log slot h=" + string(slot_data.h_type) + "\n");
    file_text_close(_log);
}

function scr_gnx_spr_ok(arg0)
{
    if (arg0 == -1)
        return true;

    if (is_string(arg0) || is_undefined(arg0) || is_struct(arg0) || is_array(arg0))
        return false;

    return sprite_exists(arg0);
}

function scr_gnx_collect_bad_spr(arg0, arg1)
{
    var _bad = "";

    if (is_array(arg0))
    {
        for (var _i = 0; _i < array_length(arg0); _i++)
        {
            if (!scr_gnx_spr_ok(arg0[_i]))
                _bad += arg1 + "[" + string(_i) + "] ";
        }

        return _bad;
    }

    if (!is_struct(arg0))
    {
        if (!scr_gnx_spr_ok(arg0))
            _bad += arg1 + " ";

        return _bad;
    }

    var _names = variable_struct_get_names(arg0);

    for (var _i = 0; _i < array_length(_names); _i++)
    {
        var _v = variable_struct_get(arg0, _names[_i]);

        if (is_struct(_v) || is_array(_v))
            _bad += scr_gnx_collect_bad_spr(_v, arg1 + "." + _names[_i]);
        else if (!scr_gnx_spr_ok(_v))
            _bad += arg1 + "." + _names[_i] + " ";
    }

    return _bad;
}

function scr_gnx_test_suite()
{
    var _log = file_text_open_append(GNX_LOG);
    var _pass = 0;
    var _fail = 0;
    file_text_write_string(_log, "[GNX-TEST] ============================================================\n");
    file_text_write_string(_log, "[GNX-TEST] Suite start\n");
    var _ok = ds_exists(global.cell_registry, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T01 cell_registry is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T01 cell_registry not a map\n");
        _fail++;
    }
    
    _ok = ds_exists(global.class_registry, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T02 class_registry is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T02 class_registry not a map\n");
        _fail++;
    }
    
    _ok = ds_exists(global.bl_lookup, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T03 bl_lookup is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T03 bl_lookup not a map\n");
        _fail++;
    }
    
    _ok = ds_exists(global.gnx_encounter_pools, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T04 gnx_encounter_pools is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T04 gnx_encounter_pools not a map\n");
        _fail++;
    }
    
    _ok = ds_exists(global.front_row, ds_type_list);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T05 front_row is a list\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T05 front_row not a list\n");
        _fail++;
    }
    
    _ok = ds_exists(global.back_row, ds_type_list);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T06 back_row is a list\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T06 back_row not a list\n");
        _fail++;
    }
    
    var _n = ds_map_size(global.cell_registry);
    _ok = _n >= 39;
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T07 cell_registry size=" + string(_n) + " (>=39)\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T07 cell_registry size=" + string(_n) + " (<39)\n");
        _fail++;
    }
    
    _n = ds_map_size(global.class_registry);
    _ok = _n >= 14;

    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T08 class_registry size=" + string(_n) + " (>=14)\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T08 class_registry size=" + string(_n) + " (<14)\n");
        _fail++;
    }
    
    _ok = ds_exists(global.gnx_cov, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T09 gnx_cov is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T09 gnx_cov not a map\n");
        _fail++;
    }
    
    _n = ds_map_size(global.gnx_encounter_pools);
    _ok = _n > 0;
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T10 encounter_pools size=" + string(_n) + "\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T10 encounter_pools empty\n");
        _fail++;
    }
    
    var _exp = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30, 31, 32, 33, 34, 36, 37, 38, 39, 40, 41, 42];
    var _missing = "";
    var _i = 0;
    
    repeat (array_length(_exp))
    {
        var _ht = _exp[_i++];
        
        if (!ds_map_exists(global.cell_registry, _ht))
            _missing += (string(_ht) + " ");
    }
    
    if (_missing == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T11 all 39 cells registered\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T11 cells missing: " + _missing + "\n");
        _fail++;
    }
    
    var _missing_c = "";
    var _ci = 0;
    
    repeat (14)
    {
        if (!ds_map_exists(global.class_registry, _ci))
            _missing_c += (string(_ci) + " ");

        _ci++;
    }

    if (_missing_c == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T12 classes 0-13 all registered\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T12 classes missing: " + _missing_c + "\n");
        _fail++;
    }
    
    if (ds_map_exists(global.cell_registry, 1))
    {
        var _c1 = ds_map_find_value(global.cell_registry, 1);
        _ok = variable_struct_exists(_c1, "name") && variable_struct_exists(_c1, "physical") && variable_struct_exists(_c1, "human_spr");
        
        if (_ok)
        {
            var _p1 = _c1.physical;
            _ok = variable_struct_exists(_p1, "allow_preg") && variable_struct_exists(_p1, "max_mon_num") && variable_struct_exists(_p1, "anal") && variable_struct_exists(_p1, "spr_row_pos");
        }
        
        if (_ok)
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T13 WALL1 registry entry complete\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T13 WALL1 registry entry missing fields\n");
            _fail++;
        }
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T13 WALL1 (h=1) not in registry\n");
        _fail++;
    }
    
    if (ds_map_exists(global.cell_registry, 36))
    {
        var _c36 = ds_map_find_value(global.cell_registry, 36);
        _ok = variable_struct_exists(_c36, "human_spr") && _c36.human_spr.mode == "fixed";
        
        if (_ok)
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T14 DAIRY human_spr mode=fixed\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T14 DAIRY human_spr mode wrong\n");
            _fail++;
        }
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T14 DAIRY (h=36) not in registry\n");
        _fail++;
    }
    
    if (ds_map_exists(global.cell_registry, 27))
    {
        var _c27 = ds_map_find_value(global.cell_registry, 27);
        _ok = variable_struct_exists(_c27, "slot_type") && _c27.slot_type == 3;
        
        if (_ok)
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T15 BIND1 slot_type=3 (tent)\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T15 BIND1 slot_type wrong (got " + string(_c27.slot_type) + ")\n");
            _fail++;
        }
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T15 BIND1 (h=27) not in registry\n");
        _fail++;
    }
    
    // T16: any mod-added classes (id>=14) must be structurally complete.
    // Generic check - does not assume any specific mod class (e.g. test_mod's Elf).
    var _cls_n = ds_map_size(global.class_registry);
    var _bad_mod_classes = "";

    if (_cls_n > 14)
    {
        var _ck = ds_map_find_first(global.class_registry);

        while (_ck != undefined)
        {
            if (_ck >= 14)
            {
                var _mc = ds_map_find_value(global.class_registry, _ck);
                var _mc_ok = variable_struct_exists(_mc, "name") && variable_struct_exists(_mc, "is_special") && variable_struct_exists(_mc, "has_hair") && variable_struct_exists(_mc, "clothing_standard");

                if (!_mc_ok)
                    _bad_mod_classes += (string(_ck) + " ");
            }

            _ck = ds_map_find_next(global.class_registry, _ck);
        }
    }

    if (_bad_mod_classes == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T16 mod classes valid (extra=" + string(max(0, _cls_n - 14)) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T16 mod class entries invalid: " + _bad_mod_classes + "\n");
        _fail++;
    }
    
    // T17: gnx_registered_cells must be an array; any registered h_type must
    // resolve to a complete cell_registry entry. Empty array (no mods) is valid.
    _ok = is_array(global.gnx_registered_cells);
    var _rn = _ok ? array_length(global.gnx_registered_cells) : 0;
    var _bad_mod_cells = "";

    for (var _i = 0; _i < _rn; _i++)
    {
        var _rh = global.gnx_registered_cells[_i];
        var _rht = is_struct(_rh) ? _rh.h_type : _rh;
        var _rc = ds_map_find_value(global.cell_registry, _rht);
        var _rc_ok = (_rc != undefined) && variable_struct_exists(_rc, "name") && variable_struct_exists(_rc, "physical") && variable_struct_exists(_rc, "human_spr");

        if (!_rc_ok)
            _bad_mod_cells += (string(_rht) + " ");
    }

    if (_ok && _bad_mod_cells == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T17 gnx_registered_cells valid (len=" + string(_rn) + ")\n");
        _pass++;
    }
    else if (!_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T17 gnx_registered_cells not an array\n");
        _fail++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T17 gnx_registered_cells invalid entries: " + _bad_mod_cells + "\n");
        _fail++;
    }
    
    _ok = global.use_legacy_dispatch == false;
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T18 use_legacy_dispatch=false\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T18 use_legacy_dispatch=true (registry bypassed!)\n");
        _fail++;
    }

    // T19: gnx_mod_data exists as struct on global.val
    _ok = is_struct(global.val.gnx_mod_data);
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T19 gnx_mod_data is a struct\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T19 gnx_mod_data not a struct\n");
        _fail++;
    }

    // T20: set_state / get_state round-trip (synthetic key, no mod required)
    var _selftest_mod = "_gnx_selftest";
    scr_gnx_set_state(_selftest_mod, "_test_rt", 42);
    var _rt = scr_gnx_get_state(_selftest_mod, "_test_rt");
    _ok = (_rt == 42);
    // Also verify it landed in global.val (persistence path)
    if (_ok)
        _ok = variable_struct_get(variable_struct_get(global.val.gnx_mod_data, _selftest_mod), "_test_rt") == 42;
    // Cleanup: remove the entire synthetic struct (created fresh by scr_gnx_set_state)
    if (variable_struct_exists(global.gnx_mod_state, _selftest_mod))
        variable_struct_remove(global.gnx_mod_state, _selftest_mod);
    if (variable_struct_exists(global.val.gnx_mod_data, _selftest_mod))
        variable_struct_remove(global.val.gnx_mod_data, _selftest_mod);
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T20 set/get round-trip + persistence path\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T20 set/get round-trip: got " + string(_rt) + "\n");
        _fail++;
    }

    // T21: fixed-mode cells have phase_1/phase_2 with valid spr_array & spr_c_array
    var _bad21 = "";
    var _k21 = ds_map_find_first(global.cell_registry);
    while (_k21 != undefined)
    {
        var _c21 = ds_map_find_value(global.cell_registry, _k21);
        if (is_struct(_c21) && variable_struct_exists(_c21, "human_spr") && is_struct(_c21.human_spr)
            && variable_struct_exists(_c21.human_spr, "mode") && _c21.human_spr.mode == "fixed")
        {
            if (variable_struct_exists(_c21.human_spr, "phase_1"))
                _bad21 += scr_gnx_collect_bad_spr(_c21.human_spr.phase_1, string(_k21) + ".phase_1");
            if (variable_struct_exists(_c21.human_spr, "phase_2"))
                _bad21 += scr_gnx_collect_bad_spr(_c21.human_spr.phase_2, string(_k21) + ".phase_2");
        }
        _k21 = ds_map_find_next(global.cell_registry, _k21);
    }
    if (_bad21 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T21 fixed-mode cell sprites valid\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T21 fixed-mode bad sprites: " + _bad21 + "\n");
        _fail++;
    }

    // T22: every class clothing table resolves to real sprites (arrays + leaf fields)
    var _bad22 = "";
    var _k22 = ds_map_find_first(global.class_registry);
    while (_k22 != undefined)
    {
        var _cl22 = ds_map_find_value(global.class_registry, _k22);
        if (is_struct(_cl22))
        {
            var _tabs22 = ["clothing_standard", "clothing_big", "clothing_tent"];
            for (var _t = 0; _t < 3; _t++)
            {
                if (variable_struct_exists(_cl22, _tabs22[_t]))
                    _bad22 += scr_gnx_collect_bad_spr(variable_struct_get(_cl22, _tabs22[_t]), "c" + string(_k22) + "." + _tabs22[_t]);
            }
        }
        _k22 = ds_map_find_next(global.class_registry, _k22);
    }
    if (_bad22 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T22 class clothing sprites valid\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T22 class clothing bad sprites: " + _bad22 + "\n");
        _fail++;
    }

    // T23: every mod listed in index.txt loaded (manifest/version compat)
    var _ok23 = is_array(global.gnx_indexed_mods) && is_array(global.gnx_loaded_mods);
    var _miss23 = "";
    if (_ok23)
    {
        for (var _mi = 0; _mi < array_length(global.gnx_indexed_mods); _mi++)
        {
            var _mn = global.gnx_indexed_mods[_mi];
            var _found = false;
            for (var _lj = 0; _lj < array_length(global.gnx_loaded_mods); _lj++)
            {
                if (global.gnx_loaded_mods[_lj] == _mn) { _found = true; break; }
            }
            if (!_found)
                _miss23 += _mn + " ";
        }
    }
    if (_ok23 && _miss23 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T23 all indexed mods loaded (" + string(_ok23 ? array_length(global.gnx_indexed_mods) : 0) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T23 mods not loaded: " + _miss23 + "\n");
        _fail++;
    }

    // T24: required_class (cells) and birth_classes (classes) resolve in class_registry
    var _bad24 = "";
    var _k24 = ds_map_find_first(global.cell_registry);
    while (_k24 != undefined)
    {
        var _c24 = ds_map_find_value(global.cell_registry, _k24);
        if (is_struct(_c24) && variable_struct_exists(_c24, "physical") && is_struct(_c24.physical)
            && variable_struct_exists(_c24.physical, "required_class") && is_array(_c24.physical.required_class))
        {
            var _rq = _c24.physical.required_class;
            for (var _ri = 0; _ri < array_length(_rq); _ri++)
            {
                if (!ds_map_exists(global.class_registry, _rq[_ri]))
                    _bad24 += "cell" + string(_k24) + "->c" + string(_rq[_ri]) + " ";
            }
        }
        _k24 = ds_map_find_next(global.cell_registry, _k24);
    }
    var _k24b = ds_map_find_first(global.class_registry);
    while (_k24b != undefined)
    {
        var _cl24 = ds_map_find_value(global.class_registry, _k24b);
        if (is_struct(_cl24) && variable_struct_exists(_cl24, "birth_classes") && is_array(_cl24.birth_classes))
        {
            var _bc = _cl24.birth_classes;
            for (var _bi = 0; _bi < array_length(_bc); _bi++)
            {
                if (!ds_map_exists(global.class_registry, _bc[_bi]))
                    _bad24 += "c" + string(_k24b) + "->birth" + string(_bc[_bi]) + " ";
            }
        }
        _k24b = ds_map_find_next(global.class_registry, _k24b);
    }
    if (_bad24 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T24 required_class/birth_classes resolve\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T24 unresolved class refs: " + _bad24 + "\n");
        _fail++;
    }

    // T25: every bl_lookup value resolves to a real sprite (or -1)
    var _bad25 = 0;
    var _bk25 = ds_map_find_first(global.bl_lookup);
    while (_bk25 != undefined)
    {
        if (!scr_gnx_spr_ok(ds_map_find_value(global.bl_lookup, _bk25)))
            _bad25++;
        _bk25 = ds_map_find_next(global.bl_lookup, _bk25);
    }
    if (_bad25 == 0)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T25 bl_lookup sprites valid (n=" + string(ds_map_size(global.bl_lookup)) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T25 bl_lookup invalid entries: " + string(_bad25) + "\n");
        _fail++;
    }

    // T26: no duplicate h_type among gnx_registered_cells
    var _dup26 = "";
    if (is_array(global.gnx_registered_cells))
    {
        for (var _i = 0; _i < array_length(global.gnx_registered_cells); _i++)
        {
            var _ei = global.gnx_registered_cells[_i];
            var _hi = is_struct(_ei) ? _ei.h_type : _ei;
            for (var _j = _i + 1; _j < array_length(global.gnx_registered_cells); _j++)
            {
                var _ej = global.gnx_registered_cells[_j];
                var _hj = is_struct(_ej) ? _ej.h_type : _ej;
                if (_hi == _hj)
                    _dup26 += string(_hi) + " ";
            }
        }
    }
    if (_dup26 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T26 no duplicate registered h_type\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T26 duplicate h_type: " + _dup26 + "\n");
        _fail++;
    }

    // T27: at least one GNX cell was hash-assigned (h_type >= 100)
    if (array_length(global.gnx_registered_cells) == 0)
    {
        file_text_write_string(_log, "[GNX-TEST] SKIP  T27 no mod cells loaded\n");
    }
    else
    {
        var _hash27 = false;
        for (var _ci = 0; _ci < array_length(global.gnx_registered_cells); _ci++)
        {
            var _e27 = global.gnx_registered_cells[_ci];
            var _h27 = is_struct(_e27) ? _e27.h_type : _e27;
            if (_h27 >= 100) { _hash27 = true; break; }
        }
        if (_hash27)
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T27 hash-assigned cell h_type>=100 found\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T27 no hash-assigned cell found\n");
            _fail++;
        }
    }

    var _total = _pass + _fail;
    file_text_write_string(_log, "[GNX-TEST] " + string(_pass) + "/" + string(_total) + " passed");
    
    if (_fail > 0)
        file_text_write_string(_log, "  *** " + string(_fail) + " FAILED ***");
    
    file_text_write_string(_log, "\n");
    file_text_write_string(_log, "[GNX-TEST] ============================================================\n");
    file_text_close(_log);
}

function gnx_cov_hit(arg0)
{
    if (ds_map_exists(global.gnx_cov, arg0))
        ds_map_replace(global.gnx_cov, arg0, ds_map_find_value(global.gnx_cov, arg0) + 1);
    else
        ds_map_add(global.gnx_cov, arg0, 1);
    
    global.gnx_cov_tick++;
    
    if (global.gnx_cov_tick >= 500)
    {
        global.gnx_cov_tick = 0;
        scr_gnx_dump_coverage();
    }
}

function gnx_first_hit(arg0, arg1, arg2, arg3)
{
    var _k = string(arg0) + "." + arg1 + "." + arg2 + "." + string(arg3);
    var _kb = string(arg0) + "." + arg1 + "." + arg2;
    
    if (!ds_map_exists(global.gnx_seen, _k))
    {
        ds_map_add(global.gnx_seen, _k, 1);
        var _f = file_text_open_append(GNX_LOG);
        file_text_write_string(_f, "[GNX-CELL] FIRST cell=" + string(arg0) + " t=" + arg1 + " ph=" + arg2 + " cls=" + string(arg3) + "\n");
        file_text_close(_f);
    }
    
    if (!ds_map_exists(global.gnx_seen_base, _kb))
        ds_map_add(global.gnx_seen_base, _kb, 1);
}

function scr_gnx_build_expected()
{
    var _phases = ["s", "lo", "ej"];
    var _k = ds_map_find_first(global.cell_registry);
    
    while (_k != undefined)
    {
        var _cell = ds_map_find_value(global.cell_registry, _k);
        var _cn = string(_k);
        
        if (variable_struct_exists(_cell, "mon_spr") && _cell.mon_spr != undefined)
        {
            for (var _i = 0; _i < 3; _i++)
                ds_list_add(global.gnx_expected, _cn + ".g." + _phases[_i]);
            
            for (var _i = 0; _i < 3; _i++)
                ds_list_add(global.gnx_expected, _cn + ".h." + _phases[_i]);
            
            for (var _i = 0; _i < 3; _i++)
                ds_list_add(global.gnx_expected, _cn + ".o." + _phases[_i]);
        }
        
        _k = ds_map_find_next(global.cell_registry, _k);
    }
    
    var _f = file_text_open_append(GNX_LOG);
    file_text_write_string(_f, "[GNX-CELL] expected set built: " + string(ds_list_size(global.gnx_expected)) + " base combos\n");
    file_text_close(_f);
}

function scr_gnx_dump_cell_coverage()
{
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-CELL] ---- cell coverage dump ----\n");
    var _seen_n = ds_map_size(global.gnx_seen);
    file_text_write_string(_log, "[GNX-CELL] SEEN " + string(_seen_n) + " combos (cell.t.ph.cls)\n");
    var _sk = ds_map_find_first(global.gnx_seen);
    
    while (_sk != undefined)
    {
        file_text_write_string(_log, "[GNX-CELL] SEEN " + string(_sk) + "\n");
        _sk = ds_map_find_next(global.gnx_seen, _sk);
    }
    
    var _miss_n = 0;
    var _exp_n = ds_list_size(global.gnx_expected);
    
    for (var _i = 0; _i < _exp_n; _i++)
    {
        var _ek = ds_list_find_value(global.gnx_expected, _i);
        
        if (!ds_map_exists(global.gnx_seen_base, _ek))
        {
            file_text_write_string(_log, "[GNX-CELL] MISS " + _ek + "\n");
            _miss_n++;
        }
    }
    
    file_text_write_string(_log, "[GNX-CELL] MISSING " + string(_miss_n) + "/" + string(_exp_n) + " base combos\n");
    file_text_write_string(_log, "[GNX-CELL] ---- end ----\n");
    file_text_close(_log);
}

function scr_gnx_test_dispatch_routing()
{
    // Pre-validates registry data for all cell×class combos.
    // Does NOT call the dispatcher (needs object context). Simulates routing logic inline.
    // Giant (class 11) skipped for big/tent cells — it only uses GIANT cell (base_body=standard).
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-TEST] === DISPATCH ROUTING CHECK ===\n");
    var _pass = 0;
    var _fail = 0;
    var _skip = 0;
    var _cells  = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22,23,24,25,27,28,29,30,31,32,33,34,36,37,38,39,40,41,42];
    // Build class list dynamically from class_registry (vanilla + any mod classes),
    // instead of a hardcoded list that assumes a specific test class is loaded.
    var _classes = [];
    var _ck = ds_map_find_first(global.class_registry);

    while (_ck != undefined)
    {
        array_push(_classes, _ck);
        _ck = ds_map_find_next(global.class_registry, _ck);
    }

    var _ci = 0;
    repeat (array_length(_cells))
    {
        var _h = _cells[_ci++];
        var _rcell = ds_map_find_value(global.cell_registry, _h);
        if (_rcell == undefined || !variable_struct_exists(_rcell, "human_spr") || _rcell.human_spr == undefined)
        {
            file_text_write_string(_log, "[GNX-TEST] SKIP  DROUTE h=" + string(_h) + " NO_HUMAN_SPR\n");
            _skip++;
            continue;
        }
        var _rule = _rcell.human_spr;
        if (variable_struct_exists(_rule, "mode") && _rule.mode == "fixed")
        {
            if (variable_struct_exists(_rule, "phase_1") && variable_struct_exists(_rule, "phase_2"))
                _pass++;
            else
            {
                file_text_write_string(_log, "[GNX-TEST] FAIL  DROUTE h=" + string(_h) + " FIXED_MISSING_PHASE\n");
                _fail++;
            }
            continue;
        }
        var _bb = variable_struct_exists(_rule, "base_body") ? _rule.base_body : "";
        var _clsi = 0;
        repeat (array_length(_classes))
        {
            var _c = _classes[_clsi++];
            if (_c == 11 && _bb != "standard") { file_text_write_string(_log, "[GNX-TEST] SKIP  DROUTE h=" + string(_h) + " c=11 Giant/" + _bb + "\n"); _skip++; continue; }
            var _rclass = ds_map_find_value(global.class_registry, _c);
            if (_rclass == undefined)
            {
                file_text_write_string(_log, "[GNX-TEST] FAIL  DROUTE h=" + string(_h) + " c=" + string(_c) + " NO_CLASS\n");
                _fail++;
                continue;
            }
            var _ok = false;
            if (_bb == "standard")
                _ok = variable_struct_exists(_rclass, "clothing_standard")
                   && variable_struct_exists(_rclass.clothing_standard, "phase_1")
                   && variable_struct_exists(_rclass.clothing_standard, "phase_2");
            else if (_bb == "big")
            {
                if (_rclass.is_special)
                    _ok = variable_struct_exists(_rclass, "clothing_big")
                       && variable_struct_exists(_rclass.clothing_big, "phase_1");
                else
                    _ok = variable_struct_exists(_rclass, "clothing_big")
                       && variable_struct_exists(_rclass.clothing_big, "idle")
                       && variable_struct_exists(_rclass.clothing_big, "loop");
            }
            else if (_bb == "tent")
            {
                if (_rclass.is_special)
                    _ok = variable_struct_exists(_rclass, "clothing_tent")
                       && variable_struct_exists(_rclass.clothing_tent, "phase_1");
                else
                    _ok = variable_struct_exists(_rclass, "clothing_tent")
                       && variable_struct_exists(_rclass.clothing_tent, "phase_1")
                       && variable_struct_exists(_rclass.clothing_tent, "phase_2");
            }
            if (_ok)
                _pass++;
            else
            {
                file_text_write_string(_log, "[GNX-TEST] FAIL  DROUTE h=" + string(_h) + " c=" + string(_c) + " bb=" + _bb + "\n");
                _fail++;
            }
        }
    }
    file_text_write_string(_log, "[GNX-TEST] DROUTE: " + string(_pass) + " PASS " + string(_fail) + " FAIL " + string(_skip) + " SKIP\n");
    file_text_write_string(_log, "[GNX-TEST] ============================================================\n");
    file_text_close(_log);
}
