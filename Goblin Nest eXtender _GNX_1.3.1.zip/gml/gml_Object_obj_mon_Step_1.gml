if (scr_mon_begin_step != -1)
    script_execute(scr_mon_begin_step);
