scr_mouse_control();

// GNX: per-frame quest completion check
scr_gnx_check_quest_completion("frame");
