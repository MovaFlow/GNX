// GNX: patched s_window_alpha.gml
// Rebased onto vanilla 1.38 base.
// - draw_sprite_ext -> gnx_draw_sprite_ext for spr_option_window, spr_guide_window
// - Added button 16 (SOUND entry) to scr_create_alpha_window, gated behind gnx_has_sounds
// - UnknownEnum -> numeric literals

function scr_create_alpha_window()
{
    var _window = instance_create_depth(x, y, -2200, obj_window);
    
    with (_window)
    {
        if (!global.val.ui_place)
        {
            x += -30;
            y += 12;
        }
        else
        {
            x += 114;
            y += 13;
        }
        
        interact_type = 9;
        source_id = other.id;
        scr_window_draw = scr_draw_alpha_window;
        gui = true;
        scr_create_button_layout(12, 11, depth - 1, 12, 2, 23, 12, 0, spr_button_arrow, 31, id, false, scr_create_alpha_set_button, -1, scr_draw_hover_button);
        scr_create_button_layout(-111, 20, depth - 1, 3, 1, 1, 34, 0, spr_button_load, 53, id, false, scr_create_save_button, -1, scr_draw_save_data_button);
        scr_create_button(35, 85, depth - 1, spr_button_oval, 31, id, scr_create_alpha_set_button, -1, scr_draw_hover_button, 12, 10);
        scr_create_button(35, 98, depth - 1, spr_button_oval, 31, id, scr_create_alpha_set_button, -1, scr_draw_hover_button, 13, 10);
        scr_create_button(-5, 111, depth - 1, spr_button_guide_icon, 31, id, scr_create_option_guide, -1, scr_draw_hover_guide_button, 14, 11);
        scr_create_button(35, 112, depth - 1, spr_button_oval, 31, id, scr_create_option_button, -1, scr_draw_hover_button, 15, 11);
        // GNX sound: SOUND entry button (same position as moan mod)
        if (global.gnx_has_sounds)
            scr_create_button(-13, 61, depth - 1, spr_button_oval, 31, id, scr_create_option_button, -1, scr_draw_hover_button, 16, 10);
    }
    
    return _window;
}

function scr_draw_alpha_window()
{
    gnx_draw_sprite_ext(spr_option_window, image_index, x, y, 1, 1, image_angle, image_blend, image_alpha);
    var _x = x - 32;
    var _y = y + 8;
    var _width = 55;
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    var _lang_pos = scr_change_lang();
    _x += _lang_pos[0];
    _y += _lang_pos[1];
    var _save_x = (x - 74) + _lang_pos[0];
    var _save_y = y + 6 + _lang_pos[1];
    var _height = 34;
    
    switch (global.val.language)
    {
        case 0:
            draw_text(_x, _y, "MON TYPE");
            draw_text(_x, _y + 12, "OPACITY");
            draw_text(_x, _y + 24, "PROP TYPE");
            draw_text(_x, _y + 36, "OPACITY");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "UI PLACEMENT");
            draw_text(_x, _y + 87, "FULLSCREEN");
            draw_text(_x - 1, _y + 100, "GUIDE");
            draw_text(_x + 43, _y + 100, "EXIT");
            draw_set_halign(fa_center);
            draw_text(_save_x, _save_y, "SAVE 1");
            draw_text(_save_x, _save_y + _height, "SAVE 2");
            draw_text(_save_x, _save_y + (_height * 2), "SAVE 3");
            break;
        
        case 9:
            draw_text(_x, _y, "怪物類型");
            draw_text(_x, _y + 12, "不透明度");
            draw_text(_x, _y + 24, "道具類型");
            draw_text(_x, _y + 36, "不透明度");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "UI放置");
            draw_text(_x, _y + 87, "全屏");
            draw_text(_x - 1, _y + 100, "指南");
            draw_text(_x + 42, _y + 100, "退出");
            draw_set_halign(fa_center);
            draw_text(_save_x - 1, _save_y, "存檔1");
            draw_text(_save_x - 1, _save_y + _height, "存檔2");
            draw_text(_save_x - 1, _save_y + (_height * 2), "存檔3");
            break;
        
        case 2:
            draw_text(_x, _y, "怪物类型");
            draw_text(_x, _y + 12, "不透明度");
            draw_text(_x, _y + 24, "道具类型");
            draw_text(_x, _y + 36, "不透明度");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "UI放置");
            draw_text(_x, _y + 87, "全屏");
            draw_text(_x - 1, _y + 100, "指南");
            draw_text(_x + 42, _y + 100, "退出");
            draw_set_halign(fa_center);
            draw_text(_save_x - 1, _save_y, "存档1");
            draw_text(_save_x - 1, _save_y + _height, "存档2");
            draw_text(_save_x - 1, _save_y + (_height * 2), "存档3");
            break;
        
        case 1:
            draw_text(_x, _y, "敵種");
            draw_text(_x, _y + 12, "不透明度");
            draw_text(_x, _y + 24, "道具");
            draw_text(_x, _y + 36, "不透明度");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "UI配置");
            draw_text(_x, _y + 87, "全画面");
            draw_text(_x - 1, _y + 100, "説明");
            draw_text(_x + 42, _y + 100, "終了");
            draw_set_halign(fa_center);
            draw_text(_save_x, _save_y, "セーブ1");
            draw_text(_save_x, _save_y + _height, "セーブ2");
            draw_text(_save_x, _save_y + (_height * 2), "セーブ3");
            break;
        
        case 3:
            draw_text(_x, _y, "몹 형태");
            draw_text(_x, _y + 12, "투명도");
            draw_text(_x, _y + 24, "소품형태");
            draw_text(_x, _y + 36, "투명도");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "UI 배치");
            draw_text(_x, _y + 87, "전체화면");
            draw_text(_x - 1, _y + 100, "안내");
            draw_text(_x + 42, _y + 100, "종료");
            draw_set_halign(fa_center);
            draw_text(_save_x, _save_y, "파일 1");
            draw_text(_save_x, _save_y + _height, "파일 2");
            draw_text(_save_x, _save_y + (_height * 2), "파일 3");
            break;
        
        case 7:
            draw_text(_x, _y, "ТИП МОН.");
            draw_text(_x, _y + 12, "ПРОЗРАЧ");
            draw_text(_x, _y + 24, "ТИП ПОДСТ.");
            draw_text(_x, _y + 36, "ПРОЗРАЧ");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "РАСП. ИНТЕРФ.");
            draw_text(_x, _y + 87, "ПОЛНЫЙ ЭКРАН");
            draw_text(_x - 1, _y + 100, "ГАЙД");
            draw_text(_x + 40, _y + 100, "ВЫХОД");
            draw_set_halign(fa_center);
            draw_text(_save_x, _save_y, "SAVE 1");
            draw_text(_save_x, _save_y + _height, "SAVE 2");
            draw_text(_save_x, _save_y + (_height * 2), "SAVE 3");
            break;
        
        case 4:
            draw_text(_x, _y, "ESTILO.M");
            draw_text(_x, _y + 12, "OPACIDAD");
            draw_text(_x, _y + 24, "ESTILO.U");
            draw_text(_x, _y + 36, "OPACIDAD");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "DISPOSICIÓN");
            draw_text(_x, _y + 87, "P.COMPLETA");
            draw_text(_x - 1, _y + 100, "GUÍA");
            draw_text(_x + 42, _y + 100, "SALIR");
            draw_set_halign(fa_center);
            draw_text(_save_x, _save_y, "ARCHIVO 1");
            draw_text(_save_x, _save_y + _height, "ARCHIVO 2");
            draw_text(_save_x, _save_y + (_height * 2), "ARCHIVO 3");
            break;
        
        case 6:
            draw_text(_x, _y, "TYPE DE M.");
            draw_text(_x, _y + 12, "OPACITÉ");
            draw_text(_x, _y + 24, "TYPE D'ACC.");
            draw_text(_x, _y + 36, "OPACITÉ");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "PLACEMENT DE L'UI");
            draw_text(_x, _y + 87, "PLEIN ÉCRAN");
            draw_text(_x - 1, _y + 100, "GUIDE");
            draw_text(_x + 42, _y + 100, "QUIT.");
            draw_set_halign(fa_center);
            draw_text(_save_x, _save_y, "SAUVEGARDE 1");
            draw_text(_save_x, _save_y + _height, "SAUVEGARDE 2");
            draw_text(_save_x, _save_y + (_height * 2), "SAUVEGARDE 3");
            break;
        
        case 8:
            draw_text(_x, _y, "MON.TYP");
            draw_text(_x, _y + 12, "DECKKRAFT");
            draw_text(_x, _y + 24, "REQ.TYP");
            draw_text(_x, _y + 36, "DECKKRAFT");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "UI-PLATZIERUNG");
            draw_text(_x, _y + 87, "VOLLBILD");
            draw_text(_x - 1, _y + 100, "HILFE");
            draw_text(_x + 41, _y + 100, "GEHEN");
            draw_set_halign(fa_center);
            draw_text(_save_x, _save_y, "SAVE 1");
            draw_text(_save_x, _save_y + _height, "SAVE 2");
            draw_text(_save_x, _save_y + (_height * 2), "SAVE 3");
            break;
        
        case 5:
            draw_text(_x, _y, "T.MONSTRO");
            draw_text(_x, _y + 12, "OPACIDADE");
            draw_text(_x, _y + 24, "T.OBJETO");
            draw_text(_x, _y + 36, "OPACIDADE");
            draw_text(_x, _y + 49, "SFX");
            draw_text(_x, _y + 61, "BGM");
            draw_text(_x, _y + 74, "POSIÇÃO DE UI");
            draw_text(_x, _y + 87, "TELA CHEIA");
            draw_text(_x - 1, _y + 100, "GUIA");
            draw_text(_x + 43, _y + 100, "SAIR");
            draw_set_halign(fa_center);
            draw_text(_save_x, _save_y, "SALVO 1");
            draw_text(_save_x, _save_y + _height, "SALVO 2");
            draw_text(_save_x, _save_y + (_height * 2), "SALVO 3");
            break;
    }
    
    draw_set_font(fnt_base_font_eng);
    _x -= (_lang_pos[0] - 1);
    _y -= _lang_pos[1];
    draw_text(_x + _width, _y, string(global.val.alpha_type + 1));
    draw_text(_x + _width, _y + 12, string(round(global.val.mon_alpha * 100)) + "%");
    draw_text(_x + _width, _y + 24, string(global.val.crate_alpha_type + 1));
    draw_text(_x + _width, _y + 36, string(round(global.val.crate_alpha * 100)) + "%");
    draw_text(_x + _width, _y + 49, string(round(global.val.sfx_vol * 100)) + "%");
    draw_text(_x + _width, _y + 61, string(round(global.val.bgm_vol * 100)) + "%");
}

function scr_draw_guide_window()
{
    gnx_draw_sprite_ext(spr_guide_window, image_index, x, y, 1, 1, image_angle, image_blend, image_alpha);
    var _x = x - 97;
    var _y = y + 9;
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    var _lang_pos = scr_change_lang();
    
    switch (global.val.language)
    {
        case 0:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "GUIDE");
            break;
        
        case 9:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "指南");
            break;
        
        case 2:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "指南");
            break;
        
        case 1:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "ガイド");
            break;
        
        case 3:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "가이드");
            break;
        
        case 7:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "ГАЙД");
            break;
        
        case 4:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "GUÍA");
            break;
        
        case 6:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "GUIDE");
            break;
        
        case 8:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "FÜHRUNG");
            break;
        
        case 5:
            draw_text(_x + _lang_pos[0], _y + _lang_pos[1], "GUIA");
            break;
    }
    
    draw_set_font(fnt_base_font_eng);
}

function scr_create_option_button()
{
    gui = true;
    act_resize = true;
}

function scr_create_option_guide()
{
    gui = true;
    act_resize = true;
    spr_sel = spr_button_guide_icon_sel;
}

function scr_create_alpha_set_button()
{
    scr_create_option_button();
    
    if (button_num < 12 && (button_num % 2) != 0)
        image_xscale = -1;
    
    if (button_num >= 8)
        y += 1;
}

function scr_create_guide_g_button()
{
    scr_create_option_button();
    spr_sel = spr_button_guide_sel;
    switch_type = false;
    fail_shake = false;
    
    switch (global.val.language)
    {
        case 0:
            switch (button_num)
            {
                case 0:
                    guide_text = "NEST";
                    break;
                
                case 1:
                    guide_text = "RAID";
                    break;
                
                case 2:
                    guide_text = "CELLS";
                    break;
                
                case 3:
                    guide_text = "BACK";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
        
        case 9:
            switch (button_num)
            {
                case 0:
                    guide_text = "巢穴";
                    break;
                
                case 1:
                    guide_text = "洗劫";
                    break;
                
                case 2:
                    guide_text = "巢室";
                    break;
                
                case 3:
                    guide_text = "返回";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
        
        case 2:
            switch (button_num)
            {
                case 0:
                    guide_text = "巢穴";
                    break;
                
                case 1:
                    guide_text = "洗劫";
                    break;
                
                case 2:
                    guide_text = "巢室";
                    break;
                
                case 3:
                    guide_text = "返回";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
        
        case 1:
            switch (button_num)
            {
                case 0:
                    guide_text = "巣";
                    break;
                
                case 1:
                    guide_text = "襲撃";
                    break;
                
                case 2:
                    guide_text = "セル";
                    break;
                
                case 3:
                    guide_text = "戻る";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
        
        case 3:
            switch (button_num)
            {
                case 0:
                    guide_text = "둥지";
                    break;
                
                case 1:
                    guide_text = "습격";
                    break;
                
                case 2:
                    guide_text = "방";
                    break;
                
                case 3:
                    guide_text = "뒤로";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
        
        case 7:
            switch (button_num)
            {
                case 0:
                    guide_text = "ГНЕЗДО";
                    break;
                
                case 1:
                    guide_text = "НАБЕГ";
                    break;
                
                case 2:
                    guide_text = "КАМЕРА";
                    break;
                
                case 3:
                    guide_text = "НАЗАД";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
        
        case 4:
            switch (button_num)
            {
                case 0:
                    guide_text = "NIDO";
                    break;
                
                case 1:
                    guide_text = "SAQUEO";
                    break;
                
                case 2:
                    guide_text = "CELDA";
                    break;
                
                case 3:
                    guide_text = "ATRÁS";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
        
        case 6:
            switch (button_num)
            {
                case 0:
                    guide_text = "NID";
                    break;
                
                case 1:
                    guide_text = "RAID";
                    break;
                
                case 2:
                    guide_text = "CELLULE";
                    break;
                
                case 3:
                    guide_text = "RETOUR";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
        
        case 8:
            switch (button_num)
            {
                case 0:
                    guide_text = "NEST";
                    break;
                
                case 1:
                    guide_text = "RAUBZUG";
                    break;
                
                case 2:
                    guide_text = "ZELLE";
                    break;
                
                case 3:
                    guide_text = "ZURÜCK";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
        
        case 5:
            switch (button_num)
            {
                case 0:
                    guide_text = "NINHO";
                    break;
                
                case 1:
                    guide_text = "SAQUEAR";
                    break;
                
                case 2:
                    guide_text = "CELA";
                    break;
                
                case 3:
                    guide_text = "VOLTAR";
                    spr_sel = spr_button_bar_sel;
                    break;
            }
            
            break;
    }
}

function scr_create_guide_basic_button()
{
    scr_create_option_button();
    spr_sel = spr_button_guide_sel;
    guide_group = 0;
    
    switch (global.val.language)
    {
        case 0:
            switch (button_num)
            {
                case 0:
                    guide_text = "CONTROLS";
                    break;
                
                case 1:
                    guide_text = "QUEST";
                    break;
                
                case 2:
                    guide_text = "PRISON";
                    break;
                
                case 3:
                    guide_text = "BIRTH";
                    break;
                
                case 4:
                    guide_text = "CLEANING";
                    break;
                
                case 5:
                    guide_text = "RATION";
                    break;
                
                case 6:
                    guide_text = "MOOD";
                    break;
                
                case 7:
                    guide_text = "MILK";
                    break;
                
                case 8:
                    guide_text = "CELL STATS";
                    break;
                
                case 9:
                    guide_text = "HOTKEYS";
                    break;
                
                case 10:
                    guide_text = "DEMOLISH";
                    break;
                
                case 11:
                    guide_text = "TENTACLES";
                    break;
            }
            
            break;
        
        case 9:
            switch (button_num)
            {
                case 0:
                    guide_text = "控制";
                    break;
                
                case 1:
                    guide_text = "任務";
                    break;
                
                case 2:
                    guide_text = "監獄";
                    break;
                
                case 3:
                    guide_text = "生育";
                    break;
                
                case 4:
                    guide_text = "清潔";
                    break;
                
                case 5:
                    guide_text = "食物";
                    break;
                
                case 6:
                    guide_text = "心情";
                    break;
                
                case 7:
                    guide_text = "乳汁";
                    break;
                
                case 8:
                    guide_text = "巢室狀態";
                    break;
                
                case 9:
                    guide_text = "快捷鍵";
                    break;
                
                case 10:
                    guide_text = "拆除";
                    break;
                
                case 11:
                    guide_text = "觸手";
                    break;
            }
            
            break;
        
        case 2:
            switch (button_num)
            {
                case 0:
                    guide_text = "控制";
                    break;
                
                case 1:
                    guide_text = "任务";
                    break;
                
                case 2:
                    guide_text = "监狱";
                    break;
                
                case 3:
                    guide_text = "生育";
                    break;
                
                case 4:
                    guide_text = "清洁";
                    break;
                
                case 5:
                    guide_text = "食物";
                    break;
                
                case 6:
                    guide_text = "心情";
                    break;
                
                case 7:
                    guide_text = "乳汁";
                    break;
                
                case 8:
                    guide_text = "巢室状态";
                    break;
                
                case 9:
                    guide_text = "快捷键";
                    break;
                
                case 10:
                    guide_text = "拆除";
                    break;
                
                case 11:
                    guide_text = "触手";
                    break;
            }
            
            break;
        
        case 1:
            switch (button_num)
            {
                case 0:
                    guide_text = "操作";
                    break;
                
                case 1:
                    guide_text = "クエスト";
                    break;
                
                case 2:
                    guide_text = "牢獄";
                    break;
                
                case 3:
                    guide_text = "出産";
                    break;
                
                case 4:
                    guide_text = "清掃";
                    break;
                
                case 5:
                    guide_text = "配給";
                    break;
                
                case 6:
                    guide_text = "機嫌";
                    break;
                
                case 7:
                    guide_text = "ミルク";
                    break;
                
                case 8:
                    guide_text = "房情報";
                    break;
                
                case 9:
                    guide_text = "キー設定";
                    break;
                
                case 10:
                    guide_text = "解体";
                    break;
                
                case 11:
                    guide_text = "触手";
                    break;
            }
            
            break;
        
        case 3:
            switch (button_num)
            {
                case 0:
                    guide_text = "조작";
                    break;
                
                case 1:
                    guide_text = "퀘스트";
                    break;
                
                case 2:
                    guide_text = "감옥";
                    break;
                
                case 3:
                    guide_text = "출산";
                    break;
                
                case 4:
                    guide_text = "청소";
                    break;
                
                case 5:
                    guide_text = "식량";
                    break;
                
                case 6:
                    guide_text = "사기";
                    break;
                
                case 7:
                    guide_text = "젖";
                    break;
                
                case 8:
                    guide_text = "감방 상태";
                    break;
                
                case 9:
                    guide_text = "단축키";
                    break;
                
                case 10:
                    guide_text = "철거";
                    break;
                
                case 11:
                    guide_text = "촉수";
                    break;
            }
            
            break;
        
        case 7:
            switch (button_num)
            {
                case 0:
                    guide_text = "УПРАВЛЕНИЕ";
                    break;
                
                case 1:
                    guide_text = "ЗАДАНИЯ";
                    break;
                
                case 2:
                    guide_text = "ТЮРЬМА";
                    break;
                
                case 3:
                    guide_text = "РОДЫ";
                    break;
                
                case 4:
                    guide_text = "УБОРКА";
                    break;
                
                case 5:
                    guide_text = "РАЦИОН";
                    break;
                
                case 6:
                    guide_text = "НАСТРОЕНИЕ";
                    break;
                
                case 7:
                    guide_text = "МОЛОКО";
                    break;
                
                case 8:
                    guide_text = "СТАТ. КАМЕРЫ";
                    break;
                
                case 9:
                    guide_text = "КЛАВИШИ";
                    break;
                
                case 10:
                    guide_text = "СНОС";
                    break;
                
                case 11:
                    guide_text = "ТЕНТАКЛИ";
                    break;
            }
            
            break;
        
        case 4:
            switch (button_num)
            {
                case 0:
                    guide_text = "CONTROLES";
                    break;
                
                case 1:
                    guide_text = "MISIÓN";
                    break;
                
                case 2:
                    guide_text = "PRISIÓN";
                    break;
                
                case 3:
                    guide_text = "PARTO";
                    break;
                
                case 4:
                    guide_text = "LIMPIEZA";
                    break;
                
                case 5:
                    guide_text = "RACIONAR";
                    break;
                
                case 6:
                    guide_text = "ÁNIMO";
                    break;
                
                case 7:
                    guide_text = "LECHE";
                    break;
                
                case 8:
                    guide_text = "ESTAD.CELDAS";
                    break;
                
                case 9:
                    guide_text = "ATAJOS";
                    break;
                
                case 10:
                    guide_text = "DEMOLICIÓN";
                    break;
                
                case 11:
                    guide_text = "TENTÁCULOS";
                    break;
            }
            
            break;
        
        case 6:
            switch (button_num)
            {
                case 0:
                    guide_text = "COMMANDES";
                    break;
                
                case 1:
                    guide_text = "QUÊTE";
                    break;
                
                case 2:
                    guide_text = "PRISON";
                    break;
                
                case 3:
                    guide_text = "NAISSANCE";
                    break;
                
                case 4:
                    guide_text = "NETTOYAGE";
                    break;
                
                case 5:
                    guide_text = "RATION";
                    break;
                
                case 6:
                    guide_text = "MORAL";
                    break;
                
                case 7:
                    guide_text = "LAIT";
                    break;
                
                case 8:
                    guide_text = "STAT. CELL.";
                    break;
                
                case 9:
                    guide_text = "TOUCHES";
                    break;
                
                case 10:
                    guide_text = "DÉMOLIR";
                    break;
                
                case 11:
                    guide_text = "TENTACULES";
                    break;
            }
            
            break;
        
        case 8:
            switch (button_num)
            {
                case 0:
                    guide_text = "STEUERUNG";
                    break;
                
                case 1:
                    guide_text = "AUFTRAG";
                    break;
                
                case 2:
                    guide_text = "GEFÄNGNIS";
                    break;
                
                case 3:
                    guide_text = "GEBURT";
                    break;
                
                case 4:
                    guide_text = "SÄUBERN";
                    break;
                
                case 5:
                    guide_text = "RATIONEN";
                    break;
                
                case 6:
                    guide_text = "STIMMUNG";
                    break;
                
                case 7:
                    guide_text = "MILCH";
                    break;
                
                case 8:
                    guide_text = "Z.STATUS";
                    break;
                
                case 9:
                    guide_text = "HOTKEY";
                    break;
                
                case 10:
                    guide_text = "ZERSTÖREN";
                    break;
                
                case 11:
                    guide_text = "TENTAKEL";
                    break;
            }
            
            break;
        
        case 5:
            switch (button_num)
            {
                case 0:
                    guide_text = "CONTROLES";
                    break;
                
                case 1:
                    guide_text = "MISSÃO";
                    break;
                
                case 2:
                    guide_text = "PRISÃO";
                    break;
                
                case 3:
                    guide_text = "PARTO";
                    break;
                
                case 4:
                    guide_text = "LIMPAR";
                    break;
                
                case 5:
                    guide_text = "PROVISÕES";
                    break;
                
                case 6:
                    guide_text = "MORAL";
                    break;
                
                case 7:
                    guide_text = "LEITE";
                    break;
                
                case 8:
                    guide_text = "ATRIB.CELAS";
                    break;
                
                case 9:
                    guide_text = "TC.ATALHO";
                    break;
                
                case 10:
                    guide_text = "DEMOLIR";
                    break;
                
                case 11:
                    guide_text = "TENTÁCULOS";
                    break;
            }
            
            break;
    }
}

function scr_create_guide_cell_button()
{
    var _type = global.guide_order_cell[button_num];
    var _num = array_length(global.val.guide_unlock.cell);
    var _exists = false;
    
    for (var i = 0; i < _num; i++)
    {
        if (global.val.guide_unlock.cell[i] == _type)
        {
            _exists = true;
            i = _num;
        }
    }
    
    if (!_exists)
    {
        instance_destroy();
    }
    else
    {
        scr_create_option_button();
        spr_sel = spr_button_guide_sel;
        guide_group = 2;
        guide_new = false;
        
        switch (global.val.language)
        {
            case 0:
                switch (button_num)
                {
                    case 0:
                        guide_text = "DISPLAY";
                        break;
                    
                    case 1:
                        guide_text = "BIRTH 2";
                        break;
                    
                    case 2:
                        guide_text = "DRINK";
                        break;
                    
                    case 3:
                        guide_text = "TRANSFER";
                        break;
                    
                    case 4:
                        guide_text = "RECOVER";
                        break;
                    
                    case 5:
                        guide_text = "MILK 2";
                        break;
                    
                    case 6:
                        guide_text = "PATROL";
                        break;
                    
                    case 7:
                        guide_text = "CLONE";
                        break;
                    
                    case 8:
                        guide_text = "F.SHRINE";
                        break;
                    
                    case 9:
                        guide_text = "R.SHRINE";
                        break;
                    
                    case 10:
                        guide_text = "S.SHRINE";
                        break;
                    
                    case 11:
                        guide_text = "L.SHRINE";
                        break;
                }
                
                break;
            
            case 9:
                switch (button_num)
                {
                    case 0:
                        guide_text = "展覽";
                        break;
                    
                    case 1:
                        guide_text = "生育2";
                        break;
                    
                    case 2:
                        guide_text = "飲用";
                        break;
                    
                    case 3:
                        guide_text = "轉移";
                        break;
                    
                    case 4:
                        guide_text = "恢復";
                        break;
                    
                    case 5:
                        guide_text = "擠奶2";
                        break;
                    
                    case 6:
                        guide_text = "巡邏";
                        break;
                    
                    case 7:
                        guide_text = "克隆";
                        break;
                    
                    case 8:
                        guide_text = "青蛙神龕";
                        break;
                    
                    case 9:
                        guide_text = "食物神龕";
                        break;
                    
                    case 10:
                        guide_text = "刀劍神龕";
                        break;
                    
                    case 11:
                        guide_text = "莉絲神龕";
                        break;
                }
                
                break;
            
            case 2:
                switch (button_num)
                {
                    case 0:
                        guide_text = "展览";
                        break;
                    
                    case 1:
                        guide_text = "生育2";
                        break;
                    
                    case 2:
                        guide_text = "饮用";
                        break;
                    
                    case 3:
                        guide_text = "转移";
                        break;
                    
                    case 4:
                        guide_text = "恢复";
                        break;
                    
                    case 5:
                        guide_text = "挤奶2";
                        break;
                    
                    case 6:
                        guide_text = "巡逻";
                        break;
                    
                    case 7:
                        guide_text = "克隆";
                        break;
                    
                    case 8:
                        guide_text = "青蛙神龛";
                        break;
                    
                    case 9:
                        guide_text = "食物神龛";
                        break;
                    
                    case 10:
                        guide_text = "刀剑神龛";
                        break;
                    
                    case 11:
                        guide_text = "莉丝神龛";
                        break;
                }
                
                break;
            
            case 1:
                switch (button_num)
                {
                    case 0:
                        guide_text = "展示";
                        break;
                    
                    case 1:
                        guide_text = "出産2";
                        break;
                    
                    case 2:
                        guide_text = "飲み";
                        break;
                    
                    case 3:
                        guide_text = "移送";
                        break;
                    
                    case 4:
                        guide_text = "回復";
                        break;
                    
                    case 5:
                        guide_text = "搾乳2";
                        break;
                    
                    case 6:
                        guide_text = "巡回";
                        break;
                    
                    case 7:
                        guide_text = "複製";
                        break;
                    
                    case 8:
                        guide_text = "蛙の祠";
                        break;
                    
                    case 9:
                        guide_text = "配給の祠";
                        break;
                    
                    case 10:
                        guide_text = "剣の祠";
                        break;
                    
                    case 11:
                        guide_text = "リスの祠";
                        break;
                }
                
                break;
            
            case 3:
                switch (button_num)
                {
                    case 0:
                        guide_text = "진열";
                        break;
                    
                    case 1:
                        guide_text = "출산2";
                        break;
                    
                    case 2:
                        guide_text = "수유";
                        break;
                    
                    case 3:
                        guide_text = "이송";
                        break;
                    
                    case 4:
                        guide_text = "회복";
                        break;
                    
                    case 5:
                        guide_text = "착유2";
                        break;
                    
                    case 6:
                        guide_text = "순찰";
                        break;
                    
                    case 7:
                        guide_text = "복제";
                        break;
                    
                    case 8:
                        guide_text = "개굴제단";
                        break;
                    
                    case 9:
                        guide_text = "식량제단";
                        break;
                    
                    case 10:
                        guide_text = "검 제단";
                        break;
                    
                    case 11:
                        guide_text = "릴리스상";
                        break;
                }
                
                break;
            
            case 7:
                switch (button_num)
                {
                    case 0:
                        guide_text = "ЭКСПОНАТ";
                        break;
                    
                    case 1:
                        guide_text = "РОДИЛЬНЯ 2";
                        break;
                    
                    case 2:
                        guide_text = "ПИТЬЁ";
                        break;
                    
                    case 3:
                        guide_text = "ПЕРЕНОСКА";
                        break;
                    
                    case 4:
                        guide_text = "РЕГЕН";
                        break;
                    
                    case 5:
                        guide_text = "ДОЙКА 2";
                        break;
                    
                    case 6:
                        guide_text = "ОБХОД";
                        break;
                    
                    case 7:
                        guide_text = "ДВОЙНИК";
                        break;
                    
                    case 8:
                        guide_text = "'АЛТАРЬ.Ля";
                        break;
                    
                    case 9:
                        guide_text = "'АЛТАРЬ.Р";
                        break;
                    
                    case 10:
                        guide_text = "'АЛТАРЬ.М";
                        break;
                    
                    case 11:
                        guide_text = "'АЛТАРЬ.Ли";
                        break;
                }
                
                break;
            
            case 4:
                switch (button_num)
                {
                    case 0:
                        guide_text = "TROFEO";
                        break;
                    
                    case 1:
                        guide_text = "PARTO 2";
                        break;
                    
                    case 2:
                        guide_text = "BEBIDA";
                        break;
                    
                    case 3:
                        guide_text = "TRASLADO";
                        break;
                    
                    case 4:
                        guide_text = "CURACIÓN";
                        break;
                    
                    case 5:
                        guide_text = "LECHE 2";
                        break;
                    
                    case 6:
                        guide_text = "PATRULLA";
                        break;
                    
                    case 7:
                        guide_text = "CLONACIÓN";
                        break;
                    
                    case 8:
                        guide_text = "ALTAR S.";
                        break;
                    
                    case 9:
                        guide_text = "ALTAR R.";
                        break;
                    
                    case 10:
                        guide_text = "ALTAR E.";
                        break;
                    
                    case 11:
                        guide_text = "ALTAR L.";
                        break;
                }
                
                break;
            
            case 6:
                switch (button_num)
                {
                    case 0:
                        guide_text = "EXPOSITION";
                        break;
                    
                    case 1:
                        guide_text = "NAISSANCE 2";
                        break;
                    
                    case 2:
                        guide_text = "BOISSON";
                        break;
                    
                    case 3:
                        guide_text = "TRANSFERT";
                        break;
                    
                    case 4:
                        guide_text = "RÉCUPÉRATION";
                        break;
                    
                    case 5:
                        guide_text = "LAIT 2";
                        break;
                    
                    case 6:
                        guide_text = "PATROUILLE";
                        break;
                    
                    case 7:
                        guide_text = "CLONE";
                        break;
                    
                    case 8:
                        guide_text = "AUTEL G.";
                        break;
                    
                    case 9:
                        guide_text = "AUTEL R.";
                        break;
                    
                    case 10:
                        guide_text = "AUTEL É.";
                        break;
                    
                    case 11:
                        guide_text = "AUTEL L.";
                        break;
                }
                
                break;
            
            case 8:
                switch (button_num)
                {
                    case 0:
                        guide_text = "AUSSTELLUNG";
                        break;
                    
                    case 1:
                        guide_text = "GEBURT 2";
                        break;
                    
                    case 2:
                        guide_text = "TRINKEN";
                        break;
                    
                    case 3:
                        guide_text = "TRANSFER";
                        break;
                    
                    case 4:
                        guide_text = "ERHOLUNG";
                        break;
                    
                    case 5:
                        guide_text = "MILCH 2";
                        break;
                    
                    case 6:
                        guide_text = "PATROUILLE";
                        break;
                    
                    case 7:
                        guide_text = "KLON";
                        break;
                    
                    case 8:
                        guide_text = "F.SCHREIN";
                        break;
                    
                    case 9:
                        guide_text = "R.SCHREIN";
                        break;
                    
                    case 10:
                        guide_text = "S.SCHREIN";
                        break;
                    
                    case 11:
                        guide_text = "L.SCHREIN";
                        break;
                }
                
                break;
            
            case 5:
                switch (button_num)
                {
                    case 0:
                        guide_text = "EXPOSITOR";
                        break;
                    
                    case 1:
                        guide_text = "PARTO 2";
                        break;
                    
                    case 2:
                        guide_text = "BEBER";
                        break;
                    
                    case 3:
                        guide_text = "TRANSFERIR";
                        break;
                    
                    case 4:
                        guide_text = "RECUPERAR";
                        break;
                    
                    case 5:
                        guide_text = "ORDENHA 2";
                        break;
                    
                    case 6:
                        guide_text = "PATRULHA";
                        break;
                    
                    case 7:
                        guide_text = "CLONAR";
                        break;
                    
                    case 8:
                        guide_text = "TEMPLO.S";
                        break;
                    
                    case 9:
                        guide_text = "TEMPLO.P";
                        break;
                    
                    case 10:
                        guide_text = "TEMPLO.E";
                        break;
                    
                    case 11:
                        guide_text = "TEMPLO.L";
                        break;
                }
                
                break;
        }
        
        for (var i = 0; i < ds_list_size(global.new_guide_list); i++)
        {
            if (ds_list_find_value(global.new_guide_list, i) == _type)
            {
                i = ds_list_size(global.new_guide_list);
                guide_new = true;
            }
        }
    }
}

function scr_create_guide_raiding_button()
{
    scr_create_option_button();
    spr_sel = spr_button_guide_sel;
    guide_group = 1;
    
    switch (global.val.language)
    {
        case 0:
            switch (button_num)
            {
                case 0:
                    guide_text = "RAIDING";
                    break;
                
                case 1:
                    guide_text = "TRADER";
                    break;
                
                case 2:
                    guide_text = "SHOP";
                    break;
                
                case 3:
                    guide_text = "BLUEPRINTS";
                    break;
                
                case 4:
                    guide_text = "TROOP LEVEL";
                    break;
                
                case 5:
                    guide_text = "SKILL LEVEL";
                    break;
                
                case 6:
                    guide_text = "CAPTURING";
                    break;
                
                case 7:
                    guide_text = "CASUALTIES";
                    break;
            }
            
            break;
        
        case 9:
            switch (button_num)
            {
                case 0:
                    guide_text = "洗劫";
                    break;
                
                case 1:
                    guide_text = "商人";
                    break;
                
                case 2:
                    guide_text = "商店";
                    break;
                
                case 3:
                    guide_text = "藍圖";
                    break;
                
                case 4:
                    guide_text = "部隊等級";
                    break;
                
                case 5:
                    guide_text = "技能等級";
                    break;
                
                case 6:
                    guide_text = "捕獲";
                    break;
                
                case 7:
                    guide_text = "傷亡";
                    break;
            }
            
            break;
        
        case 2:
            switch (button_num)
            {
                case 0:
                    guide_text = "洗劫";
                    break;
                
                case 1:
                    guide_text = "商人";
                    break;
                
                case 2:
                    guide_text = "商店";
                    break;
                
                case 3:
                    guide_text = "蓝图";
                    break;
                
                case 4:
                    guide_text = "部队等级";
                    break;
                
                case 5:
                    guide_text = "技能等级";
                    break;
                
                case 6:
                    guide_text = "捕获";
                    break;
                
                case 7:
                    guide_text = "伤亡";
                    break;
            }
            
            break;
        
        case 1:
            switch (button_num)
            {
                case 0:
                    guide_text = "襲撃中";
                    break;
                
                case 1:
                    guide_text = "商人";
                    break;
                
                case 2:
                    guide_text = "ショップ";
                    break;
                
                case 3:
                    guide_text = "設計図";
                    break;
                
                case 4:
                    guide_text = "部隊";
                    break;
                
                case 5:
                    guide_text = "スキル";
                    break;
                
                case 6:
                    guide_text = "捕獲";
                    break;
                
                case 7:
                    guide_text = "犠牲者";
                    break;
            }
            
            break;
        
        case 3:
            switch (button_num)
            {
                case 0:
                    guide_text = "습격 중";
                    break;
                
                case 1:
                    guide_text = "거래상";
                    break;
                
                case 2:
                    guide_text = "상점";
                    break;
                
                case 3:
                    guide_text = "설계도";
                    break;
                
                case 4:
                    guide_text = "부대 레벨";
                    break;
                
                case 5:
                    guide_text = "스킬 레벨";
                    break;
                
                case 6:
                    guide_text = "포획";
                    break;
                
                case 7:
                    guide_text = "사상자";
                    break;
            }
            
            break;
        
        case 7:
            switch (button_num)
            {
                case 0:
                    guide_text = "НАБЕГИ";
                    break;
                
                case 1:
                    guide_text = "ТОРГОВЕЦ";
                    break;
                
                case 2:
                    guide_text = "МАГАЗИН";
                    break;
                
                case 3:
                    guide_text = "ЧЕРТЕЖИ";
                    break;
                
                case 4:
                    guide_text = "УР. ВОЙСК";
                    break;
                
                case 5:
                    guide_text = "УР. НАВЫКОВ";
                    break;
                
                case 6:
                    guide_text = "ЗАХВАТ";
                    break;
                
                case 7:
                    guide_text = "ПОТЕРИ";
                    break;
            }
            
            break;
        
        case 4:
            switch (button_num)
            {
                case 0:
                    guide_text = "SAQUEAR";
                    break;
                
                case 1:
                    guide_text = "NEGOCIANTE";
                    break;
                
                case 2:
                    guide_text = "TIENDA";
                    break;
                
                case 3:
                    guide_text = "PLANOS";
                    break;
                
                case 4:
                    guide_text = "NVL.TROPA";
                    break;
                
                case 5:
                    guide_text = "NVL.HAB";
                    break;
                
                case 6:
                    guide_text = "CAPTURA";
                    break;
                
                case 7:
                    guide_text = "BAJAS";
                    break;
            }
            
            break;
        
        case 6:
            switch (button_num)
            {
                case 0:
                    guide_text = "RAIDS";
                    break;
                
                case 1:
                    guide_text = "MARCHAND";
                    break;
                
                case 2:
                    guide_text = "BOUTIQUE";
                    break;
                
                case 3:
                    guide_text = "PLANS";
                    break;
                
                case 4:
                    guide_text = "NV. TROUPES";
                    break;
                
                case 5:
                    guide_text = "NV COMP.";
                    break;
                
                case 6:
                    guide_text = "CAPTURE";
                    break;
                
                case 7:
                    guide_text = "PERTES";
                    break;
            }
            
            break;
        
        case 8:
            switch (button_num)
            {
                case 0:
                    guide_text = "RAUBZUG";
                    break;
                
                case 1:
                    guide_text = "HÄNDLER";
                    break;
                
                case 2:
                    guide_text = "LADEN";
                    break;
                
                case 3:
                    guide_text = "BLAUPAUSEN";
                    break;
                
                case 4:
                    guide_text = "TRUPPEN.LV.";
                    break;
                
                case 5:
                    guide_text = "FÄHIG.LV.";
                    break;
                
                case 6:
                    guide_text = "EINFANGEN";
                    break;
                
                case 7:
                    guide_text = "VERLUSTE";
                    break;
            }
            
            break;
        
        case 5:
            switch (button_num)
            {
                case 0:
                    guide_text = "INVADINDO";
                    break;
                
                case 1:
                    guide_text = "MERCADOR";
                    break;
                
                case 2:
                    guide_text = "LOJA";
                    break;
                
                case 3:
                    guide_text = "DIAGRAMAS";
                    break;
                
                case 4:
                    guide_text = "NVL.TROPAS";
                    break;
                
                case 5:
                    guide_text = "NVL.HAB";
                    break;
                
                case 6:
                    guide_text = "CAPTURAR";
                    break;
                
                case 7:
                    guide_text = "BAIXAS";
                    break;
            }
            
            break;
    }
}

