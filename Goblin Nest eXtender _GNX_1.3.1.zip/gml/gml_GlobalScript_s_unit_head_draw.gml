function scr_draw_unit_head()
{
    switch (drag_type)
    {
        case 2:
            if (!follow)
            {
                scr_draw_head_tiny_icon();
            }
            else
            {
                if (source_id.slot_data.load)
                    draw_sprite(spr_loading, source_id.slot_data.load_index, x - 15, y + 7);
                
                if (unit_data != -1)
                {
                    if (hover)
                    {
                        draw_sprite(spr_char_window, 0, x, y - 24);
                        draw_set_halign(fa_center);
                        draw_text(x + 1, y - 20, unit_data.class_name);
                        draw_sprite(spr_icon, !abs(sign(unit_data.preg_c)) * 3, x + 6, y + 31);
                        
                        if (unit_data.preg_c != -1)
                            draw_text(x - 5, y + 24, floor(unit_data.preg_c));
                        else
                            draw_sprite(spr_infinity, 0, x - 7, y + 26);
                        
                        scr_draw_bar_h(x - 12, y + 34, unit_data.preg_c, unit_data.preg_c_max, 8388736, 25, true);
                        
                        if (source_id.bar_glow_rep != -1)
                        {
                            var _per = (unit_data.preg_c / unit_data.preg_c_max) * 25;
                            var _num = source_id.bar_glow_rep;
                            var _n = min(_num, 1) - clamp(_num - 1, 0, 1);
                            draw_sprite_ext(spr_pixel, 0, x - 12, y + 34, _per, 1, image_angle, c_white, _n * 0.65);
                            
                            if (irandom_range(1, 100) <= 10)
                            {
                                var _system = obj_np.part_system_f;
                                part_particles_create(_system, (x - 13) + _per, y + 34, global.rep_part, 1);
                            }
                        }
                        
                        hover = false;
                    }
                    else
                    {
                        if (floor(unit_data.preg_c) == 0)
                            draw_sprite(spr_icon, 3, x - 15, y + 18);
                        else if (unit_data.preg != -1)
                            draw_sprite(spr_icon, 0, x - 15, y + 18);
                        
                        if (unit_data.milk)
                            draw_sprite(spr_icon, 1, x + 15, y + 18);
                    }
                    
                    if (source_id.slot_data.h_type == 25 && source_id.slot_data.clone_wait != 0)
                    {
                        var _num = 14400 - source_id.slot_data.clone_wait;
                        scr_draw_bar_v(x + 12, y - 5, _num, 14400, 65535, 12);
                    }
                }
            }
            
            break;
        
        case 1:
            scr_draw_head_tiny_icon();
            
            if (hover)
            {
                draw_sprite(spr_prison_char_window, 0, x, y - 10);
                draw_set_halign(fa_center);
                
                if (unit_data.preg_c != -1)
                    draw_text(x - 4, y - 22, floor(unit_data.preg_c));
                else
                    draw_sprite(spr_infinity, 0, x - 8, y - 20);
                
                hover = false;
            }
            
            break;
        
        case -1:
            scr_draw_head_tiny_icon();
            break;
    }
    
    if (unit_data != -1)
        scr_draw_stage_unit_head(x, y, unit_data, true);
}

function scr_draw_head_tiny_icon()
{
    if (global.val.show_head)
    {
        if (unit_data.preg != -1)
            draw_sprite(spr_preg_icon, 1, x - 7, y - 10);
        else if (floor(unit_data.preg_c) == 0)
            draw_sprite(spr_preg_icon, 0, x - 7, y - 10);
        
        if (unit_data.milk)
            draw_sprite(spr_preg_icon, 2, x + 7, y - 10);
    }
}

function scr_draw_stage_unit_head(arg0, arg1, arg2, arg3)
{
    var _class = arg2.class;
    var _skin = arg2.skin;
    var _hair = arg2.hair;
    var _lvl = arg2.lvl;
    var _gnx_icon_drawn = false;
    
    if (ds_map_exists(global.class_registry, _class))
    {
        var _gnx_rc = ds_map_find_value(global.class_registry, _class);
        
        if (variable_struct_exists(_gnx_rc, "icon_spr") && _gnx_rc.icon_spr != -1)
        {
            draw_sprite_ext(_gnx_rc.icon_spr, _skin, arg0, arg1, 1, 1, image_angle, image_blend, image_alpha);
            
            if (_hair != -1 && variable_struct_exists(_gnx_rc, "icon_hair_spr") && _gnx_rc.icon_hair_spr != -1)
                draw_sprite_ext(_gnx_rc.icon_hair_spr, _hair, arg0, arg1, 1, 1, image_angle, image_blend, image_alpha);
            
            _gnx_icon_drawn = true;
        }
    }
    
    if (!_gnx_icon_drawn)
    {
        var _index;
        
        if (_class < 8)
            _index = (_class * 3) + _skin;
        else
            _index = _class + 16;
        
        draw_sprite_ext(spr_unit_icon_head, _index, arg0, arg1, 1, 1, image_angle, image_blend, image_alpha);
        
        if (_hair != -1)
        {
            var _hair_index = (_class * 3) + _hair;
            draw_sprite_ext(spr_unit_icon_hair, _hair_index, arg0, arg1, 1, 1, image_angle, image_blend, image_alpha);
        }
    }
    
    var _x_shift = 0;
    var _y_shift = 14;
    
    if (arg3)
        scr_draw_head_star(arg0, arg1, _x_shift, _y_shift, _lvl);
}

function scr_draw_head_star(arg0, arg1, arg2, arg3, arg4)
{
    switch (arg4)
    {
        case 0:
            draw_sprite_ext(spr_star_icon, 0, arg0 + arg2, arg1 + arg3 + 1, 1, 1, image_angle, image_blend, image_alpha);
            break;
        
        case 1:
            draw_sprite_ext(spr_star_icon, 0, (arg0 + arg2) - 3, arg1 + arg3 + 1, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, arg0 + arg2 + 3, arg1 + arg3 + 1, 1, 1, image_angle, image_blend, image_alpha);
            break;
        
        case 2:
            draw_sprite_ext(spr_star_icon, 0, (arg0 + arg2) - 3, arg1 + arg3, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, arg0 + arg2 + 3, arg1 + arg3, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, arg0 + arg2, arg1 + arg3 + 3, 1, 1, image_angle, image_blend, image_alpha);
            break;
        
        case 3:
            draw_sprite_ext(spr_star_icon, 0, (arg0 + arg2) - 5, arg1 + arg3, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, (arg0 + arg2) - 2, arg1 + arg3 + 3, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, arg0 + arg2 + 2, arg1 + arg3 + 3, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, arg0 + arg2 + 5, arg1 + arg3, 1, 1, image_angle, image_blend, image_alpha);
            break;
        
        case 4:
            draw_sprite_ext(spr_star_icon, 0, (arg0 + arg2) - 6, arg1 + arg3, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, arg0 + arg2, arg1 + arg3, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, (arg0 + arg2) - 3, arg1 + arg3 + 3, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, arg0 + arg2 + 3, arg1 + arg3 + 3, 1, 1, image_angle, image_blend, image_alpha);
            draw_sprite_ext(spr_star_icon, 0, arg0 + arg2 + 6, arg1 + arg3, 1, 1, image_angle, image_blend, image_alpha);
            break;
        
        case 5:
            draw_sprite_ext(spr_star_icon, 1, arg0 + arg2, arg1 + arg3 + 1, 1, 1, image_angle, image_blend, image_alpha);
            break;
        
        case 6:
            draw_sprite_ext(spr_star_icon_fake, 0, arg0 + arg2, arg1 + arg3 + 1, 1, 1, image_angle, image_blend, image_alpha);
            break;
        
        case 7:
            draw_sprite_ext(spr_star_icon_fake_2, 0, arg0 + arg2, arg1 + arg3 + 1, 1, 1, image_angle, image_blend, image_alpha);
            break;
    }
}

function scr_draw_cage_head()
{
    scr_draw_stage_unit_head(x, y, unit_data, true);
    var _raid = obj_np.obj_raid.raid_data.raid_state;
    
    if (_raid == 1 || _raid == 2)
    {
        gpu_set_fog(true, c_black, 0, 0);
        image_alpha = 0.7;
        scr_draw_stage_unit_head(x, y, unit_data, true);
        image_alpha = 1;
        gpu_set_fog(false, c_white, 0, 0);
    }
}

