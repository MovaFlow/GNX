scr_mouse_control();

if (keyboard_check_pressed(ord("K")))
{
    var _n = ds_list_size(global.unit_list);
    
    for (var _i = 0; _i < _n; _i++)
    {
        var _u = ds_list_find_value(global.unit_list, _i);
        
        if (_u != -1)
        {
            _u.class = 14;
            break;
        }
    }
}
