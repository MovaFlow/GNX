// GNX Mod Extender — Loader stub
// All functions moved to gml_GlobalScript_s_initials.gml (v0.2).
// This file is kept as an empty placeholder to avoid UTMT asset removal.
