function scr_create_window_button_list(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7)
{
    var _ver = 8;
    var _w = 40;
    var _col = ceil(arg3 / _ver);
    arg1 -= max(0, ((arg1 + (_w * _col)) - room_width) + 4);
    var _window = instance_create_depth(arg1, arg2, -2200, obj_window);
    
    with (_window)
    {
        sprite_index = spr_pixel;
        image_xscale = sprite_get_width(spr_button_long);
        image_yscale = (sprite_get_height(spr_button_long) - 1) * arg3;
        var _inst = scr_check_least_depth_collide(id);
        
        if (_inst != -1 && _inst.depth <= depth)
            depth = _inst.depth - 1;
        
        interact_type = arg4;
        source_id = arg0;
        activate = false;
        scr_window_draw = scr_draw_window;
        
        with (obj_window)
        {
            if (id != other.id && !gui)
                instance_destroy();
        }
        
        for (var i = 0; i < _col; i++)
            scr_create_button_layout(20 + (i * 40), 7, depth - 20 - (50 * i), min(_ver, arg3 - (i * _ver)), 1, 0, 0, i * _ver, spr_button_long, arg5, id, true, arg6, scr_button_list_step, scr_button_text_draw);
        
        scr_create_button(image_xscale - 7, -4, depth + 1, spr_button_exit, 37, id, scr_create_button_small, -1, scr_draw_hover_button, 0, 0);
        
        if (arg0.slot_data.slot_type == 5 || arg0.slot_data.slot_type == 4)
            scr_create_button(image_xscale - 19, -4, depth + 1, -1, 61, id, scr_create_button_side, scr_button_list_step, scr_draw_hover_button, 0, 0);
        
        if (arg7)
            scr_create_button(image_xscale - 19, -4, depth + 1, spr_button_destroy, 36, id, scr_create_button_small, scr_button_list_step, scr_draw_hover_button, 0, 0);
        
        scr_create_button(image_xscale - 19 - 12, -4, depth + 1, spr_button_swap, 60, id, scr_create_button_swap, scr_button_list_step, scr_draw_hover_button, 0, 0);
    }
}

function scr_create_window_slot_mod(arg0, arg1, arg2, arg3)
{
    var _window = instance_create_depth(arg1, arg2, -2200, obj_window);
    
    with (_window)
    {
        interact_type = 2;
        source_id = arg0;
        drag_type = 0;
        skip_row = 0;
        c_line = make_color_rgb(88, 29, 20);
        reward_info = -1;
        source_id.mod_window = id;
        sprite_index = spr_window_sizable;
        image_xscale = 3;
        
        with (obj_window)
        {
            if (id != other.id && !gui)
                instance_destroy();
        }
        
        var _inst = scr_check_least_depth_collide(id);
        
        if (_inst != -1 && _inst.depth <= depth)
            depth = _inst.depth - 1;
        
        var _icon_array = [];
        var _pos_array = [];
        var _num = 0;
        var _ext = 0;
        var _y_shift = 0;
        
        with (source_id)
        {
            var _array_order = [0, 1, 2, 3, 4, 5, 6, 7, 8, 13, 14];
            var _spr_num = array_length(spr_slot);
            
            for (var i = 0; i < array_length(_array_order); i++)
            {
                for (var ii = 0; ii < _spr_num; ii++)
                {
                    if (_array_order[i] == spr_slot[ii][0] && spr_slot[ii][2])
                    {
                        _icon_array[_num] = i;
                        _pos_array[_num] = ii;
                        _num++;
                        ii = _spr_num;
                    }
                }
                
                if (_array_order[i] == 5 && _num != 0)
                    other.skip_row = _num;
            }
        }
        
        pos_array = _pos_array;
        icon_array = _icon_array;
        var _height_dist = 9;
        
        if (arg0.slot_data.slot_type == 3)
        {
            scr_window_draw = scr_draw_mod_door_window;
            
            for (var i = 0; i < array_length(global.val.mon_num); i++)
            {
                if (global.val.mon_num[i] != -1 && i != 2)
                {
                    array_push(icon_array, i);
                    array_push(pos_array, i + 1);
                    _num++;
                }
            }
            
            var _scale = (7 * (_num - 1)) + (3 * max(0, sign(_num - skip_row)));
            image_yscale = max(1, 1.4 + (_scale * 0.1) + _ext);
            scr_create_button_layout(2, 8 + _y_shift, depth - 1, skip_row * 2, 2, 11, _height_dist, 0, spr_button_arrow, 26, id, false, scr_create_mod_button, -1, -1);
            scr_create_button_layout(7, 13 + _y_shift + (skip_row * _height_dist), depth - 1, _num - skip_row, 1, 0, _height_dist, 0, spr_button_oval, 27, id, false, scr_create_mod_button_circle, -1, -1);
        }
        else
        {
            scr_window_draw = scr_draw_mod_window;
            var _scale = (7 * (_num - 1)) + (3 * (max(0, sign(_num - skip_row)) * sign(skip_row)));
            
            if (arg0.slot_data.slot_type == 0 || arg0.slot_data.slot_type == 2 || arg0.slot_data.slot_type == 1)
            {
                var _data = scr_h_slot_text_data(arg0.slot_data.h_type);
                reward_info = _data.spawn_info;
                
                if (reward_info != -1)
                {
                    reward_info.y_shift = _scale;
                    _ext += 1.1;
                }
            }
            
            image_yscale = max(1, 1.4 + (_scale * 0.1) + _ext);
            
            if (!arg3)
                y -= floor(_scale * 1.25);
            
            if (_num > 0)
            {
                scr_create_button_layout(2, 8 + _y_shift, depth - 1, skip_row * 2, 2, 11, _height_dist, 0, spr_button_arrow, 26, id, false, scr_create_mod_button, -1, -1);
                scr_create_button_layout(7, 9 + _y_shift + (skip_row * _height_dist) + (sign(skip_row) * 4), depth - 1, _num - skip_row, 1, 0, _height_dist, 0, spr_button_oval, 27, id, false, scr_create_mod_button_circle, -1, -1);
                scr_create_button_layout(-8, 4 + _y_shift, depth - 1, _num, 1, 0, _height_dist, 0, spr_mod_icon, -1, id, false, scr_create_mod_icon, -1, -1);
            }
            
            if (arg0.slot_range != -1)
                scr_create_button_mod_range(id, arg0);
        }
        
        scr_create_button(13, -4, depth + 1, spr_button_exit, 37, id, scr_create_button_small_follow, -1, scr_draw_hover_button, 0, 0);
        
        if (arg0.unit_data == -1)
            scr_create_button(1, -4, depth + 1, spr_button_destroy, 36, id, scr_create_button_small_follow, -1, scr_draw_hover_button, 0, 0);
        
        scr_create_button(image_xscale - 14, -4, depth + 1, spr_button_swap, 60, id, scr_create_button_swap_follow, scr_button_list_step, scr_draw_hover_button, 0, 0);
    }
}

function scr_create_button_mod_range(arg0, arg1)
{
    var _button = instance_create_depth(0, 0, -999, obj_button);
    
    with (_button)
    {
        image_xscale = 0;
        image_yscale = 0;
        interact_type = 28;
        source_id = arg0;
        var _set = true;
        var _floor = arg1.slot_data.slot_floor;
        scr_button_draw = scr_draw_mod_range;
        
        switch (arg1.slot_data.h_type)
        {
            case 39:
                _set = false;
                scr_button_draw = scr_draw_l_shrine_range;
                break;
        }
        
        if (_set && ds_map_exists(global.cell_registry, arg1.slot_data.h_type))
        {
            var _rp_range = ds_map_find_value(global.cell_registry, arg1.slot_data.h_type).physical;
            
            if (variable_struct_exists(_rp_range, "range_draw_func"))
            {
                _set = false;
                scr_button_draw = _rp_range.range_draw_func;
                var _log = file_text_open_append(GNX_LOG);
                file_text_write_string(_log, "[GNX] range_draw_func h=" + string(arg1.slot_data.h_type) + "\n");
                file_text_close(_log);
            }
        }
        
        if (_set)
        {
            var _range = arg1.slot_range + global.val.add_range;
            var _slot_x_max = global.slot_x[_floor];
            var _last_pos = ds_list_size(global.slot_list[_floor]) - 1;
            var _pos = ds_list_find_index(global.slot_list[_floor], arg1);
            var _start_pos = max(0, _pos - (_range * 2));
            var _end_pos = min(_last_pos, _pos + (_range * 2));
            var _end_slot = ds_list_find_value(global.slot_list[_floor], _end_pos);
            start_x = max(0, ds_list_find_value(global.slot_list[_floor], _start_pos).x);
            end_x = min(_slot_x_max, _end_slot.x + _end_slot.image_xscale) - start_x;
            y_pos = 175 + (_floor * 140);
        }
    }
}

