function scr_create_slot(arg0, arg1, arg2, arg3)
{
    var _list = global.slot_list[arg1];
    var _x;
    
    if (global.build_side && arg0 != 4)
    {
        arg2--;
        var _prev_slot = ds_list_find_value(_list, arg2);
        _x = _prev_slot.x;
        
        if (arg3)
            _x--;
    }
    else if (arg2 >= (ds_list_size(_list) - 1))
    {
        _x = global.slot_x[arg1];
    }
    else
    {
        var _prev_slot = ds_list_find_value(_list, arg2);
        _x = _prev_slot.x;
    }
    
    var _slot_id = instance_create_depth(0, 0, 0, obj_slot);
    var _slot_w;
    
    with (_slot_id)
    {
        unit_data = -1;
        slot_data = 
        {
            slot_type: arg0,
            slot_floor: arg1,
            anim_struct: -1,
            prop: []
        };
        scr_slot_step = -1;
        slot_range = -1;
        mod_window = -1;
        x = _x;
        y = 175 + (arg1 * 140);
        hover = true;
        h_unit_list = -1;
        
        switch (arg0)
        {
            case 0:
                scr_set_slot_h_base();
                slot_data.base_type = 0;
                spr_base = spr_slot_back;
                image_xscale = 45;
                image_yscale = -74;
                _slot_w = 45;
                clean_id = -1;
                break;
            
            case 1:
                scr_set_slot_h_base();
                slot_data.base_type = 0;
                spr_base = spr_big_slot_back;
                image_xscale = 77;
                image_yscale = -74;
                _slot_w = 77;
                clean_id = -1;
                break;
            
            case 4:
                x++;
                depth = -750;
                image_xscale = 18;
                image_yscale = -108;
                slot_data.index = 0;
                spr_base = spr_bet_pillar;
                _slot_w = 20;
                slot_data.between_type = 1;
                break;
            
            case 5:
                x++;
                depth = -750;
                image_xscale = 9;
                image_yscale = -108;
                slot_data.index = 0;
                spr_base = spr_bet_plank;
                _slot_w = 11;
                slot_data.between_type = 0;
                break;
            
            case 3:
                image_xscale = 45;
                image_yscale = -85;
                slot_data.index = 0;
                spr_base = spr_slot_entrance;
                _slot_w = 45;
                spr_slot = [[4, 0, true, -1]];
                var _index = -1;
                
                with (obj_slot)
                {
                    if (slot_data.slot_type == 3 && slot_data.slot_floor == other.slot_data.slot_floor && variable_struct_exists(slot_data, "mod_index"))
                        _index = slot_data.mod_index;
                }
                
                if (_index == -1)
                {
                    slot_data.mod_index = [0, false, false, true, false];
                }
                else
                {
                    slot_data.mod_index = [];
                    
                    for (var i = 0; i < array_length(_index); i++)
                        array_push(slot_data.mod_index, _index[i]);
                }
                
                break;
            
            case 2:
                scr_set_slot_h_base();
                slot_data.base_type = 4;
                spr_base = spr_tent_back;
                image_xscale = 45;
                image_yscale = -74;
                _slot_w = 45;
                break;
        }
        
        if (spr_base != -1)
        {
            var _num = sprite_get_number(spr_base) - 1;
            slot_data.index = irandom_range(0, _num);
        }
        
        global.slot_x[arg1] += _slot_w;
    }
    
    if (arg2 >= (ds_list_size(_list) - 1) && !global.build_side)
        ds_list_add(_list, _slot_id);
    else
        ds_list_insert(_list, arg2, _slot_id);
    
    scr_shift_slot(_slot_id, _slot_w, arg1);
    
    if (arg3)
        _slot_id = scr_create_slot(5, arg1, arg2 + 1, false);
    
    scr_camera_x_border();
    return _slot_id;
}

function scr_set_slot_h_base()
{
    slot_data.anim_struct = -1;
    slot_data.h_type = -1;
    slot_data.mod_index = [];
    slot_data.mon_placement = [];
    slot_data.mon_timer = [];
    slot_data.max_mon_num = 0;
    slot_data.slot_dirt = -1;
    slot_data.sign_y = 0;
    slot_data.allow_preg = false;
    scr_slot_draw_special = -1;
    slot_data.h_wait = 0;
    slot_data.h_loop = 0;
    slot_data.h_step = 0;
    slot_data.sq_x = -1;
    slot_data.sq_y = -1;
    slot_data.sp_x = -1;
    slot_data.sp_y = -1;
    slot_data.sp_anim_x = 0;
    slot_data.sp_anim_y = 0;
    slot_data.load = false;
    slot_data.load_index = 0;
    slot_data.carry = false;
    sp_spr = -1;
    scr_slot_step = -1;
    h_unit_list = [];
    spawn_part = [];
    spawn_stream = false;
    slot_sfx = -1;
    slot_range = -1;
    slot_h = true;
}

function scr_occupy_slot(arg0, arg1, arg2, arg3)
{
    with (arg0)
    {
        animation_end = false;
        
        if (arg1 != -1)
        {
            unit_data = arg1;
            slot_data.anim_struct.char_state = 0;
            slot_data.anim_struct.ff = true;
            slot_data.h_wait = irandom_range(240, 360);
            slot_data.h_step = 0;
            slot_data.h_loop = 0;
            slot_data.load = false;
            slot_data.carry = false;
            var _old_h_unit_list = h_unit_list;
            h_unit_list = [];
            scr_slot_step = scr_slot_state;
            scr_set_slot_spr_part(arg3);
            var _num = array_length(spr_slot);
            
            for (var i = 0; i < _num; i++)
            {
                var _type = spr_slot[i][0];
                
                if (_type == 5)
                    slot_data.mod_index[i] = 1;
            }
            
            scr_create_slot_head(false, id);
            
            if (instance_exists(obj_window))
            {
                with (obj_window)
                {
                    if (interact_type == 2)
                    {
                        if (source_id == arg0)
                        {
                            var _x = x;
                            var _y = y;
                            
                            with (obj_button)
                            {
                                if (instance_exists(source_id) && source_id.object_index == obj_window && source_id.source_id == arg0 && trigger == true && global.click_lock)
                                {
                                    global.click_lock = false;
                                    instance_destroy();
                                }
                            }
                            
                            with (arg0)
                                scr_create_window_slot_mod(id, _x, _y, true);
                            
                            if (arg2)
                                instance_destroy();
                        }
                        
                        if (!arg2)
                            instance_destroy();
                    }
                }
            }
            
            switch (slot_data.h_type)
            {
                case 11:
                    if (unit_data.milk)
                        slot_data.drink_num = 8;
                    else
                        slot_data.drink_num = 0;
                    
                    break;
                
                case 30:
                    if (unit_data.milk)
                        slot_data.milk_num = 4;
                    else
                        slot_data.milk_num = 0;
                    
                    break;
                
                case 17:
                    if (slot_data.mon_placement[0] != -1)
                    {
                        with (slot_data.mon_placement[0])
                        {
                            if (mon_data.carry_start_id != -1)
                            {
                                mon_data.carry_start_id.slot_data.load = false;
                                mon_data.carry_start_id.slot_data.carry = false;
                            }
                            
                            if (mon_data.carry_end_id != -1)
                            {
                                mon_data.carry_end_id.slot_data.load = false;
                                mon_data.carry_start_id.slot_data.carry = false;
                            }
                        }
                    }
                    
                    h_unit_list = _old_h_unit_list;
                    scr_unit_removal(false, true, false, false, -1);
                    break;
                
                case 24:
                    slot_data.visual = true;
                    slot_data.anim_struct.char_state = 0;
                    break;
                
                case 25:
                    scr_slot_step = scr_slot_h_clone_idle;
                    break;
                
                case 37:
                    if (unit_data.lvl != 7)
                        bar_glow_rep = 0;
                    
                    break;
            }
            
            if (ds_map_exists(global.cell_registry, slot_data.h_type))
            {
                var _rp_cell = ds_map_find_value(global.cell_registry, slot_data.h_type);
                
                if (variable_struct_exists(_rp_cell, "gnx_price"))
                {
                    var _rp = _rp_cell.physical;
                    
                    if (variable_struct_exists(_rp, "visual") && _rp.visual)
                        slot_data.visual = true;
                    
                    if (variable_struct_exists(_rp, "anim_struct_overrides"))
                    {
                        var _ov = _rp.anim_struct_overrides;
                        
                        if (variable_struct_exists(_ov, "char_state"))
                            slot_data.anim_struct.char_state = _ov.char_state;
                    }
                }
            }
        }
        else
        {
            var _unit_data = unit_data;
            unit_data = -1;
            scr_slot_step = -1;
            slot_data.load = false;
            slot_data.carry = false;
            scr_create_anim_struct();
            scr_unit_removal(false, true, true, false, -1);
            var _num = array_length(spr_slot);
            
            for (var i = 0; i < _num; i++)
            {
                var _type = spr_slot[i][0];
                
                if (_type == 7 || _type == 8 || _type == 9 || _type == 6 || _type == 10 || _type == 11)
                {
                    spr_slot[i][1] = -1;
                    spr_slot[i][3] = -1;
                    
                    if (spr_slot[i][2] != -2)
                        spr_slot[i][2] = false;
                }
                
                if (_type == 5)
                    slot_data.mod_index[i] = 0;
            }
            
            if (array_length(slot_data.prop) > 0)
            {
                var _prop_id = -1;
                var _prop_num = array_length(slot_data.prop);
                
                for (var i = 0; i < _prop_num; i++)
                {
                    if (slot_data.prop[i].prop_type == 40)
                        _prop_id = slot_data.prop[i].prop_id;
                }
                
                if (_prop_id != -1)
                {
                    with (_prop_id)
                    {
                        if (slot_id.slot_data.h_type == 5)
                        {
                            if (!prop_data.spawn)
                            {
                                array_delete(slot_id.slot_data.prop, 0, 1);
                                instance_destroy();
                            }
                            else if ((floor(image_index + 1) % 6) != 0)
                            {
                                var _skin = floor(image_index / 6);
                                image_index = 5 + (_skin * 6);
                            }
                        }
                        else
                        {
                            array_delete(slot_id.slot_data.prop, 0, 1);
                            instance_destroy();
                        }
                    }
                }
            }
            
            switch (slot_data.h_type)
            {
                case 36:
                    slot_data.anim_struct.milk_index = -1;
                    slot_data.anim_struct.milk_timer = -1;
                    slot_data.anim_struct.milk_spd = -1;
                    slot_data.anim_struct.blink_index = -1;
                    slot_data.anim_struct.blink_timer = 0;
                    break;
                
                case 4:
                    if (array_length(slot_data.prop) > 0)
                    {
                        if (instance_exists(slot_data.prop[0].prop_id))
                        {
                            with (slot_data.prop[0].prop_id)
                                instance_destroy();
                        }
                        
                        array_delete(slot_data.prop, 0, 1);
                    }
                    
                    break;
                
                case 11:
                    if (slot_data.drink_num != 8)
                    {
                        if (_unit_data != -1)
                        {
                            if (!variable_struct_exists(_unit_data, "milk"))
                                _unit_data.milk = false;
                            else
                                _unit_data.milk = false;
                        }
                    }
                    
                    break;
                
                case 30:
                    if (slot_data.milk_num != 4)
                    {
                        if (_unit_data != -1)
                        {
                            if (!variable_struct_exists(_unit_data, "milk"))
                                _unit_data.milk = false;
                            else
                                _unit_data.milk = false;
                            
                            if (_unit_data.class == 9)
                                _unit_data.scr_wait = 0;
                        }
                    }
                    
                    break;
                
                case 17:
                    for (var i = 0; i < array_length(h_unit_list); i++)
                    {
                        if (h_unit_list[i].mon_data.carry_start_id != -1)
                        {
                            h_unit_list[i].mon_data.carry_start_id.slot_data.load = false;
                            h_unit_list[i].mon_data.carry_start_id.slot_data.carry = false;
                        }
                        
                        if (h_unit_list[i].mon_data.carry_end_id != -1)
                        {
                            h_unit_list[i].mon_data.carry_end_id.slot_data.load = false;
                            h_unit_list[i].mon_data.carry_start_id.slot_data.carry = false;
                        }
                    }
                    
                    slot_data.visual = true;
                    scr_slot_step = scr_slot_state;
                    slot_data.anim_struct.char_state = 0;
                    break;
                
                case 24:
                    slot_data.visual = true;
                    slot_data.anim_struct.char_state = 0;
                    break;
                
                case 37:
                    bar_glow_rep = -1;
                    break;
            }
            
            if (ds_map_exists(global.cell_registry, slot_data.h_type))
            {
                var _rp_unoccupy = ds_map_find_value(global.cell_registry, slot_data.h_type).physical;
                
                if (variable_struct_exists(_rp_unoccupy, "scr_unoccupy"))
                {
                    var _log = file_text_open_append(GNX_LOG);
                    file_text_write_string(_log, "[GNX] scr_unoccupy h=" + string(slot_data.h_type) + "\n");
                    file_text_close(_log);
                    script_execute(_rp_unoccupy.scr_unoccupy);
                }
            }
            
            if (instance_exists(obj_window))
            {
                with (obj_window)
                {
                    if (interact_type == 2)
                    {
                        if (source_id == arg0)
                        {
                            var _x = x;
                            var _y = y;
                            
                            with (obj_button)
                            {
                                if (source_id.object_index == obj_window && source_id.source_id == arg0 && trigger == true && global.click_lock)
                                {
                                    global.click_lock = false;
                                    instance_destroy();
                                }
                            }
                            
                            with (arg0)
                                scr_create_window_slot_mod(id, _x, _y, true);
                            
                            if (arg2)
                                instance_destroy();
                        }
                        
                        if (!arg2)
                            instance_destroy();
                    }
                }
            }
            
            return _unit_data;
        }
    }
}

function scr_set_slot_spr_part(arg0)
{
    var _unit_stat = unit_data;
    slot_data.anim_struct.spr_type = arg0;
    var _spr = scr_set_class_spr_data(_unit_stat, arg0, scr_slot_draw_special);
    
    if (!is_array(_spr))
        exit;
    
    var _spr_array = _spr[0];
    var _spr_c_array = _spr[1];
    
    if (!is_array(_spr_c_array))
        exit;
    
    if (_spr_array != -1)
    {
        if (!is_array(spr_slot))
            exit;
        
        var _num = array_length(spr_slot);
        
        for (var i = 0; i < _num; i++)
        {
            if (!is_array(spr_slot[i]))
                continue;
            
            var _type = spr_slot[i][0];
            
            switch (_type)
            {
                case 10:
                    spr_slot[i][1] = _spr_array[1];
                    spr_slot[i][3] = _spr_c_array[1];
                    spr_slot[i][5] = _spr_c_array[0];
                    break;
                
                case 6:
                    spr_slot[i][1] = _spr_array[2];
                    spr_slot[i][3] = _spr_c_array[2];
                    
                    if (spr_slot[i][2] != -2)
                        spr_slot[i][2] = true;
                    
                    break;
                
                case 7:
                    spr_slot[i][1] = _spr_array[3];
                    
                    if (spr_slot[i][2] != -2 && _spr_c_array[3] != -1)
                    {
                        spr_slot[i][3] = _spr_c_array[3];
                        spr_slot[i][2] = true;
                    }
                    
                    break;
                
                case 8:
                    spr_slot[i][1] = _spr_array[4];
                    spr_slot[i][3] = _spr_c_array[4];
                    
                    if (spr_slot[i][2] != -2)
                        spr_slot[i][2] = true;
                    
                    break;
                
                case 9:
                    spr_slot[i][1] = _spr_array[5];
                    spr_slot[i][3] = _spr_c_array[5];
                    break;
                
                case 11:
                    spr_slot[i][1] = _spr_array[6];
                    break;
            }
        }
    }
    
    if (slot_data.h_type == 27 || slot_data.h_type == 28 || slot_data.h_type == 31 || slot_data.h_type == 32 || slot_data.h_type == 29)
    {
        var _del = true;
        
        if ((arg0 == 0 || arg0 == 2 || arg0 == 3) && slot_data.h_step <= 2)
        {
            if (array_length(h_unit_list) == 0)
            {
                h_unit_list[0] = instance_create_depth(x, y, depth - 10, obj_tent);
                
                with (h_unit_list[0])
                {
                    source_id = other.id;
                    mon_data = {};
                    mon_data.h_type = other.slot_data.h_type;
                    mon_data.index = 0;
                    spr_type = spr_h_tent_mon;
                }
            }
            else if (arg0 == 3)
            {
                with (h_unit_list[0])
                    spr_type = spr_h_tent_ej_mon;
            }
            
            _del = false;
        }
        
        if (_del)
        {
            if (array_length(h_unit_list) != 0)
            {
                with (h_unit_list[0])
                    instance_destroy();
                
                h_unit_list = [];
            }
        }
    }
}

function scr_slot_state()
{
    if (variable_struct_exists(slot_data, "sp_y") && is_array(slot_data.sp_y) && array_length(slot_data.sp_y) < 2)
        slot_data.sp_y = [slot_data.sp_y[0], slot_data.sp_y[0]];

    if (variable_struct_exists(slot_data, "sq_y") && is_array(slot_data.sq_y) && array_length(slot_data.sq_y) < 2)
        slot_data.sq_y = [slot_data.sq_y[0], slot_data.sq_y[0]];
    
    animation_end = false;
    
    switch (slot_data.anim_struct.char_state)
    {
        case 0:
            script_execute(scr_slot.idle);
            break;
        
        case 1:
            if (!variable_struct_exists(scr_slot, "h"))
            {
                var _f = file_text_open_append(GNX_LOG);
                file_text_write_string(_f, "[GNX] scr_slot_state: scr_slot.h missing — h_type=" + string(slot_data.h_type) + " h_step=" + string(slot_data.h_step));
                file_text_writeln(_f);
                file_text_close(_f);
                slot_data.anim_struct.char_state = 0;
                slot_data.anim_struct.ff = true;
                break;
            }
            script_execute(scr_slot.h[slot_data.h_step]);
            break;
        
        case 2:
            break;
        
        case 11:
            script_execute(scr_slot.none);
            break;
    }
}

function scr_shift_slot(arg0, arg1, arg2)
{
    var _pos = ds_list_find_index(global.slot_list[arg2], arg0) + 1;
    var _num = ds_list_size(global.slot_list[arg2]) - _pos;
    
    for (var i = 0; i < _num; i++)
    {
        var _id = ds_list_find_value(global.slot_list[arg2], _pos + i);
        
        with (_id)
            x += arg1;
    }
}

function scr_add_new_slot_h_type(arg0, arg1)
{
    var _array = [];
    var _num = 0;
    var _set = false;
    var _button_group, _order_array, _base_array;
    
    if (!_set)
    {
        _order_array = global.breed_order;
        
        for (var i = 0; i < array_length(_order_array); i++)
        {
            if (arg0 == _order_array[i])
            {
                array_push(global.unlock.breed, arg0);
                _base_array = global.unlock.breed;
                _button_group = 10;
                _set = true;
            }
        }
    }
    
    if (!_set)
    {
        _order_array = global.utility_order;
        
        for (var i = 0; i < array_length(_order_array); i++)
        {
            if (arg0 == _order_array[i])
            {
                array_push(global.unlock.utility, arg0);
                _base_array = global.unlock.utility;
                _button_group = 11;
                _set = true;
            }
        }
    }
    
    if (!_set)
    {
        _order_array = global.pleasure_order;
        
        for (var i = 0; i < array_length(_order_array); i++)
        {
            if (arg0 == _order_array[i])
            {
                array_push(global.unlock.pleasure, arg0);
                _base_array = global.unlock.pleasure;
                _button_group = 12;
                _set = true;
            }
        }
    }
    
    if (!_set)
    {
        _order_array = global.b_breed_order;
        
        for (var i = 0; i < array_length(_order_array); i++)
        {
            if (arg0 == _order_array[i])
            {
                array_push(global.unlock.b_breed, arg0);
                _base_array = global.unlock.b_breed;
                _button_group = 13;
                _set = true;
            }
        }
    }
    
    if (!_set)
    {
        _order_array = global.b_utility_order;
        
        for (var i = 0; i < array_length(_order_array); i++)
        {
            if (arg0 == _order_array[i])
            {
                array_push(global.unlock.b_utility, arg0);
                _base_array = global.unlock.b_utility;
                _button_group = 14;
                _set = true;
            }
        }
    }
    
    if (!_set)
    {
        _order_array = global.b_pleasure_order;
        
        for (var i = 0; i < array_length(_order_array); i++)
        {
            if (arg0 == _order_array[i])
            {
                array_push(global.unlock.b_other, arg0);
                _base_array = global.unlock.b_other;
                _button_group = 15;
                _set = true;
            }
        }
    }
    
    if (!_set)
    {
        _order_array = global.t_breed_order;
        
        for (var i = 0; i < array_length(_order_array); i++)
        {
            if (arg0 == _order_array[i])
            {
                array_push(global.unlock.t_breed, arg0);
                _base_array = global.unlock.t_breed;
                _button_group = 16;
                _set = true;
            }
        }
    }
    
    if (!_set)
    {
        _order_array = global.t_utility_order;
        
        for (var i = 0; i < array_length(_order_array); i++)
        {
            if (arg0 == _order_array[i])
            {
                array_push(global.unlock.t_utility, arg0);
                _base_array = global.unlock.t_utility;
                _button_group = 17;
                _set = true;
            }
        }
    }
    
    scr_rearrange_buttons(_button_group, _order_array, _base_array);
    var _data = 
    {
        slot_type: arg0,
        prop_type: -1,
        between_type: -1
    };
    ds_list_add(global.new_button_list, _data);
    scr_check_add_guide(arg0);
    
    if (arg1)
        scr_pop_up_create(13);
    
    scr_check_steam_achievement(11);
}

function scr_add_new_prop_type(arg0, arg1)
{
    var _array = [];
    var _num = 0;
    var _set = false;
    var _order_array = global.prop_order_top;
    var _button_group, _base_array;
    
    for (var i = 0; i < array_length(_order_array); i++)
    {
        if (arg0 == _order_array[i])
        {
            _set = true;
            array_push(global.unlock.edit_top, arg0);
            _base_array = global.unlock.edit_top;
            _button_group = 7;
        }
    }
    
    if (_set)
        scr_rearrange_buttons(_button_group, _order_array, _base_array);
    
    _set = false;
    _order_array = global.prop_order_mid;
    
    for (var i = 0; i < array_length(_order_array); i++)
    {
        if (arg0 == _order_array[i])
        {
            _set = true;
            array_push(global.unlock.edit_mid, arg0);
            _base_array = global.unlock.edit_mid;
            _button_group = 8;
        }
    }
    
    if (_set)
        scr_rearrange_buttons(_button_group, _order_array, _base_array);
    
    _set = false;
    _order_array = global.prop_order_bot;
    
    for (var i = 0; i < array_length(_order_array); i++)
    {
        if (arg0 == _order_array[i])
        {
            _set = true;
            array_push(global.unlock.edit_bot, arg0);
            _base_array = global.unlock.edit_bot;
            _button_group = 9;
        }
    }
    
    if (_set)
        scr_rearrange_buttons(_button_group, _order_array, _base_array);
    
    var _data = 
    {
        slot_type: -1,
        prop_type: arg0,
        between_type: -1
    };
    ds_list_add(global.new_button_list, _data);
    
    if (arg1)
        scr_pop_up_create(14);
    
    scr_check_steam_achievement(11);
}

function scr_add_new_between_type(arg0, arg1)
{
    var _set = false;
    var _order_array = global.between_order;
    var _button_group, _base_array;
    
    for (var i = 0; i < array_length(_order_array); i++)
    {
        if (arg0 == _order_array[i])
        {
            if (arg0 == 1)
                array_push(global.unlock.edit_between, 0);
            
            array_push(global.unlock.edit_between, arg0);
            _base_array = global.unlock.edit_between;
            _button_group = 6;
            _set = true;
        }
    }
    
    scr_rearrange_buttons(_button_group, _order_array, _base_array);
    var _data = 
    {
        slot_type: -1,
        prop_type: -1,
        between_type: arg0
    };
    ds_list_add(global.new_button_list, _data);
    
    if (arg1)
        scr_pop_up_create(14);
    
    scr_check_steam_achievement(11);
}

function scr_rearrange_buttons(arg0, arg1, arg2)
{
    var _array = [];
    var _num = 0;
    var _num_1 = array_length(arg1);
    var _num_2 = array_length(arg2);
    
    for (var i = 0; i < _num_1; i++)
    {
        for (var ii = 0; ii < _num_2; ii++)
        {
            if (arg2[ii] == arg1[i])
            {
                _array[_num] = arg2[ii];
                _num++;
                ii = _num_2;
            }
        }
    }
    
    switch (arg0)
    {
        case 10:
            global.unlock.breed = _array;
            break;
        
        case 11:
            global.unlock.utility = _array;
            break;
        
        case 12:
            global.unlock.pleasure = _array;
            break;
        
        case 13:
            global.unlock.b_breed = _array;
            break;
        
        case 14:
            global.unlock.b_utility = _array;
            break;
        
        case 15:
            global.unlock.b_other = _array;
            break;
        
        case 16:
            global.unlock.t_breed = _array;
            break;
        
        case 17:
            global.unlock.t_utility = _array;
            break;
        
        case 6:
            global.unlock.edit_between = _array;
            break;
        
        case 7:
            global.unlock.edit_top = _array;
            break;
        
        case 8:
            global.unlock.edit_mid = _array;
            break;
        
        case 9:
            global.unlock.edit_bot = _array;
            break;
    }
}

function scr_destroy_all_slot_prop()
{
    var _num = array_length(slot_data.prop);
    
    for (var i = 0; i < _num; i++)
    {
        with (slot_data.prop[i].prop_id)
            instance_destroy();
    }
}

function scr_check_slot_availability(arg0, arg1, arg2)
{
    var _result = false;
    var _unit_data = arg1.unit_data;
    var _old_unit_data = unit_data;
    
    with (arg0)
    {
        switch (slot_data.slot_type)
        {
            case 0:
                if (slot_data.anim_struct != -1 && slot_h)
                    _result = true;
                
                if (_result && slot_data.h_type == 5 && array_length(slot_data.prop) > 0)
                {
                    _result = false;
                    
                    if (arg2)
                        scr_pop_up_create(16);
                }
                
                if (_result && _old_unit_data != -1 && arg1.drag_type == 2 && arg1.source_id.slot_data.h_type == 5 && array_length(arg1.source_id.slot_data.prop) > 0)
                {
                    _result = false;
                    
                    if (arg2)
                        scr_pop_up_create(16);
                }
                
                if (_result && _old_unit_data != -1 && arg1.drag_type == 2 && (arg1.source_id.slot_data.h_type == 36 || arg1.source_id.slot_data.h_type == 37 || arg1.source_id.slot_data.h_type == 38 || arg1.source_id.slot_data.h_type == 39))
                {
                    if (_old_unit_data != -1 && arg1.unit_data.class != _old_unit_data.class)
                    {
                        _result = false;
                        
                        if (arg2)
                            scr_pop_up_create(0);
                    }
                }
                
                if (_unit_data.class == 11)
                {
                    _result = false;
                    
                    if (arg2)
                        scr_pop_up_create(0);
                }
                
                if (_result && _old_unit_data != -1 && arg1.drag_type == 2 && arg1.source_id.slot_data.h_type >= 26 && arg1.source_id.slot_data.h_type < 35 && (_old_unit_data.preg != -1 && _old_unit_data.preg != 2))
                {
                    _result = false;
                    
                    if (arg2)
                        scr_pop_up_create(31);
                }
                
                if (_result && ds_map_exists(global.cell_registry, slot_data.h_type))
                {
                    var _rp_req0 = ds_map_find_value(global.cell_registry, slot_data.h_type).physical;
                    
                    if (variable_struct_exists(_rp_req0, "required_class"))
                    {
                        var _req0 = _rp_req0.required_class;
                        var _class_ok0 = false;
                        
                        if (is_array(_req0))
                        {
                            for (var _ri0 = 0; _ri0 < array_length(_req0); _ri0++)
                            {
                                if (_unit_data.class == _req0[_ri0])
                                {
                                    _class_ok0 = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            _class_ok0 = _unit_data.class == _req0;
                        }
                        
                        var _log0 = file_text_open_append(GNX_LOG);
                        file_text_write_string(_log0, "[GNX] required_class h=" + string(slot_data.h_type) + " class=" + string(_unit_data.class) + " ok=" + string(_class_ok0) + "\n");
                        file_text_close(_log0);
                        
                        if (!_class_ok0)
                        {
                            _result = false;
                            
                            if (arg2)
                                scr_pop_up_create(0);
                        }
                    }
                }
                
                break;
            
            case 1:
                if (slot_data.anim_struct != -1 && slot_h)
                    _result = true;
                
                if (_result && _old_unit_data != -1 && arg1.drag_type == 2 && (arg1.source_id.slot_data.h_type == 38 || arg1.source_id.slot_data.h_type == 36 || arg1.source_id.slot_data.h_type == 37 || arg1.source_id.slot_data.h_type == 39))
                {
                    if (_old_unit_data != -1 && arg1.unit_data.class != _old_unit_data.class)
                    {
                        _result = false;
                        
                        if (arg2)
                            scr_pop_up_create(0);
                    }
                }
                
                if (_result && ((_unit_data.class == 11 && slot_data.h_type != 37) || (slot_data.h_type == 37 && _unit_data.class != 11)))
                {
                    _result = false;
                    
                    if (arg2)
                        scr_pop_up_create(0);
                }
                
                if (_result && _old_unit_data != -1 && arg1.drag_type == 2 && arg1.source_id.slot_data.h_type >= 26 && arg1.source_id.slot_data.h_type < 35 && (_old_unit_data.preg != -1 && _old_unit_data.preg != 2))
                {
                    _result = false;
                    
                    if (arg2)
                        scr_pop_up_create(31);
                }
                
                if (_result)
                {
                    switch (slot_data.h_type)
                    {
                        case 37:
                            if (_unit_data.class != 11)
                            {
                                _result = false;
                                
                                if (arg2)
                                    scr_pop_up_create(0);
                            }
                            
                            break;
                        
                        case 38:
                            if (_unit_data.class != 12)
                            {
                                _result = false;
                                
                                if (arg2)
                                    scr_pop_up_create(0);
                            }
                            
                            break;
                        
                        case 36:
                            if (_unit_data.class != 9)
                            {
                                _result = false;
                                
                                if (arg2)
                                    scr_pop_up_create(0);
                            }
                            
                            break;
                        
                        case 39:
                            if (_unit_data.class != 8)
                            {
                                _result = false;
                                
                                if (arg2)
                                    scr_pop_up_create(0);
                            }
                            
                            break;
                    }
                    
                    if (_result && ds_map_exists(global.cell_registry, slot_data.h_type))
                    {
                        var _rp_req = ds_map_find_value(global.cell_registry, slot_data.h_type).physical;
                        
                        if (variable_struct_exists(_rp_req, "required_class"))
                        {
                            var _req = _rp_req.required_class;
                            var _class_ok = false;
                            
                            if (is_array(_req))
                            {
                                for (var _ri = 0; _ri < array_length(_req); _ri++)
                                {
                                    if (_unit_data.class == _req[_ri])
                                    {
                                        _class_ok = true;
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                _class_ok = _unit_data.class == _req;
                            }
                            
                            var _log = file_text_open_append(GNX_LOG);
                            file_text_write_string(_log, "[GNX] required_class h=" + string(slot_data.h_type) + " class=" + string(_unit_data.class) + " ok=" + string(_class_ok) + "\n");
                            file_text_close(_log);
                            
                            if (!_class_ok)
                            {
                                _result = false;
                                
                                if (arg2)
                                    scr_pop_up_create(0);
                            }
                        }
                    }
                }
                
                break;
            
            case 2:
                if (slot_data.anim_struct != -1 && slot_h)
                    _result = true;
                
                if (_result && (arg1.drag_type == 2 || arg1.drag_type == 1) && (_unit_data.preg == 1 || (_unit_data.preg != -1 && _unit_data.preg != 2)))
                {
                    _result = false;
                    
                    if (arg2)
                        scr_pop_up_create(31);
                }
                
                if (_result && _old_unit_data != -1 && arg1.drag_type == 2 && (arg1.source_id.slot_data.h_type == 36 || arg1.source_id.slot_data.h_type == 37 || arg1.source_id.slot_data.h_type == 38 || arg1.source_id.slot_data.h_type == 39))
                {
                    if (_old_unit_data != -1 && arg1.unit_data.class != _old_unit_data.class)
                    {
                        _result = false;
                        
                        if (arg2)
                            scr_pop_up_create(0);
                    }
                }
                
                if (_unit_data.class == 11)
                {
                    _result = false;
                    
                    if (arg2)
                        scr_pop_up_create(0);
                }
                
                break;
        }
    }
    
    return _result;
}

function scr_check_drink_slot_range(arg0, arg1, arg2)
{
    arg1 += global.val.add_range;
    var _start_pos = max(0, arg0 - (arg1 * 2));
    var _end_pos = arg0 + (arg1 * 2);
    var _dist = (_end_pos - _start_pos) + 1;
    var _slot_dist = 100;
    var _drink_id = -1;
    
    for (var i = 0; i < _dist; i++)
    {
        var _c_pos = _start_pos + i;
        var _slot_id = ds_list_find_value(global.slot_list[arg2], _c_pos);
        
        if (_slot_id != undefined && _slot_id.slot_data.slot_type == 0 && _slot_id.slot_data.h_type == 11 && _slot_id.unit_data != -1 && array_length(_slot_id.h_unit_list) < 2 && _slot_id.slot_data.drink_num > 0)
        {
            if (abs(arg0 - _c_pos) < _slot_dist)
            {
                _slot_dist = abs(arg0 - _c_pos);
                _drink_id = _slot_id;
            }
        }
    }
    
    return _drink_id;
}

function scr_check_carry_slot_range(arg0)
{
    var _start_id = -1;
    var _flip = -1;
    var _count = (arg0 + global.val.add_range) * 4;
    var _set_mon = false;
    var _carry_exe = -1;
    var _floor = slot_data.slot_floor;
    var _pos = ds_list_find_index(global.slot_list[_floor], id);
    var _slot_pos = [];
    var _allow = false;
    var _cell_spe = -1;
    var _mon_type = scr_mon_find_placement();
    
    if (_mon_type != -1)
    {
        if (slot_data.visual && unit_data != -1)
        {
            var _c_slot_id = id;
            
            if (unit_data.preg != -1)
            {
                for (var i = 0; i < _count; i++)
                {
                    var _t_pos = _pos + (((i div 2) + 1) * _flip);
                    _flip *= -1;
                    var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                    
                    if (_t_slot_id != undefined && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && (_t_slot_id.slot_data.h_type == 5 || _t_slot_id.slot_data.h_type == 12) && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1 && array_length(_t_slot_id.slot_data.prop) == 0)
                    {
                        i = _count;
                        _set_mon = true;
                        _slot_pos = [_c_slot_id, _t_slot_id];
                    }
                }
            }
            else
            {
                if (unit_data.milk)
                {
                    for (var i = 0; i < _count; i++)
                    {
                        var _t_pos = _pos + (((i div 2) + 1) * _flip);
                        _flip *= -1;
                        var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                        
                        if (_t_slot_id != undefined && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && _t_slot_id.slot_data.h_type == 11 && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                        {
                            i = _count;
                            _set_mon = true;
                            _slot_pos = [_c_slot_id, _t_slot_id];
                        }
                    }
                }
                
                if (!_set_mon && unit_data.milk)
                {
                    for (var i = 0; i < _count; i++)
                    {
                        var _t_pos = _pos + (((i div 2) + 1) * _flip);
                        _flip *= -1;
                        var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                        
                        if (_t_slot_id != undefined && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1 || (_t_slot_id.slot_data.slot_type == 2 && _t_slot_id.slot_data.h_type == 30)) && (_t_slot_id.slot_data.h_type == 4 || _t_slot_id.slot_data.h_type == 30) && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                        {
                            i = _count;
                            _set_mon = true;
                            _slot_pos = [_c_slot_id, _t_slot_id];
                        }
                    }
                }
                
                if (!_set_mon)
                {
                    switch (unit_data.class)
                    {
                        case 8:
                            _cell_spe = 39;
                            break;
                        
                        case 12:
                            _cell_spe = 38;
                            break;
                        
                        case 9:
                            _cell_spe = 36;
                            break;
                    }
                    
                    if (_cell_spe != -1)
                    {
                        for (var i = 0; i < _count; i++)
                        {
                            var _t_pos = _pos + (((i div 2) + 1) * _flip);
                            _flip *= -1;
                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                            
                            if (_t_slot_id != undefined && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.slot_data.h_type == _cell_spe && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                            {
                                i = _count;
                                _set_mon = true;
                                _slot_pos = [_c_slot_id, _t_slot_id];
                            }
                        }
                    }
                    
                    if (!_set_mon)
                    {
                        for (var i = 0; i < _count; i++)
                        {
                            var _t_pos = _pos + (((i div 2) + 1) * _flip);
                            _flip *= -1;
                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                            
                            if (_t_slot_id != undefined && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.slot_data.allow_preg && (_t_slot_id.slot_data.h_type <= 26 || ds_map_exists(global.cell_registry, _t_slot_id.slot_data.h_type)) && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                            {
                                i = _count;
                                _set_mon = true;
                                _slot_pos = [_c_slot_id, _t_slot_id];
                            }
                        }
                    }
                }
            }
        }
        else
        {
            var _slot_pos_dist = 0;
            var _old_slot_pos_dist = 1000000;
            var _current_slot_id = -1;
            var _preg_current_slot_id = -1;
            var _array_rec_pos = [];
            
            for (var i = 0; i < _count; i++)
            {
                var _c_pos = _pos + (((i div 2) + 1) * _flip);
                _flip *= -1;
                var _c_slot_id = ds_list_find_value(global.slot_list[_floor], _c_pos);
                
                if (_c_slot_id != undefined)
                    array_push(_array_rec_pos, _c_pos);
            }
            
            for (var i = 0; i < _count; i++)
            {
                var _c_pos = _pos + (((i div 2) + 1) * _flip);
                _flip *= -1;
                var _c_slot_id = ds_list_find_value(global.slot_list[_floor], _c_pos);
                
                if (_c_slot_id != undefined && _c_slot_id.slot_data.anim_struct != -1 && _c_slot_id.unit_data != -1 && (!_c_slot_id.slot_data.carry || !_c_slot_id.slot_data.load) && (_c_slot_id.slot_data.slot_type == 0 || (_c_slot_id.slot_data.slot_type == 1 && _c_slot_id.slot_data.h_type != 37) || (_c_slot_id.slot_data.slot_type == 2 && _c_slot_id.slot_data.h_type == 30)))
                {
                    if (_c_slot_id.slot_data.allow_preg)
                    {
                        _slot_pos_dist = 0;
                        _old_slot_pos_dist = 1000000;
                        
                        if (_c_slot_id.unit_data.preg != -1)
                        {
                            for (var ii = 0; ii < (_count * 2); ii++)
                            {
                                var _t_pos = _c_pos + (((ii div 2) + 1) * _flip);
                                _flip *= -1;
                                var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                _allow = false;
                                
                                if (_t_slot_id != undefined)
                                {
                                    for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                    {
                                        if (_array_rec_pos[iii] == _t_pos)
                                        {
                                            _allow = true;
                                            iii = array_length(_array_rec_pos);
                                        }
                                    }
                                    
                                    if (_allow && _t_slot_id.slot_data.slot_type == 0 && _t_slot_id.slot_data.anim_struct != -1 && (_t_slot_id.slot_data.h_type == 5 || _t_slot_id.slot_data.h_type == 12) && (!_t_slot_id.slot_data.carry || !_c_slot_id.slot_data.load) && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1 && array_length(_t_slot_id.slot_data.prop) == 0)
                                    {
                                        _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                        
                                        if (_slot_pos_dist < _old_slot_pos_dist)
                                        {
                                            _preg_current_slot_id = _t_slot_id;
                                            _old_slot_pos_dist = _slot_pos_dist;
                                        }
                                    }
                                }
                            }
                            
                            if (_preg_current_slot_id != -1)
                            {
                                i = _count;
                                _set_mon = true;
                                _slot_pos = [_c_slot_id, _preg_current_slot_id];
                            }
                        }
                    }
                    else
                    {
                        _cell_spe = -1;
                        _current_slot_id = -1;
                        
                        switch (_c_slot_id.unit_data.class)
                        {
                            case 8:
                                _cell_spe = 39;
                                break;
                            
                            case 12:
                                _cell_spe = 38;
                                break;
                            
                            case 9:
                                _cell_spe = 36;
                                break;
                        }
                        
                        switch (_c_slot_id.slot_data.h_type)
                        {
                            case 4:
                                if (!_c_slot_id.unit_data.milk)
                                {
                                    if (_cell_spe != -1)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1 && _t_slot_id.slot_data.h_type == _cell_spe)
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (_current_slot_id == -1)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.slot_data.allow_preg && (_t_slot_id.slot_data.h_type <= 26 || ds_map_exists(global.cell_registry, _t_slot_id.slot_data.h_type)) && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (_current_slot_id != -1)
                                    {
                                        i = _count;
                                        _set_mon = true;
                                        _slot_pos = [_c_slot_id, _current_slot_id];
                                    }
                                }
                                
                                break;
                            
                            case 30:
                                if (!_c_slot_id.unit_data.milk)
                                {
                                    if (_cell_spe != -1)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1 && _t_slot_id.slot_data.h_type == _cell_spe)
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (_current_slot_id == -1)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.slot_data.allow_preg && (_t_slot_id.slot_data.h_type <= 26 || ds_map_exists(global.cell_registry, _t_slot_id.slot_data.h_type)) && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (_current_slot_id != -1)
                                    {
                                        i = _count;
                                        _set_mon = true;
                                        _slot_pos = [_c_slot_id, _current_slot_id];
                                    }
                                }
                                
                                break;
                            
                            case 5:
                                if (_c_slot_id.slot_data.anim_struct.char_state == 0 && _c_slot_id.unit_data.preg == -1)
                                {
                                    if (_c_slot_id.unit_data.milk)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.slot_data.h_type == 11 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (_current_slot_id != -1)
                                        {
                                            i = _count;
                                            _set_mon = true;
                                            _slot_pos = [_c_slot_id, _current_slot_id];
                                        }
                                    }
                                    
                                    if (!_set_mon && _c_slot_id.unit_data.milk)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1 || (_t_slot_id.slot_data.slot_type == 2 && _t_slot_id.slot_data.h_type == 30)) && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && (_t_slot_id.slot_data.h_type == 4 || _t_slot_id.slot_data.h_type == 30) && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (_current_slot_id != -1)
                                        {
                                            i = _count;
                                            _set_mon = true;
                                            _slot_pos = [_c_slot_id, _current_slot_id];
                                        }
                                    }
                                    
                                    if (!_set_mon)
                                    {
                                        if (_cell_spe != -1)
                                        {
                                            _slot_pos_dist = 0;
                                            _old_slot_pos_dist = 1000000;
                                            
                                            for (var ii = 0; ii < (_count * 2); ii++)
                                            {
                                                var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                                _flip *= -1;
                                                var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                                _allow = false;
                                                
                                                if (_t_slot_id != undefined)
                                                {
                                                    for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                    {
                                                        if (_array_rec_pos[iii] == _t_pos)
                                                        {
                                                            _allow = true;
                                                            iii = array_length(_array_rec_pos);
                                                        }
                                                    }
                                                    
                                                    if (_allow && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1 && _t_slot_id.slot_data.h_type == _cell_spe)
                                                    {
                                                        _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                        
                                                        if (_slot_pos_dist < _old_slot_pos_dist)
                                                        {
                                                            _current_slot_id = _t_slot_id;
                                                            _old_slot_pos_dist = _slot_pos_dist;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (_current_slot_id == -1)
                                        {
                                            _slot_pos_dist = 0;
                                            _old_slot_pos_dist = 1000000;
                                            
                                            for (var ii = 0; ii < (_count * 2); ii++)
                                            {
                                                var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                                _flip *= -1;
                                                var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                                _allow = false;
                                                
                                                if (_t_slot_id != undefined)
                                                {
                                                    for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                    {
                                                        if (_array_rec_pos[iii] == _t_pos)
                                                        {
                                                            _allow = true;
                                                            iii = array_length(_array_rec_pos);
                                                        }
                                                    }
                                                    
                                                    if (_allow && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.slot_data.allow_preg && (_t_slot_id.slot_data.h_type <= 26 || ds_map_exists(global.cell_registry, _t_slot_id.slot_data.h_type)) && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                                                    {
                                                        _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                        
                                                        if (_slot_pos_dist < _old_slot_pos_dist)
                                                        {
                                                            _current_slot_id = _t_slot_id;
                                                            _old_slot_pos_dist = _slot_pos_dist;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (_current_slot_id != -1)
                                        {
                                            _set_mon = true;
                                            _slot_pos = [_c_slot_id, _current_slot_id];
                                        }
                                    }
                                }
                                
                                break;
                            
                            case 12:
                                if (_c_slot_id.slot_data.anim_struct.char_state == 0 && _c_slot_id.unit_data.preg == -1)
                                {
                                    if (_c_slot_id.unit_data.milk)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.slot_data.h_type == 11 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (_current_slot_id != -1)
                                        {
                                            i = _count;
                                            _set_mon = true;
                                            _slot_pos = [_c_slot_id, _current_slot_id];
                                        }
                                    }
                                    
                                    if (!_set_mon && _c_slot_id.unit_data.milk)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1 || (_t_slot_id.slot_data.slot_type == 2 && _t_slot_id.slot_data.h_type == 30)) && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && (_t_slot_id.slot_data.h_type == 4 || _t_slot_id.slot_data.h_type == 30) && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (_current_slot_id != -1)
                                        {
                                            i = _count;
                                            _set_mon = true;
                                            _slot_pos = [_c_slot_id, _current_slot_id];
                                        }
                                    }
                                    
                                    if (!_set_mon)
                                    {
                                        if (_cell_spe != -1)
                                        {
                                            _slot_pos_dist = 0;
                                            _old_slot_pos_dist = 1000000;
                                            
                                            for (var ii = 0; ii < (_count * 2); ii++)
                                            {
                                                var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                                _flip *= -1;
                                                var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                                _allow = false;
                                                
                                                if (_t_slot_id != undefined)
                                                {
                                                    for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                    {
                                                        if (_array_rec_pos[iii] == _t_pos)
                                                        {
                                                            _allow = true;
                                                            iii = array_length(_array_rec_pos);
                                                        }
                                                    }
                                                    
                                                    if (_allow && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1 && _t_slot_id.slot_data.h_type == _cell_spe)
                                                    {
                                                        _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                        
                                                        if (_slot_pos_dist < _old_slot_pos_dist)
                                                        {
                                                            _current_slot_id = _t_slot_id;
                                                            _old_slot_pos_dist = _slot_pos_dist;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (_current_slot_id == -1)
                                        {
                                            _slot_pos_dist = 0;
                                            _old_slot_pos_dist = 1000000;
                                            
                                            for (var ii = 0; ii < (_count * 2); ii++)
                                            {
                                                var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                                _flip *= -1;
                                                var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                                _allow = false;
                                                
                                                if (_t_slot_id != undefined)
                                                {
                                                    for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                    {
                                                        if (_array_rec_pos[iii] == _t_pos)
                                                        {
                                                            _allow = true;
                                                            iii = array_length(_array_rec_pos);
                                                        }
                                                    }
                                                    
                                                    if (_allow && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.slot_data.allow_preg && (_t_slot_id.slot_data.h_type <= 26 || ds_map_exists(global.cell_registry, _t_slot_id.slot_data.h_type)) && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1)
                                                    {
                                                        _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                        
                                                        if (_slot_pos_dist < _old_slot_pos_dist)
                                                        {
                                                            _current_slot_id = _t_slot_id;
                                                            _old_slot_pos_dist = _slot_pos_dist;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (_current_slot_id != -1)
                                        {
                                            _set_mon = true;
                                            _slot_pos = [_c_slot_id, _current_slot_id];
                                        }
                                    }
                                }
                                
                                break;
                            
                            case 11:
                                if (!_c_slot_id.unit_data.milk)
                                {
                                    if (_cell_spe != -1)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1 && _t_slot_id.slot_data.h_type == _cell_spe)
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (_current_slot_id == -1)
                                    {
                                        _slot_pos_dist = 0;
                                        _old_slot_pos_dist = 1000000;
                                        
                                        for (var ii = 0; ii < (_count * 2); ii++)
                                        {
                                            var _t_pos = _pos + (((ii div 2) + 1) * _flip);
                                            _flip *= -1;
                                            var _t_slot_id = ds_list_find_value(global.slot_list[_floor], _t_pos);
                                            _allow = false;
                                            
                                            if (_t_slot_id != undefined)
                                            {
                                                for (var iii = 0; iii < array_length(_array_rec_pos); iii++)
                                                {
                                                    if (_array_rec_pos[iii] == _t_pos)
                                                    {
                                                        _allow = true;
                                                        iii = array_length(_array_rec_pos);
                                                    }
                                                }
                                                
                                                if (_allow && (_t_slot_id.slot_data.slot_type == 0 || _t_slot_id.slot_data.slot_type == 1) && !_c_slot_id.slot_data.carry && _t_slot_id.slot_data.anim_struct != -1 && _t_slot_id.slot_data.allow_preg && _t_slot_id.unit_data == -1 && _t_slot_id.slot_head_id == -1 && (_t_slot_id.slot_data.h_type < 26 || ds_map_exists(global.cell_registry, _t_slot_id.slot_data.h_type)))
                                                {
                                                    _slot_pos_dist = abs(x - _c_slot_id.x) + abs(_c_slot_id.x - _t_slot_id.x);
                                                    
                                                    if (_slot_pos_dist < _old_slot_pos_dist)
                                                    {
                                                        _current_slot_id = _t_slot_id;
                                                        _old_slot_pos_dist = _slot_pos_dist;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (_current_slot_id != -1)
                                    {
                                        i = _count;
                                        _set_mon = true;
                                        _slot_pos = [_c_slot_id, _current_slot_id];
                                    }
                                }
                                
                                break;
                        }
                    }
                }
            }
        }
    }
    
    if (_set_mon)
    {
        var _c_slot_id = _slot_pos[0];
        var _t_slot_id = _slot_pos[1];
        _carry_exe = [_c_slot_id, _t_slot_id];
    }
    
    return _carry_exe;
}

function scr_spawn_carry_mon_task(arg0)
{
    var _carry = scr_check_carry_slot_range(arg0);
    
    if (_carry != -1 && (global.val.mon_num[1] - global.val.nest_num[2]) > 1)
    {
        var _x = floor(x + (image_xscale * 0.5));
        var _y = y;
        var _floor = slot_data.slot_floor;
        var _door = scr_find_nearest_door(_x, _y, _floor);
        
        if (_door != -1)
        {
            _x = _door.x + floor(_door.image_xscale * 0.5);
            _y = _door.y;
            var _slot_pos = ds_list_find_index(global.slot_list[_floor], id);
            var _c_slot_id = _carry[0];
            var _t_slot_id = _carry[1];
            
            if (ds_map_exists(global.cell_registry, _t_slot_id.slot_data.h_type))
            {
                var _dbgf = file_text_open_append(GNX_LOG);
                file_text_write_string(_dbgf, "[GNX] goblin carry → h_type=" + string(_t_slot_id.slot_data.h_type) + "\n");
                file_text_close(_dbgf);
            }
            
            global.val.nest_num[2]++;
            var _mon = scr_create_mon(1, _x, _y, _floor, _slot_pos, 0);
            array_push(h_unit_list, _mon);
            
            with (_mon)
            {
                mon_data.carry_start_id = _c_slot_id;
                mon_data.carry_end_id = _t_slot_id;
                mon_data.mood_type = 1;
                mon_data.mood_timer = 180;
                scr_mood_value_set(-0.25);
            }
            
            if (_c_slot_id != id)
            {
                with (_c_slot_id)
                {
                    slot_data.load = true;
                    slot_data.carry = true;
                    scr_create_slot_head(false, id);
                }
            }
            
            with (_t_slot_id)
            {
                slot_data.load = true;
                slot_data.carry = true;
                scr_create_slot_head(false, id);
            }
            
            slot_data.anim_struct.char_state = 1;
            slot_data.anim_struct.ff = true;
        }
    }
}

function scr_check_clean_range(arg0)
{
    arg0 += global.val.add_range;
    var _floor = slot_data.slot_floor;
    var _pos = ds_list_find_index(global.slot_list[_floor], id);
    var _start_pos = max(0, _pos - (arg0 * 2));
    var _end_pos = _pos + (arg0 * 2);
    var _dist = (_end_pos - _start_pos) + 1;
    var _clean = false;
    
    for (var i = 0; i < _dist; i++)
    {
        var _c_pos = _start_pos + i;
        var _slot_id = ds_list_find_value(global.slot_list[_floor], _c_pos);
        
        if (_slot_id != undefined && (_slot_id.slot_data.slot_type == 0 || _slot_id.slot_data.slot_type == 1) && _slot_id.clean_id == -1 && _slot_id.slot_data.slot_dirt > 0)
        {
            with (_slot_id)
            {
                var _shift_x = 0;
                
                if (_slot_id.slot_data.slot_type == 1)
                    _shift_x = 11;
                
                clean_id = instance_create_depth(x + _shift_x, y, -761, obj_clean);
                
                with (clean_id)
                {
                    source_id = other.id;
                    shift_x = _shift_x;
                    var _width;
                    
                    if (_slot_id.slot_data.slot_type == 0)
                        _width = 45;
                    else
                        _width = 77;
                    
                    bubble_emitter = -1;
                    smoke_emitter = -1;
                    bubble_emitter = part_emitter_create(obj_np.part_system_f);
                    part_emitter_region(obj_np.part_system_f, bubble_emitter, x, x + _width, y, y - 60, 1, 0);
                    part_emitter_stream(obj_np.part_system_f, bubble_emitter, global.bubble_part, -4);
                    smoker_emitter = part_emitter_create(obj_np.part_system_f);
                    part_emitter_region(obj_np.part_system_f, smoker_emitter, x, x + _width, y - 10, y - 60, 1, 0);
                    part_emitter_stream(obj_np.part_system_f, smoker_emitter, global.smoke_part, -3);
                }
            }
        }
    }
    
    return _clean;
}

function scr_animation_end(arg0, arg1)
{
    if (slot_data.anim_struct.index >= arg1)
    {
        slot_data.anim_struct.index = 0;
        animation_end = true;
        
        if (arg0)
        {
            var _spd = slot_data.anim_struct.spr_spd / 60;
            _spd = random_range(_spd * 0.9, _spd * 1.1);
            slot_data.anim_struct.anim_spd = _spd;
        }
    }
}

function scr_mon_find_placement()
{
    var _type_ar = [0, 1];
    var _place = 0;
    var _num = array_length(h_unit_list);
    var _exists = true;
    
    switch (slot_data.h_type)
    {
        case 4:
            _type_ar = [0];
            break;
        
        case 17:
            _type_ar = [1];
            break;
        
        case 36:
            _type_ar = [0, 1];
            _place = min(1, array_length(h_unit_list));
            
            if (_place == 0 || slot_data.mon_placement[0] == -1)
                _type_ar = [0];
            
            break;
        
        case 24:
            _type_ar = [3];
            break;
        
        case 18:
            var _hob = true;
            var _slot_ar = [false, false, false];
            var _ar = [];
            
            for (var i = 0; i < _num; i++)
                _slot_ar[h_unit_list[i].mon_data.placement_num] = true;
            
            for (var i = 0; i < 3; i++)
            {
                if (!_slot_ar[i])
                    array_push(_ar, i);
            }
            
            _place = _ar[irandom_range(0, array_length(_ar) - 1)];
            
            if (_place == 2 && array_length(_ar) > 2)
                _place = choose(0, 1);
            
            if (_place != 0)
                _type_ar = [0];
            
            break;
        
        case 19:
            _type_ar = [0];
            var _slot_ar = [false, false];
            var _ar = [];
            
            for (var i = 0; i < _num; i++)
                _slot_ar[h_unit_list[i].mon_data.placement_num] = true;
            
            for (var i = 0; i < 2; i++)
            {
                if (!_slot_ar[i])
                    array_push(_ar, i);
            }
            
            _place = _ar[irandom_range(0, array_length(_ar) - 1)];
            break;
        
        case 38:
            _type_ar = [3];
            var _slot_ar = [false, false];
            var _ar = [];
            
            for (var i = 0; i < _num; i++)
                _slot_ar[h_unit_list[i].mon_data.placement_num] = true;
            
            for (var i = 0; i < 2; i++)
            {
                if (!_slot_ar[i])
                    array_push(_ar, i);
            }
            
            _place = _ar[irandom_range(0, array_length(_ar) - 1)];
            break;
        
        case 23:
            var _slot_ar = [false, false];
            var _ar = [];
            
            if (_num == 0)
            {
                _type_ar = [3];
                _place = 0;
            }
            else if (slot_data.mon_placement[0] == -1)
            {
                _exists = false;
            }
            else
            {
                _place = 1;
            }
            
            break;
        
        case 21:
            _type_ar = [3];
            break;
        
        case 22:
            _type_ar = [3];
            break;
        
        case 20:
            _type_ar = [3];
            break;
        
        case 39:
            _type_ar = [0, 1, 3];
            break;
        
        case 37:
            _type_ar = [0, 1, 3];
            break;
        
        default:
            if (ds_map_exists(global.cell_registry, slot_data.h_type))
            {
                var _gcell = ds_map_find_value(global.cell_registry, slot_data.h_type);
                
                if (variable_struct_exists(_gcell, "mon_types") && _gcell.mon_types != undefined)
                    _type_ar = _gcell.mon_types;
            }
            
            break;
    }
    
    if (_exists)
    {
        var _a = irandom_range(0, array_length(_type_ar) - 1);
        var _type = _type_ar[_a];
        return [_type, _place];
    }
    else
    {
        return -1;
    }
}

function scr_slot_call_mon(arg0)
{
    if (!variable_struct_exists(scr_slot, "h"))
        exit;

    var _num = array_length(h_unit_list);

    if (_num < slot_data.max_mon_num && !slot_data.carry)
    {
        slot_data.h_wait -= global.w_spd;
        
        if (slot_data.h_wait <= 0)
        {
            slot_data.h_wait = irandom_range(240, 360);
            var _ar = scr_mon_find_placement();
            
            if (_ar != -1)
            {
                var _type = _ar[0];
                var _place = _ar[1];
                var _mon = -1;
                var _slot_id = id;
                var _floor = slot_data.slot_floor;
                
                if (arg0)
                {
                    with (obj_mon)
                    {
                        if (mon_data.mon_state == 5 && mon_data.slot_id == -1 && mon_data.mon_floor == _floor && mon_data.task == 0 && mon_data.mon_type == _type)
                        {
                            mon_data.slot_id = _slot_id;
                            mon_data.mon_state = 6;
                            mon_data.ff = true;
                            mon_data.placement_num = _place;
                            _mon = id;
                            var _gfd = file_text_open_append(GNX_LOG);
                            file_text_write_string(_gfd, "[MON:" + string(id) + "] DISPATCHED(wander) from x=" + string(x) + " → h_type=" + string(_slot_id.slot_data.h_type) + " cell_x=" + string(_slot_id.x));
                            file_text_writeln(_gfd);
                            file_text_close(_gfd);
                            break;
                        }
                    }
                }
                
                if (_mon == -1 && (global.val.mon_num[_type] - global.val.nest_num[_type + 1]) > 0)
                {
                    var _x = floor(x + (image_xscale * 0.5));
                    var _y = y;
                    var _door = -1;
                    
                    if (slot_data.h_type == 4 || slot_data.h_type == 24 || (slot_data.h_type == 36 && _place == 0))
                    {
                        _door = scr_find_nearest_door(_x, _y, _floor);
                    }
                    else
                    {
                        var _type_ar = scr_check_door_allow(slot_data.slot_floor, [_type]);
                        
                        if (array_length(_type_ar) > 0)
                        {
                            _type = _type_ar[0];
                            _door = scr_find_nearest_door(_x, _y, _floor);
                        }
                    }
                    
                    if (_door != -1)
                    {
                        _x = _door.x + floor(_door.image_xscale * 0.5);
                        _y = _door.y;
                        var _slot_pos = ds_list_find_index(global.slot_list[_floor], id);
                        _mon = scr_create_mon(_type, _x, _y, _floor, _slot_pos, _place);
                        global.val.nest_num[_type + 1]++;
                    }
                }
                
                if (_mon != -1)
                {
                    array_push(h_unit_list, _mon);
                    slot_data.load = true;
                    slot_data.load_index = 0;
                    scr_create_slot_head(false, id);
                }
            }
        }
    }
}

function scr_tired_timer(arg0, arg1, arg2)
{
    arg0 = max(0, arg0 - global.w_spd);
    
    if (arg0 <= 0)
        slot_data.anim_struct.anim_spd = arg1 / arg2;
    
    return arg0;
}

function scr_slot_cow_milking()
{
    slot_data.anim_struct.milk_timer = max(0, slot_data.anim_struct.milk_timer - global.w_spd);
    slot_data.anim_struct.milk_index += (slot_data.anim_struct.milk_spd / 60) * global.w_spd;
    
    if (slot_data.anim_struct.milk_index >= 5)
    {
        slot_data.anim_struct.milk_index -= 5;
        scr_play_milk_sfx();
        
        if (slot_data.anim_struct.milk_timer == 0)
        {
            switch (slot_data.anim_struct.milk_spd)
            {
                case 9:
                    slot_data.anim_struct.milk_spd = 12;
                    slot_data.anim_struct.milk_timer = 240;
                    break;
                
                case 12:
                    slot_data.anim_struct.milk_spd = 9;
                    slot_data.anim_struct.milk_timer = 600;
                    break;
            }
        }
    }
    
    if (unit_data.milk)
    {
        unit_data.scr_wait = min(240, unit_data.scr_wait + global.w_spd);
        
        if (unit_data.scr_wait >= 240)
        {
            scr_add_milk_item(1, 1);
            scr_icon_pop_up_create(x + (image_xscale * 0.5), y - 62, 1, 1, false);
            unit_data.milk = false;
            unit_data.scr_wait = 0;
        }
    }
}

function scr_check_empty_cell_range(arg0, arg1)
{
    arg1 += global.val.add_range;
    var _floor = arg0.slot_data.slot_floor;
    var _pos = ds_list_find_index(global.slot_list[_floor], arg0);
    var _start_pos = max(0, _pos - (arg1 * 2));
    var _end_pos = _pos + (arg1 * 2);
    var _dist = (_end_pos - _start_pos) + 1;
    var _slot_dist = 1000;
    var _empty_id = -1;
    var _target_id = -1;
    var _check = false;
    
    for (var i = 0; i < _dist; i++)
    {
        var _c_pos = _start_pos + i;
        var _slot_id = ds_list_find_value(global.slot_list[_floor], _c_pos);
        
        if (_slot_id != undefined && (_slot_id.slot_data.slot_type == 0 || _slot_id.slot_data.slot_type == 1) && _slot_id.unit_data != -1 && !_slot_id.slot_data.carry && _slot_id.slot_data.load == 0 && _slot_id.slot_data.h_type != 11 && _slot_id.slot_data.h_type != 17 && _slot_id.slot_data.h_type != 24 && _slot_id.slot_data.h_type != 4 && _slot_id.slot_data.h_type != 20 && _slot_id.slot_data.h_type != 21 && _slot_id.slot_data.h_type != 22 && _slot_id.slot_data.h_type != 38 && _slot_id.slot_data.h_type != 5 && _slot_id.slot_data.h_type != 12 && variable_struct_exists(_slot_id.scr_slot, "h"))
        {
            var _num = array_length(_slot_id.h_unit_list);
            
            if (abs(_pos - _c_pos) < _slot_dist)
            {
                _check = false;
                
                switch (_slot_id.slot_data.h_type)
                {
                    case 23:
                        _check = true;
                        
                        if (_num == 1)
                        {
                            _slot_dist = abs(_pos - _c_pos);
                            _target_id = _slot_id;
                        }
                        
                        break;
                    
                    case 37:
                        _check = true;
                        
                        if (_num < _slot_id.slot_data.max_mon_num && _slot_id.slot_data.anim_struct.char_state == 0 && !_slot_id.slot_data.mod_index[1])
                        {
                            _slot_dist = abs(_pos - _c_pos);
                            _target_id = _slot_id;
                        }
                        
                        break;
                    
                    case 39:
                        _check = true;
                        
                        if (_slot_id.slot_data.anim_struct.char_state == 0)
                        {
                            _slot_dist = abs(_pos - _c_pos);
                            _target_id = _slot_id;
                        }
                        
                        break;
                }
                
                if (!_check)
                {
                    if (_num < _slot_id.slot_data.max_mon_num)
                    {
                        _slot_dist = abs(_pos - _c_pos);
                        _target_id = _slot_id;
                    }
                }
            }
        }
    }
    
    return _target_id;
}

function scr_check_add_guide(arg0)
{
    var _exists = false;
    
    if (arg0 == 11 || arg0 == 12 || arg0 == 10 || arg0 == 17 || arg0 == 33 || arg0 == 30 || arg0 == 24 || arg0 == 25 || arg0 == 41 || arg0 == 39 || arg0 == 40 || arg0 == 42)
        _exists = true;
    
    if (_exists)
    {
        array_push(global.val.guide_unlock.cell, arg0);
        ds_list_add(global.new_guide_list, arg0);
    }
}

function scr_check_frog_unit_swap(arg0)
{
    var _unit_data = unit_data;
    var _scr_check = -1;
    var _slot = false;
    
    switch (arg0)
    {
        case 5:
            _slot = true;
            
            if (floor(_unit_data.preg_c) == 0 && _unit_data.preg == -1 && !_unit_data.milk)
                _scr_check = scr_check_type_preg;
            
            break;
        
        case 12:
            _slot = true;
            
            if (floor(_unit_data.preg_c) == 0 && _unit_data.preg == -1 && !_unit_data.milk)
                _scr_check = scr_check_type_preg;
            
            break;
        
        case 4:
            _slot = true;
            
            if (floor(_unit_data.preg_c) == 0)
            {
                if (_unit_data.preg == -1 && !_unit_data.milk)
                    _scr_check = scr_check_type_preg;
            }
            else if (!_unit_data.milk)
            {
                _scr_check = scr_check_type_milk;
            }
            
            break;
        
        case 30:
            _slot = true;
            
            if (floor(_unit_data.preg_c) == 0)
            {
                if (_unit_data.preg == -1 && !_unit_data.milk)
                    _scr_check = scr_check_type_preg;
            }
            else if (!_unit_data.milk)
            {
                _scr_check = scr_check_type_milk;
            }
            
            break;
        
        case 33:
            _slot = true;
            _scr_check = scr_check_type_n_preg;
            break;
    }
    
    if (!_slot && slot_data.allow_preg)
    {
        if (floor(_unit_data.preg_c) == 0 && _unit_data.preg == -1)
            _scr_check = scr_check_type_preg;
    }
    
    if (_scr_check != -1)
    {
        var _range = 5 + global.val.add_range;
        var _floor = slot_data.slot_floor;
        var _h_type = slot_data.h_type;
        var _pos = ds_list_find_index(global.slot_list[_floor], id);
        var _start_pos = max(0, _pos - (_range * 2));
        var _end_pos = _pos + (_range * 2);
        var _dist = (_end_pos - _start_pos) + 1;
        var _frog = false;
        var _class_swap;
        
        for (var i = 0; i < _dist; i++)
        {
            var _c_pos = _start_pos + i;
            var _slot_id = ds_list_find_value(global.slot_list[_floor], _c_pos);
            
            if (_slot_id != undefined && _slot_id.slot_data.slot_type == 1 && _slot_id.slot_data.h_type == 41)
            {
                i = _dist;
                _frog = true;
                _class_swap = _slot_id.slot_data.mod_index[2];
            }
        }
        
        var _swap_pos = -1;
        
        if (_frog)
        {
            _swap_pos = script_execute(_scr_check, _unit_data, arg0, _class_swap);
            
            if (_swap_pos != -1)
            {
                var _old_unit_data = ds_list_find_value(global.unit_list, _swap_pos);
                var _old_slot_id = id;
                ds_list_set(global.unit_list, _swap_pos, -1);
                scr_insert_unit_to_list(_unit_data, _swap_pos, -1);
                var _button = scr_reset_single_unit_window(_swap_pos);
                scr_occupy_slot(_old_slot_id, -1, true, 1);
                scr_occupy_slot(_old_slot_id, _old_unit_data, true, 1);
                scr_create_slot_head(true, id);
                scr_swap_emitter(x + round(image_xscale * 0.5), y - 30, false);
                scr_swap_emitter(_button.x, _button.y, true);
            }
        }
    }
}

function scr_check_type_n_preg(arg0, arg1, arg2)
{
    var _num = ds_list_size(global.unit_list);
    var _swap_pos = -1;
    var _hold_pos = -1;
    var _class = arg0.class;
    var _same_check = false;

    if (obj_control.hold_id != -1 && instance_exists(obj_control.hold_id) && obj_control.hold_id.drag_type == 1)
        _hold_pos = obj_control.hold_id.button_num;

    for (var i = 0; i < _num; i++)
    {
        var _pris_unit = ds_list_find_value(global.unit_list, i);

        if (_pris_unit != -1 && i != _hold_pos && floor(_pris_unit.preg_c) == 0 && _pris_unit.class == _class)
        {
            _swap_pos = i;
            i = _num;
            _same_check = true;
        }
    }
    
    if (!_same_check && !arg2)
    {
        for (var i = 0; i < _num; i++)
        {
            var _pris_unit = ds_list_find_value(global.unit_list, i);
            
            if (_pris_unit != -1 && i != _hold_pos && floor(_pris_unit.preg_c) == 0 && (_pris_unit.class != 11 || (_pris_unit.class == 11 && _class == 11)))
            {
                _swap_pos = i;
                i = _num;
            }
        }
    }
    
    return _swap_pos;
}

function scr_check_type_preg(arg0, arg1, arg2)
{
    var _num = ds_list_size(global.unit_list);
    var _swap_pos = -1;
    var _hold_pos = -1;
    var _class = arg0.class;
    var _same_check = false;
    var _tent = false;
    
    if (arg1 > 26 && arg1 < 35)
        _tent = true;

    if (obj_control.hold_id != -1 && instance_exists(obj_control.hold_id) && obj_control.hold_id.drag_type == 1)
        _hold_pos = obj_control.hold_id.button_num;
    
    for (var i = 0; i < _num; i++)
    {
        var _pris_unit = ds_list_find_value(global.unit_list, i);
        
        if (_pris_unit != -1 && i != _hold_pos && floor(_pris_unit.preg_c) != 0 && _pris_unit.class == _class && (!_tent || (_tent && (_pris_unit.preg == -1 || (_pris_unit.preg != -1 && _pris_unit.preg == 2)))))
        {
            _swap_pos = i;
            i = _num;
            _same_check = true;
        }
    }
    
    if (!_same_check && arg1 < 35 && !arg2)
    {
        for (var i = 0; i < _num; i++)
        {
            var _pris_unit = ds_list_find_value(global.unit_list, i);
            
            if (_pris_unit != -1 && i != _hold_pos && floor(_pris_unit.preg_c) != 0 && _pris_unit.class != 11 && (!_tent || (_tent && (_pris_unit.preg == -1 || (_pris_unit.preg != -1 && _pris_unit.preg == 2)))))
            {
                _swap_pos = i;
                i = _num;
            }
        }
    }
    
    return _swap_pos;
}

function scr_check_type_milk(arg0, arg1, arg2)
{
    var _num = ds_list_size(global.unit_list);
    var _swap_pos = -1;
    var _hold_pos = -1;
    var _class = arg0.class;
    var _same_check = false;
    
    if (obj_control.hold_id != -1 && instance_exists(obj_control.hold_id) && obj_control.hold_id.drag_type == 1)
        _hold_pos = obj_control.hold_id.button_num;
    
    for (var i = 0; i < _num; i++)
    {
        var _pris_unit = ds_list_find_value(global.unit_list, i);
        
        if (_pris_unit != -1 && i != _hold_pos && floor(_pris_unit.milk) && _pris_unit.class == _class)
        {
            _swap_pos = i;
            i = _num;
            _same_check = true;
        }
    }
    
    if (!_same_check && !arg2)
    {
        for (var i = 0; i < _num; i++)
        {
            var _pris_unit = ds_list_find_value(global.unit_list, i);
            
            if (_pris_unit != -1 && i != _hold_pos && floor(_pris_unit.milk) && _pris_unit.class != 11)
            {
                _swap_pos = i;
                i = _num;
            }
        }
    }
    
    return _swap_pos;
}

function scr_check_between_base(arg0, arg1)
{
    var _pos = ds_list_find_index(global.slot_list[arg0], arg1);
    var _type = arg1.slot_data.between_type;
    
    if ((_pos - 2) >= 0)
    {
        var _change_id = ds_list_find_value(global.slot_list[arg0], _pos - 1);
        var _between = ds_list_find_value(global.slot_list[arg0], _pos - 2);
        
        if (_between.slot_data.between_type == _type)
        {
            scr_change_between_base(_change_id, _type);
        }
        else
        {
            if (_change_id.slot_data.slot_type == 0)
            {
                _change_id.slot_data.base_type = 0;
                _change_id.spr_base = spr_slot_back;
            }
            
            if (_change_id.slot_data.slot_type == 1)
            {
                _change_id.slot_data.base_type = 0;
                _change_id.spr_base = spr_big_slot_back;
            }
            
            if (_change_id.slot_data.slot_type == 2)
            {
                _change_id.slot_data.base_type = 4;
                _change_id.spr_base = spr_tent_back;
            }
        }
    }
    
    if ((_pos + 2) <= ds_list_size(global.slot_list[arg0]))
    {
        var _change_id = ds_list_find_value(global.slot_list[arg0], _pos + 1);
        var _between = ds_list_find_value(global.slot_list[arg0], _pos + 2);
        
        if (_between.slot_data.between_type == _type)
        {
            scr_change_between_base(_change_id, _type);
        }
        else
        {
            if (_change_id.slot_data.slot_type == 0)
            {
                _change_id.slot_data.base_type = 0;
                _change_id.spr_base = spr_slot_back;
            }
            
            if (_change_id.slot_data.slot_type == 1)
            {
                _change_id.slot_data.base_type = 0;
                _change_id.spr_base = spr_big_slot_back;
            }
            
            if (_change_id.slot_data.slot_type == 2)
            {
                _change_id.slot_data.base_type = 4;
                _change_id.spr_base = spr_tent_back;
            }
        }
    }
}

function scr_change_between_base(arg0, arg1)
{
    var _spr = -1;
    var _base_type;
    
    switch (arg0.slot_data.slot_type)
    {
        case 0:
            switch (arg1)
            {
                case 0:
                    _spr = spr_slot_back;
                    _base_type = 0;
                    break;
                
                case 1:
                    _spr = spr_slot_back_pillar;
                    _base_type = 1;
                    break;
                
                case 2:
                    _spr = spr_slot_back_rock;
                    _base_type = 2;
                    break;
                
                case 3:
                    _spr = spr_slot_back_brick;
                    _base_type = 3;
                    break;
            }
            
            break;
        
        case 1:
            switch (arg1)
            {
                case 0:
                    _spr = spr_big_slot_back;
                    _base_type = 0;
                    break;
                
                case 1:
                    _spr = spr_big_slot_back_pillar;
                    _base_type = 1;
                    break;
                
                case 2:
                    _spr = spr_big_slot_back_rock;
                    _base_type = 2;
                    break;
                
                case 3:
                    _spr = spr_big_slot_back_brick;
                    _base_type = 3;
                    break;
            }
            
            break;
        
        case 2:
            switch (arg1)
            {
                case 4:
                    _spr = spr_tent_back_full;
                    _base_type = 5;
                    break;
            }
            
            break;
    }
    
    if (_spr != -1)
    {
        arg0.spr_base = _spr;
        arg0.slot_data.base_type = _base_type;
    }
}
