// GNX: patched s_unit_function.gml
// Added moan_voice/moan_pitch copy from _info to _unit_info in scr_create_unit_base.
// These fields are set by scr_set_unit_stat_data (s_unit_data.gml) when gnx_has_sounds is true.

function scr_create_unit_base(arg0, arg1)
{
    var _class_name = -1;
    var _unit_info = {};
    _unit_info.class = arg0;
    _unit_info.lvl = min(arg1, 7);
    _unit_info.milk = false;
    _unit_info.tired_c = 0;
    _unit_info.preg = -1;
    _unit_info.preg_prd = 25;
    _unit_info.scr_wait = 0;
    var _info = scr_set_unit_stat_data(arg0, arg1);
    _unit_info.class_name = _info.class_name;
    _unit_info.hair = _info.hair;
    _unit_info.skin = _info.skin;
    _unit_info.breast = _info.breast;
    _unit_info.leg = _info.leg;
    _unit_info.preg_c = _info.preg_c;
    _unit_info.preg_c_max = _info.preg_c;
    _unit_info.scr_unit = _info.scr_unit;
    // GNX sound: copy voice assignment from stat data
    _unit_info.moan_voice = _info.moan_voice;
    _unit_info.moan_pitch = _info.moan_pitch;
    return _unit_info;
}

function scr_insert_unit_to_list(arg0, arg1, arg2)
{
    var _insert = false;
    var _pos_id = ds_list_find_value(global.unit_list, arg1);
    var _button_num;
    if (arg2 != -1)
    {
        _button_num = arg2.button_num;
    }
    else
    {
        _button_num = -1;
    }
    if (_pos_id != -1)
    {
        if (arg2.drag_type == UnknownEnum.Value_1)
        {
            ds_list_set(global.unit_list, _button_num, _pos_id);
            ds_list_set(global.unit_list, arg1, arg0);
            _insert = true;
        }
    }
    else
    {
        if (arg2 != -1 && arg2.drag_type != UnknownEnum.Value_5 && _button_num != -1)
        {
            ds_list_set(global.unit_list, _button_num, -1);
        }
        ds_list_set(global.unit_list, arg1, arg0);
        _insert = true;
    }
    return _insert;
}

function scr_unit_milk_generate(arg0)
{
    if (!unit_data.milk)
    {
        var _set = false;
        switch (slot_data.h_type)
        {
            case UnknownEnum.Value_11:
                _set = true;
                if (slot_data.drink_num == 0)
                {
                    unit_data.scr_wait += global.w_spd;
                    if (unit_data.scr_wait >= 1500)
                    {
                        unit_data.scr_wait = 0;
                        unit_data.milk = true;
                        slot_data.drink_num = 8;
                    }
                }
                break;
            case UnknownEnum.Value_30:
                _set = true;
                if (slot_data.milk_num == 0)
                {
                    unit_data.scr_wait += global.w_spd;
                    if (unit_data.scr_wait >= 1500)
                    {
                        unit_data.scr_wait = 0;
                        unit_data.milk = true;
                        slot_data.milk_num = 4;
                    }
                }
                break;
        }
        if (!_set)
        {
            unit_data.scr_wait += global.w_spd * arg0;
            if (unit_data.scr_wait >= 1500)
            {
                unit_data.scr_wait = 0;
                unit_data.milk = true;
            }
        }
    }
}

function scr_unit_preg_generate(arg0)
{
    unit_data.preg_c = min(unit_data.preg_c_max, unit_data.preg_c + (0.0002 * global.w_spd * arg0));
}

enum UnknownEnum
{
    Value_1 = 1,
    Value_5 = 5,
    Value_11 = 11,
    Value_30 = 30
}
