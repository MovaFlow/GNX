scr_mouse_control();

// GNX: per-frame quest completion check
scr_gnx_check_quest_completion("frame");

// GNX: tool system per-frame hooks (gated by gnx_has_tools inside each function)
scr_gnx_check_keybinds();
scr_gnx_apply_continuous_effects();
