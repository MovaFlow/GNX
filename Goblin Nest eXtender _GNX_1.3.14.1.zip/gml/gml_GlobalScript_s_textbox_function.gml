function scr_create_textbox(arg0, arg1, arg2)
{
    global.camera_lock = true;
    global.speed_lock = true;
    
    with (instance_create_depth(0, 0, -3000, obj_window))
    {
        interact_type = UnknownEnum.Value_5;
        source_id = arg2;
        gui = true;
        sprite_index = spr_pixel;
        image_xscale = 480;
        image_yscale = 270;
        
        if (arg1 != -1)
            script_execute(arg1);
        
        textbox_id = instance_create_depth(179, 162, -3010, obj_text);
        var _name, _spr;
        
        with (textbox_id)
        {
            source_id = other.id;
            scr_set_textbox_lang();
            text_data = arg0;
            page = 0;
            page_number = 0;
            draw_char = 0;
            char = ["", ""];
            last_free_space = 0;
            text_name = [];
            text_spr = [];
            text_ar = [];
            last_blip = -1;
            arrow = false;
            wait = 0;
            shift_y = 0;
            ff = true;
            text_color = make_color_rgb(234, 244, 232);
            shadow_color = 0;
            script_execute(text_data.text_type);
            _name = text_name[0];
            _spr = text_spr[0];
            text_length[0] = string_length(text_ar[0]);
            draw_set_font(fnt_base_font_eng);
        }
        
        name_text = _name;
        portrait_index = _spr;
        scr_window_draw = scr_draw_window_portrait;
        unpause = false;
        
        if (global.w_spd != 0)
        {
            global.speed_save = global.w_spd;
            global.w_spd = 0;
            unpause = true;
            
            with (obj_button)
            {
                if (interact_type == UnknownEnum.Value_35)
                {
                    switch_type = true;
                    image_index = (button_num * 2) + 1;
                    
                    if (button_num == global.w_spd)
                    {
                        switch_type = false;
                        image_index = button_num * 2;
                    }
                }
            }
        }
        
        por_button = scr_create_button_layout(284, 28, -3015, 2, 2, 15, 0, 0, spr_button_portrait, UnknownEnum.Value_57, id, false, scr_create_gui_por_button, -1, scr_draw_hover_button);
    }
}

function scr_text(arg0, arg1, arg2)
{
    line_break_pos[0][page_number] = 999;
    line_break_num[page_number] = 0;
    line_break_offset[page_number] = 0;
    text_name[page_number] = arg0;
    text_spr[page_number] = arg1;
    text_ar[page_number] = arg2;
    page_number++;
}

function scr_textbox_step()
{
    if (ff)
    {
        ff = false;
        scr_change_lang();
        
        for (var i = 0; i < page_number; i++)
        {
            text_length[i] = string_length(text_ar[i]);
            
            for (var c = 0; c < text_length[i]; c++)
            {
                var _char_pos = c + 1;
                char[c][i] = string_char_at(text_ar[i], _char_pos);
                var _text_up_to_char = string_copy(text_ar[i], 1, _char_pos);
                var _current_text_w = string_width(_text_up_to_char) - string_width(char[c][i]);
                
                if (global.val.language == UnknownEnum.Value_9 || global.val.language == UnknownEnum.Value_2 || global.val.language == UnknownEnum.Value_3 || global.val.language == UnknownEnum.Value_1)
                    last_free_space = _char_pos + 1;
                else if (char[c][i] == " ")
                    last_free_space = _char_pos + 1;
                
                if ((_current_text_w - line_break_offset[i]) > line_width)
                {
                    line_break_pos[line_break_num[i]][i] = last_free_space;
                    line_break_num[i]++;
                    var _text_last_pos = string_copy(text_ar[i], 1, last_free_space);
                    var _last_free_space_string = string_char_at(text_ar[i], last_free_space);
                    line_break_offset[i] = string_width(_text_last_pos) - string_width(_last_free_space_string);
                }
            }
            
            for (var c = 0; c < text_length[i]; c++)
            {
                var _char_pos = c + 1;
                var _text_x = x;
                var _text_y = y;
                var _text_up_to_char = string_copy(text_ar[i], 1, _char_pos);
                var _current_text_w = string_width(_text_up_to_char) - string_width(char[c][i]);
                var _text_line = 0;
                
                for (var b = 0; b < line_break_num[i]; b++)
                {
                    if (_char_pos >= line_break_pos[b][i])
                    {
                        var _str_copy = string_copy(text_ar[i], line_break_pos[b][i], _char_pos - line_break_pos[b][i]);
                        _current_text_w = string_width(_str_copy);
                        _text_line = b + 1;
                    }
                }
                
                char_x[c][i] = _text_x + _current_text_w;
                char_y[c][i] = _text_y + (_text_line * line_sep);
            }
        }
        
        draw_set_font(fnt_base_font_eng);
    }
    
    if (draw_char < text_length[page])
    {
        arrow = false;
        shift_y = 0;
        draw_char += 0.6;
        draw_char = clamp(draw_char, 0, text_length[page]);
        var _c = floor(draw_char);
        var _char = char[min(_c, text_length[page] - 1)][page];
        var _last_char = char[max(0, _c - 1)][page];
        
        if (_c != last_blip && _char != "." && (_c == 0 || (_last_char == " " && _char != " ")))
        {
            last_blip = _c;
            audio_play_sound(snd_blip, 1, false, global.val.sfx_vol);
        }
    }
    else
    {
        arrow = true;
        
        if (wait++ >= 20)
        {
            wait = 0;
            shift_y = !shift_y;
        }
    }
}

function scr_end_textbox(arg0)
{
    with (arg0)
    {
        if (!obj_np.obj_raid.activate)
            global.camera_lock = false;
        
        global.speed_lock = false;
        
        if (source_id.unpause)
        {
            global.w_spd = global.speed_save;
            
            with (obj_button)
            {
                if (interact_type == UnknownEnum.Value_35)
                {
                    switch_type = true;
                    image_index = (button_num * 2) + 1;
                    
                    if (button_num == global.w_spd)
                    {
                        switch_type = false;
                        image_index = button_num * 2;
                    }
                }
            }
        }
        
        if (text_data.noti_type != -1)
        {
            for (var i = 0; i < ds_list_size(global.noti_list); i++)
            {
                if (ds_list_find_value(global.noti_list, i).noti_type == text_data.noti_type)
                {
                    ds_list_delete(global.noti_list, i);
                    i = ds_list_size(global.noti_list);
                }
            }
            
            with (obj_np)
            {
                if (ds_list_size(global.noti_list) > 0)
                    scr_create_button(416, 242, -2000, spr_notification, UnknownEnum.Value_33, -1, scr_create_notification_button, -1, scr_draw_hover_button, 0, 0);
            }
        }
        
        if (text_data.event_after != -1)
            scr_add_event(text_data.event_after, false);
        
        // GNX: chain to next event in mod quest sequence
        if (variable_struct_exists(text_data, "gnx_next") && text_data.gnx_next != undefined)
            scr_gnx_fire_event(text_data.gnx_next);
        
        instance_destroy();
        
        with (source_id)
            instance_destroy();
    }
}

enum UnknownEnum
{
    Value_1 = 1,
    Value_2,
    Value_3,
    Value_5 = 5,
    Value_9 = 9,
    Value_33 = 33,
    Value_35 = 35,
    Value_57 = 57
}
