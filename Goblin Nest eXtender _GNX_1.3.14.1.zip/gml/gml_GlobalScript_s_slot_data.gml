function scr_set_slot_h_data(arg0, arg1)
{
    var _wall = -1;
    
    with (arg0)
    {
        if (arg1 != -1)
        {
            scr_create_anim_struct();
            scr_slot_draw_special = scr_draw_slot_parts;
            slot_head_id = -1;
            bar_glow_rep = -1;
            slot_data.anal = -1;
            slot_data.spr_touch = -1;
            slot_data.spr_enter = -1;
            scr_slot_base = -1;
            var _reg_handled = false;
            
            if (!global.use_legacy_dispatch && ds_map_exists(global.cell_registry, arg1))
            {
                var _rcell = ds_map_find_value(global.cell_registry, arg1);
                var _rp = _rcell.physical;
                slot_data.h_type = arg1;
                slot_data.allow_preg = _rp.allow_preg;
                slot_data.max_mon_num = _rp.max_mon_num;
                slot_data.anal = _rp.anal;
                slot_data.spr_row_pos = _rp.spr_row_pos;
                slot_data.slot_dirt = _rp.slot_dirt_init;
                var _tmpl = _rp.spr_slot_template;
                var _rn = array_length(_tmpl);
                var _rclone = array_create(_rn);
                
                for (var _ri = 0; _ri < _rn; _ri++)
                {
                    var _rrow = _tmpl[_ri];
                    var _rm = array_length(_rrow);
                    var _rnew = array_create(_rm);
                    
                    for (var _rj = 0; _rj < _rm; _rj++)
                        _rnew[_rj] = _rrow[_rj];
                    
                    _rclone[_ri] = _rnew;
                }
                
                spr_slot = _rclone;
                scr_slot = _rp.scr_slot_template;
                scr_slot_draw_special = _rp.scr_draw_special;
                slot_data.hand_x = _rp.hand_x;
                slot_data.hand_y = _rp.hand_y;
                slot_data.hand_xscale = _rp.hand_xscale;
                slot_data.hand_angle = _rp.hand_angle;
                slot_data.hand_frame = [];
                slot_data.hand_frame[1] = -1;
                slot_data.hand_frame[2] = -1;
                slot_data.hand_frame[3] = -1;
                slot_data.hand_frame[4] = -1;

                if (variable_struct_exists(_rp, "hand_frames"))
                {
                    var _hf = _rp.hand_frames;

                    if (variable_struct_exists(_hf, "frame_1"))
                        slot_data.hand_frame[1] = _hf.frame_1;

                    if (variable_struct_exists(_hf, "frame_2"))
                        slot_data.hand_frame[2] = _hf.frame_2;

                    if (variable_struct_exists(_hf, "frame_3"))
                        slot_data.hand_frame[3] = _hf.frame_3;

                    if (variable_struct_exists(_hf, "frame_4"))
                        slot_data.hand_frame[4] = _hf.frame_4;
                }
                
                sp_spr = _rp.sp_spr;
                slot_data.sq_x = _rp.sq_x;
                slot_data.sq_y = _rp.sq_y;
                slot_data.sp_x = _rp.sp_x;
                slot_data.sp_y = _rp.sp_y;
                slot_data.sp_anim_x = _rp.sp_anim_x;
                slot_data.sp_anim_y = _rp.sp_anim_y;
                
                if (variable_struct_exists(_rp, "sign_y_base"))
                    slot_data.sign_y = _rp.sign_y_base + irandom_range(-_rp.sign_y_jitter, _rp.sign_y_jitter);
                
                if (variable_struct_exists(_rp, "milk_step"))
                    slot_data.milk_step = _rp.milk_step;
                
                if (variable_struct_exists(_rp, "drink_num"))
                    slot_data.drink_num = _rp.drink_num;
                
                if (variable_struct_exists(_rp, "mon_index"))
                    slot_data.mon_index = array_create(array_length(_rp.mon_index), 0);
                
                if (variable_struct_exists(_rp, "blink_spr"))
                    blink_spr = _rp.blink_spr;
                
                if (variable_struct_exists(_rp, "anim_struct_overrides"))
                {
                    var _ao = _rp.anim_struct_overrides;
                    var _ao_keys = variable_struct_get_names(_ao);
                    var _ao_n = array_length(_ao_keys);
                    for (var _aoi = 0; _aoi < _ao_n; _aoi++)
                    {
                        var _aok = _ao_keys[_aoi];
                        variable_struct_set(slot_data.anim_struct, _aok, variable_struct_get(_ao, _aok));
                    }
                }
                
                if (variable_struct_exists(_rp, "visual"))
                    slot_data.visual = _rp.visual;
                
                if (variable_struct_exists(_rp, "slot_front"))
                    slot_front = _rp.slot_front;
                
                if (variable_struct_exists(_rp, "sp_place_init") && _rp.sp_place_init)
                    slot_data.sp_place = [];
                
                if (variable_struct_exists(_rp, "set_timer"))
                    slot_data.set_timer = _rp.set_timer;
                
                if (variable_struct_exists(_rp, "slot_range"))
                    slot_range = _rp.slot_range;
                
                if (variable_struct_exists(_rp, "slot_h"))
                    slot_h = _rp.slot_h;
                
                if (variable_struct_exists(_rp, "scr_slot_step"))
                    scr_slot_step = _rp.scr_slot_step;
                
                if (variable_struct_exists(_rp, "scr_slot_base"))
                    scr_slot_base = _rp.scr_slot_base;
                
                if (variable_struct_exists(_rp, "candle_index"))
                    candle_index = _rp.candle_index;
                
                if (variable_struct_exists(_rp, "milk_num"))
                    slot_data.milk_num = _rp.milk_num;
                
                if (variable_struct_exists(_rp, "clone_wait"))
                    slot_data.clone_wait = _rp.clone_wait;
                
                if (variable_struct_exists(_rp, "bar_glow_rep"))
                    bar_glow_rep = _rp.bar_glow_rep;
                
                if (variable_struct_exists(_rp, "extra_spawn_part") && _rp.extra_spawn_part)
                    array_push(spawn_part, false);
                
                if (variable_struct_exists(_rp, "dirt_fix_inc") && _rp.dirt_fix_inc)
                    global.dirt_fix++;
                
                if (variable_struct_exists(_rp, "death_fix_inc") && _rp.death_fix_inc)
                    global.death_fix++;
                
                if (variable_struct_exists(_rp, "del_item_type"))
                {
                    var _del_type = _rp.del_item_type;
                    var _dil_num = ds_list_size(global.inv_list);
                    
                    for (var _dii = 0; _dii < _dil_num; _dii++)
                    {
                        var _ditem = ds_list_find_value(global.inv_list, _dii);
                        
                        if (_ditem.item_type == _del_type)
                        {
                            ds_list_delete(global.inv_list, _dii);
                            _dii = _dil_num;
                        }
                    }
                }
                
                _reg_handled = true;
            }
            
            if (!_reg_handled)
            {
                switch (arg1)
                {
                    case 1:
                        slot_data.slot_dirt = 0;
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.anal = false;
                        slot_data.spr_row_pos = 0;
                        spr_slot = [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_1_back, false, -1], [2, spr_slot_wall_1_handc, true, -1], [5, spr_slot_wall_1_extra, false, -1], [7, -1, false, -1, false], [8, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        scr_slot_draw_special = scr_draw_slot_parts_wall;
                        slot_data.hand_x = [17, 6];
                        slot_data.hand_y = [-42, -40];
                        slot_data.hand_xscale = [1, 1];
                        slot_data.hand_angle = [90, 0];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = [1];
                        slot_data.hand_frame[2] = [2, 3];
                        slot_data.hand_frame[3] = [2, 3];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-31, -30];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-28, -33];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = -1;
                        break;
                    
                    case 2:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.anal = false;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_2_back, false, -1], [3, spr_slot_wall_2_legc, true, -1], [2, spr_slot_wall_2_handc, true, -1], [7, -1, false, -1, false], [8, -1, false, -1, false], [9, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        scr_slot_draw_special = scr_draw_slot_parts_wall;
                        slot_data.hand_x = [17, 6, 17];
                        slot_data.hand_y = [-42, -40, -13];
                        slot_data.hand_xscale = [1, 1, 1];
                        slot_data.hand_angle = [90, 0, 90];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = [1];
                        slot_data.hand_frame[2] = [2, 3];
                        slot_data.hand_frame[3] = [2, 3];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-31, -30];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-28, -33];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = -1;
                        break;
                    
                    case 7:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.anal = false;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_3_back, false, -1], [3, spr_slot_wall_3_legc, true, -1], [2, spr_slot_wall_3_handc, true, -1], [8, -1, false, -1, false], [7, -1, false, -1, false], [9, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        scr_slot_draw_special = scr_draw_slot_parts_wall;
                        slot_data.hand_x = [17, 6];
                        slot_data.hand_y = [-39, -20];
                        slot_data.hand_xscale = [-1, -1];
                        slot_data.hand_angle = [90, 0];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = [1];
                        slot_data.hand_frame[2] = [2, 3];
                        slot_data.hand_frame[3] = [2, 3];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-30, -23];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-30, -26];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 1;
                        break;
                    
                    case 8:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.anal = false;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_4_back, false, -1], [2, spr_slot_wall_4_handc, true, -1], [5, spr_slot_wall_4_extra, false, -1], [7, -1, false, -1, false], [8, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        scr_slot_draw_special = scr_draw_slot_parts_wall;
                        slot_data.hand_x = [17, 6];
                        slot_data.hand_y = [-38, -35];
                        slot_data.hand_xscale = [-1, -1];
                        slot_data.hand_angle = [90, 0];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = [1];
                        slot_data.hand_frame[2] = [2, 3];
                        slot_data.hand_frame[3] = [2, 3];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-30, -23];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-30, -26];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 1;
                        break;
                    
                    case 9:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[0, spr_slot_press_1_back, false, -1], [5, spr_slot_press_1_extra, false, -1], [12, spr_dirt_mp, false, -1, false], [9, -1, -2, -1, false], [6, -1, false, -1, true], [8, -1, false, -1, false], [2, spr_slot_press_1_handc, true, -1], [7, -1, false, -1, false], [11, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        slot_data.hand_x = [3];
                        slot_data.hand_y = [-11];
                        slot_data.hand_xscale = [-1];
                        slot_data.hand_angle = [0];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = -1;
                        slot_data.hand_frame[2] = [2, 3];
                        slot_data.hand_frame[3] = [3, 4];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-17, -14];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-17, -14];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 1;
                        break;
                    
                    case 13:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[10, -1, -2, -1, false, -1], [0, spr_slot_prone_1_back, false, -1], [12, spr_dirt_prone, false, -1, false], [6, -1, false, -1, false], [8, -1, false, -1, false], [2, spr_slot_prone_1_handc, true, -1], [7, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        slot_data.hand_x = [4];
                        slot_data.hand_y = [-23];
                        slot_data.hand_xscale = [-1];
                        slot_data.hand_angle = [0];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = -1;
                        slot_data.hand_frame[2] = [2, 3];
                        slot_data.hand_frame[3] = [3, 4];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-22, -25];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-22, -25];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 0;
                        break;
                    
                    case 14:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[12, spr_dirt_back, false, -1, false], [5, spr_slot_ride_extra, false, -1], [8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-5, -25];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-5, -25];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = -1;
                        break;
                    
                    case 3:
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[0, spr_slot_tf_1_back, false, -1], [8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [5, spr_slot_tf_1_extra, false, -1], [12, spr_dirt_tf, false, -1, false], [6, -1, false, -1, false], [2, spr_slot_tf_1_handc, true, -1], [7, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej_2, scr_slot_h_base_wait]
                        };
                        slot_data.hand_x = [7, 17];
                        slot_data.hand_y = [-21, -11];
                        slot_data.hand_xscale = [-1, -1];
                        slot_data.hand_angle = [0, 90];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = -1;
                        slot_data.hand_frame[2] = [3, 4];
                        slot_data.hand_frame[3] = [3, 4];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-24];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-16];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 0;
                        break;
                    
                    case 6:
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[0, spr_slot_bj_1_back, false, -1], [12, spr_dirt_wall, false, -1, false], [2, spr_slot_bj_1_handc, true, -1], [10, -1, -2, -1, false, -1], [7, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        slot_data.hand_x = [7, 17];
                        slot_data.hand_y = [-29, -12];
                        slot_data.hand_xscale = [-1, -1];
                        slot_data.hand_angle = [0, 90];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = 0;
                        slot_data.hand_frame[2] = [3, 4];
                        slot_data.hand_frame[3] = [3, 4];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-22];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-22];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 2;
                        break;
                    
                    case 15:
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 0;
                        spr_slot = [[8, -1, false, -1, false], [0, spr_slot_foreplay, false, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-34];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-34];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 0;
                        break;
                    
                    case 5:
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        slot_data.spr_row_pos = 0;
                        spr_slot = [[0, spr_slot_birth_back, false, -1], [5, spr_slot_birth_extra, false, -1], [10, -1, -2, -1, false, -1], [7, -1, -2, -1, false], [6, -1, -2, -1, false], [8, -1, -2, -1, false], [1, spr_slot_birth_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_birth_idle,
                            h: [scr_slot_birth_spawn_loop, scr_slot_non_h_base_wait, scr_slot_birth_spawn_ej]
                        };
                        slot_data.hand_x = [7];
                        slot_data.hand_y = [-34];
                        slot_data.hand_xscale = [1];
                        slot_data.hand_angle = [0];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = -1;
                        slot_data.hand_frame[2] = [0];
                        slot_data.hand_frame[3] = [0];
                        break;
                    
                    case 12:
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        slot_data.spr_row_pos = 0;
                        spr_slot = [[0, spr_slot_birth_2_back, false, -1], [8, -1, -2, -1, false], [6, -1, -2, -1, false], [10, -1, -2, -1, false, -1], [5, spr_slot_birth_2_front, false, -1], [1, spr_slot_birth_2_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_birth_idle,
                            h: [scr_slot_birth_spawn_loop, scr_slot_non_h_base_wait, scr_slot_birth_spawn_ej]
                        };
                        break;
                    
                    case 4:
                        slot_data.max_mon_num = 1;
                        slot_data.milk_step = 0;
                        slot_data.spr_row_pos = 0;
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        spr_slot = [[0, spr_slot_milk_1_back, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, false], [10, -1, -2, -1, false, -1], [2, spr_slot_milk_1_handc, true, -1], [7, -1, false, -1, false], [1, spr_slot_milk_1_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_milk_idle,
                            h: [scr_slot_h_milk_loop]
                        };
                        scr_slot_draw_special = scr_draw_slot_milk;
                        slot_data.hand_x = [8];
                        slot_data.hand_y = [-26];
                        slot_data.hand_xscale = [-1];
                        slot_data.hand_angle = [0];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = -1;
                        slot_data.hand_frame[2] = [2];
                        slot_data.hand_frame[3] = [2];
                        break;
                    
                    case 10:
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        slot_data.spr_row_pos = 0;
                        spr_slot = [[0, spr_slot_display_back, false, -1], [11, -1, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, true], [10, -1, -2, -1, false, -1], [1, spr_slot_display_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_display_idle
                        };
                        break;
                    
                    case 11:
                        slot_data.max_mon_num = 2;
                        slot_data.drink_num = 0;
                        slot_data.mon_index = [0, 0];
                        slot_data.sign_y = -86 + irandom_range(-2, 2);
                        slot_data.spr_row_pos = 0;
                        spr_slot = [[0, spr_slot_drink_back, false, -1], [2, spr_slot_drink_handc, true, -1], [7, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, -2, -1, true], [1, spr_slot_drink_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_drink_idle,
                            h: [scr_slot_h_drink_loop]
                        };
                        slot_data.hand_x = [6];
                        slot_data.hand_y = [-48];
                        slot_data.hand_xscale = [-1];
                        slot_data.hand_angle = [0];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = -1;
                        slot_data.hand_frame[2] = [3, 4];
                        slot_data.hand_frame[3] = [3, 4];
                        scr_slot_draw_special = scr_draw_slot_drink;
                        slot_range = 3;
                        break;
                    
                    case 36:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 2;
                        slot_data.sign_y = -92 + irandom_range(-1, 1);
                        blink_spr = spr_cow_blink;
                        slot_data.anim_struct.milk_index = -1;
                        slot_data.anim_struct.milk_timer = -1;
                        slot_data.anim_struct.milk_spd = -1;
                        slot_data.anim_struct.blink_index = -1;
                        slot_data.anim_struct.blink_timer = 0;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [5, spr_slot_cow_extra, false, -1], [10, -1, -2, -1, false], [6, -1, -2, -1, false], [8, -1, false, -1, false], [7, -1, false, -1, false], [1, spr_slot_cow_sign, true, -1], [4, 0, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_cow_state_idle, scr_slot_cow_state_loop, scr_slot_cow_state_floop, scr_slot_cow_state_ej]
                        };
                        scr_slot_draw_special = scr_draw_slot_cow;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-30];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-16];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 0;
                        _num = ds_list_size(global.inv_list);
                        
                        for (var i = 0; i < _num; i++)
                        {
                            var _item = ds_list_find_value(global.inv_list, i);
                            
                            if (_item.item_type == 2)
                            {
                                ds_list_delete(global.inv_list, i);
                                i = _num;
                            }
                        }
                        
                        break;
                    
                    case 37:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        bar_glow_rep = -1;
                        slot_data.spr_row_pos = 0;
                        slot_data.slot_dirt = 0;
                        slot_data.sign_y = -92 + irandom_range(-1, 1);
                        spr_slot = [[12, spr_dirt_giant, false, -1, false], [13, 0, true, -1], [5, spr_slot_giant_extra, false, -1], [2, spr_slot_giant_control, true, -1, false], [3, spr_slot_giant_control, true, -1, false], [7, -1, true, -1, false], [10, -1, -2, -1, false], [6, -1, true, -1, false], [8, -1, true, -1, false], [9, -1, false, -1, false], [11, -1, false, -1, false], [1, spr_slot_giant_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_giant_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_giant_birth, scr_slot_h_giant_birth_ej, scr_slot_h_base_wait]
                        };
                        scr_slot_draw_special = scr_draw_slot_giant;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 38;
                        slot_data.sq_y = [-17];
                        slot_data.sp_x = 38;
                        slot_data.sp_y = [-17];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 0;
                        break;
                    
                    case 38:
                        slot_data.max_mon_num = 2;
                        slot_data.mon_timer = [0, 0];
                        slot_data.set_timer = 0;
                        slot_data.allow_preg = true;
                        slot_data.spr_row_pos = 16;
                        slot_data.slot_dirt = 0;
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        slot_data.sp_place = [];
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [0, spr_slot_chain_bg, false, -1], [5, spr_slot_chain_extra, false, -1], [6, -1, false, -1, false], [8, -1, false, -1, false], [1, spr_slot_chain_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_chain_idle,
                            h: [scr_slot_h_chain_sloop, scr_slot_h_chain_floop, scr_slot_h_chain_ej]
                        };
                        scr_slot_draw_special = scr_draw_slot_chain;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = [32, 42];
                        slot_data.sq_y = [-36, -36];
                        slot_data.sp_x = [32, 42];
                        slot_data.sp_y = [-36, -36];
                        slot_data.sp_anim_x = -1;
                        slot_data.sp_anim_y = 1;
                        break;
                    
                    case 17:
                        slot_data.max_mon_num = 2;
                        slot_data.spr_row_pos = 16;
                        slot_data.sign_y = -90 + irandom_range(-2, 2);
                        slot_data.visual = true;
                        spr_slot = [[5, spr_slot_carry_extra, false, -1], [8, -1, false, -1, false], [10, -1, false, -1, false], [6, -1, false, -1, false], [0, spr_slot_carry_back, false, -1], [1, spr_slot_carry_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_carry_idle,
                            h: [scr_slot_carry_load, scr_slot_carry_active]
                        };
                        slot_data.anim_struct.char_state = 0;
                        scr_slot_draw_special = scr_draw_slot_carry;
                        scr_slot_step = scr_slot_state;
                        slot_range = 2;
                        break;
                    
                    case 18:
                        slot_data.max_mon_num = 3;
                        slot_data.set_timer = 0;
                        slot_data.allow_preg = true;
                        slot_data.spr_row_pos = 16;
                        slot_data.slot_dirt = 0;
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [10, -1, false, -1, false], [6, -1, -2, -1, false], [8, -1, false, -1, false], [0, spr_slot_gb_1_back, false, -1], [1, spr_slot_gb_sign, true, -1], [4, 0, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_gb_1_sloop, scr_slot_h_gb_1_floop, scr_slot_h_gb_1_ej]
                        };
                        scr_slot_draw_special = scr_draw_slot_gb_1;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-31, -33];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-28, -33];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = -1;
                        break;
                    
                    case 19:
                        slot_data.max_mon_num = 2;
                        slot_data.mon_timer = [0, 0];
                        slot_data.set_timer = 0;
                        slot_data.allow_preg = true;
                        slot_data.spr_row_pos = 16;
                        slot_data.slot_dirt = 0;
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        slot_data.sp_place = [];
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [0, spr_slot_gb_2_back, false, -1], [10, -1, false, -1, false], [6, -1, false, -1, true], [8, -1, false, -1, false], [1, spr_slot_gb_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_gb_2_idle,
                            h: [scr_slot_h_gb_2_sloop, scr_slot_h_gb_2_floop, scr_slot_h_gb_2_ej]
                        };
                        scr_slot_draw_special = scr_draw_slot_gb_2;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 38;
                        slot_data.sq_y = [-14, -18];
                        slot_data.sp_x = 38;
                        slot_data.sp_y = [-14, -18];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 1;
                        break;
                    
                    case 23:
                        slot_data.max_mon_num = 2;
                        slot_data.mon_timer = [0, 0];
                        slot_data.set_timer = 0;
                        slot_data.allow_preg = true;
                        slot_data.spr_row_pos = 16;
                        slot_data.slot_dirt = 0;
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [10, -1, false, -1, false], [6, -1, false, -1, false], [8, -1, false, -1, false], [1, spr_slot_gb_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_gb_3_sloop, scr_slot_h_gb_3_floop, scr_slot_h_gb_3_ej]
                        };
                        scr_slot_draw_special = scr_draw_ogre_behind;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 38;
                        slot_data.sq_y = [-19, -25];
                        slot_data.sp_x = 38;
                        slot_data.sp_y = [-19, -25];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = -1;
                        break;
                    
                    case 24:
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 16;
                        slot_data.sign_y = -90 + irandom_range(-2, 2);
                        slot_data.visual = true;
                        spr_slot = [[8, -1, -2, -1, false], [10, -1, false, -1, false], [0, spr_slot_patrol_back, false, -1], [6, -1, -2, -1, false], [7, -1, -2, -1, false], [1, spr_slot_patrol_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_patrol_idle,
                            h: [scr_slot_patrol_active]
                        };
                        slot_data.hand_x = [32];
                        slot_data.hand_y = [-71];
                        slot_data.hand_xscale = [1];
                        slot_data.hand_angle = [90];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = [1];
                        slot_data.anim_struct.char_state = 0;
                        scr_slot_draw_special = scr_draw_slot_patrol;
                        slot_range = 1;
                        break;
                    
                    case 20:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 16;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [6, -1, false, -1, false], [8, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_big_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        scr_slot_draw_special = scr_draw_ogre_front;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 38;
                        slot_data.sq_y = [-10];
                        slot_data.sp_x = 38;
                        slot_data.sp_y = [-10];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 0;
                        break;
                    
                    case 21:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 16;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, true], [10, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_big_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        scr_slot_draw_special = scr_draw_ogre_behind;
                        break;
                    
                    case 22:
                        slot_data.allow_preg = true;
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 16;
                        slot_data.slot_dirt = 0;
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [10, -1, false, -1, false], [6, -1, false, -1, true], [8, -1, false, -1, false]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_big_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 38;
                        slot_data.sq_y = [-19];
                        scr_slot_draw_special = scr_draw_ogre_behind;
                        break;
                    
                    case 27:
                        slot_front = -1;
                        slot_data.allow_preg = true;
                        slot_data.spr_row_pos = 26;
                        spr_slot = [[8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, false, -1, true], [0, spr_tent_front, false, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_tent_idle,
                            h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
                        };
                        scr_slot_draw_special = scr_draw_slot_tent;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-26];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-26];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 1;
                        array_push(spawn_part, false);
                        break;
                    
                    case 28:
                        slot_front = -1;
                        slot_data.allow_preg = true;
                        slot_data.spr_row_pos = 26;
                        spr_slot = [[10, -1, -2, -1, false, -1], [6, -1, false, -1, true], [8, -1, false, -1, false], [0, spr_tent_front, false, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_tent_idle,
                            h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
                        };
                        scr_slot_draw_special = scr_draw_slot_tent;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-26];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-25];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = -1;
                        array_push(spawn_part, false);
                        break;
                    
                    case 31:
                        slot_front = spr_slot_wall_tent;
                        slot_data.allow_preg = true;
                        slot_data.spr_row_pos = 26;
                        var _front = choose(spr_tent_front_1, spr_tent_front_2);
                        spr_slot = [[8, -1, false, -1, false], [2, spr_empty, true, -1], [7, -1, false, -1, false], [3, spr_empty, true, -1], [9, -1, false, -1, false], [0, spr_tent_front, false, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_tent_idle,
                            h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
                        };
                        scr_slot_draw_special = scr_draw_slot_tent;
                        slot_data.hand_x = [4];
                        slot_data.hand_y = [-42];
                        slot_data.hand_xscale = [-1];
                        slot_data.hand_angle = [0];
                        slot_data.hand_frame[1] = [1];
                        slot_data.hand_frame[2] = [2, 3];
                        slot_data.hand_frame[3] = [2, 3];
                        slot_data.hand_frame[4] = [1];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-42];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-42];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 1;
                        array_push(spawn_part, false);
                        break;
                    
                    case 32:
                        slot_front = spr_slot_wall_tent;
                        slot_data.allow_preg = true;
                        var _front = choose(spr_tent_front_1, spr_tent_front_2);
                        slot_data.spr_row_pos = 26;
                        spr_slot = [[8, -1, false, -1, false], [2, spr_empty, true, -1], [7, -1, false, -1, false], [3, spr_empty, true, -1], [9, -1, false, -1, false], [0, spr_tent_front, false, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_tent_idle,
                            h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
                        };
                        scr_slot_draw_special = scr_draw_slot_tent;
                        slot_data.hand_x = [4, 9];
                        slot_data.hand_y = [-43, -52];
                        slot_data.hand_xscale = [1, 1];
                        slot_data.hand_angle = [0, 90];
                        slot_data.hand_frame[1] = [1];
                        slot_data.hand_frame[2] = [2, 3];
                        slot_data.hand_frame[3] = [2, 3];
                        slot_data.hand_frame[4] = [1];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-40];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-40];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = -1;
                        array_push(spawn_part, false);
                        break;
                    
                    case 29:
                        slot_front = spr_slot_wall_tent;
                        slot_data.allow_preg = true;
                        var _front = choose(spr_tent_front_1, spr_tent_front_2);
                        slot_data.spr_row_pos = 26;
                        spr_slot = [[10, -1, -2, -1, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, false], [0, spr_tent_front, false, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_tent_idle,
                            h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
                        };
                        scr_slot_draw_special = scr_draw_slot_tent;
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 22;
                        slot_data.sq_y = [-34];
                        slot_data.sp_x = 22;
                        slot_data.sp_y = [-34];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = -1;
                        array_push(spawn_part, false);
                        break;
                    
                    case 34:
                        slot_front = -1;
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        slot_data.spr_row_pos = 26;
                        spr_slot = [[0, spr_slot_clean_back, false, -1], [1, spr_slot_clean_sign, true, -1]];
                        scr_slot_step = scr_slot_clean_idle;
                        slot_range = 2;
                        slot_h = false;
                        break;
                    
                    case 33:
                        slot_front = spr_slot_wall_tent_2;
                        bar_glow_rep = 0;
                        slot_data.spr_row_pos = 26;
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        spr_slot = [[8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, false, -1, true], [1, spr_slot_recover_sign, true, -1], [0, spr_tent_front, false, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_recover_idle
                        };
                        scr_slot_draw_special = scr_draw_slot_tent;
                        break;
                    
                    case 30:
                        slot_front = spr_slot_wall_tent_2;
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        slot_data.spr_row_pos = 26;
                        slot_data.milk_num = 0;
                        spr_slot = [[6, -1, false, -1, false], [10, -1, -2, -1, false, -1], [1, spr_slot_milk_2_sign, true, -1], [0, spr_tent_front, false, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_milk_2_idle,
                            h: [scr_slot_h_milk_2_loop]
                        };
                        scr_slot_draw_special = scr_draw_slot_tent;
                        break;
                    
                    case 39:
                        slot_data.max_mon_num = 1;
                        slot_data.spr_row_pos = 16;
                        slot_data.slot_dirt = 0;
                        slot_range = 1;
                        global.dirt_fix++;
                        slot_data.allow_preg = true;
                        slot_data.sign_y = -92 + irandom_range(-1, 1);
                        spr_slot = [[0, spr_slot_l_shrine, false, -1], [12, spr_dirt_l_shrine, false, -1, false], [10, -1, false, -1, false], [8, -1, false, -1, false], [6, -1, false, -1, true], [7, -1, false, -1, false], [1, spr_slot_lilith_sign, true, -1]];
                        scr_slot = 
                        {
                            idle: scr_slot_h_state_idle,
                            h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
                        };
                        slot_data.hand_x = [20];
                        slot_data.hand_y = [-78];
                        slot_data.hand_xscale = [-1];
                        slot_data.hand_angle = [0];
                        slot_data.hand_frame = [];
                        slot_data.hand_frame[1] = [0];
                        slot_data.hand_frame[2] = [0, 1, 4];
                        slot_data.hand_frame[3] = [2];
                        sp_spr = spr_sp_v_start;
                        slot_data.sq_x = 38;
                        slot_data.sq_y = [-30];
                        slot_data.sp_x = 38;
                        slot_data.sp_y = [-30];
                        slot_data.sp_anim_x = 0;
                        slot_data.sp_anim_y = 1;
                        scr_slot_base = scr_slot_h_lilith_idle;
                        scr_slot_draw_special = scr_draw_slot_l_shrine;
                        candle_index = 0;
                        break;
                    
                    case 40:
                        slot_data.spr_row_pos = 16;
                        global.death_fix++;
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [0, spr_slot_v_shrine, false, -1]];
                        slot_h = false;
                        break;
                    
                    case 41:
                        slot_data.spr_row_pos = 16;
                        slot_range = 1;
                        slot_range = 5;
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [0, spr_slot_f_shrine, false, -1], [14, 0, true, -1]];
                        slot_h = false;
                        break;
                    
                    case 42:
                        slot_data.spr_row_pos = 16;
                        spr_slot = [[12, spr_dirt_big, false, -1, false], [0, spr_slot_r_shrine, false, -1]];
                        scr_slot_step = scr_slot_h_r_shrine_idle;
                        slot_h = false;
                        break;
                    
                    case 25:
                        slot_data.spr_row_pos = 16;
                        slot_data.clone_wait = 0;
                        slot_data.sign_y = -84 + irandom_range(-2, 2);
                        spr_slot = [[0, -1, false, -1], [1, spr_slot_clone_sign, true, -1]];
                        scr_slot_draw_special = scr_draw_slot_clone;
                        scr_slot_step = scr_slot_h_clone_idle;
                        slot_h = false;
                        break;
                }
            }
            
            for (var i = 0; i < slot_data.max_mon_num; i++)
            {
                array_push(slot_data.mon_placement, -1);
                array_push(slot_data.mon_timer, 0);
                array_push(spawn_part, false);
            }
            
            var _num = array_length(spr_slot);
            slot_data.mod_index = [];
            slot_data.h_type = arg1;
            
            for (var i = 0; i < _num; i++)
            {
                if (spr_slot[i][0] == 2 || spr_slot[i][0] == 3)
                    slot_data.mod_index[i] = -1;
                else
                    slot_data.mod_index[i] = 0;
            }
            
            if (_wall != -1)
            {
                spr_base = _wall;
                _num = gnx_sprite_get_number(spr_base) - 1;
                slot_data.index = irandom_range(0, _num);
                image_yscale = -74;
            }
        }
        else
        {
            var _h_set = false;
            var _slot_w = 0;
            scr_set_slot_h_base();
            
            switch (slot_data.slot_type)
            {
                case 0:
                    image_yscale = -74;
                    break;
                
                case 1:
                    image_yscale = -74;
                    break;
                
                case 2:
                    image_yscale = -74;
                    break;
            }
        }
    }
}

function scr_create_anim_struct()
{
    slot_data.anim_struct = 
    {
        char_state: -1,
        index: -1,
        frame_c: -1,
        blink_index: -1,
        blink_timer: -1,
        spr_spd: -1,
        anim_spd: -1,
        sp_state: -1,
        sp_index: 0,
        sp_timer: irandom_range(30, 60),
        spr_type: -1,
        ff: true
    };
}

function scr_mon_birth(arg0, arg1)
{
    var _mon_type = arg0.mon_type;
    var _unit_class = arg0.class;
    var _unit_lvl = arg0.lvl;
    var _mon_class = 0;

    if (_mon_type < 0 || _mon_type > 3)
    {
        var _f = file_text_open_append(GNX_LOG);
        file_text_write_string(_f, "[GNX] scr_mon_birth: invalid mon_type=" + string(_mon_type) + " class=" + string(_unit_class) + " — skipping birth");
        file_text_writeln(_f);
        file_text_close(_f);
        exit;
    }

    // GNX: birth_class (struct) or birth_classes (array) maps human class → goblin class per species
    if (ds_map_exists(global.class_registry, _unit_class) && _unit_class >= 14)
    {
        var _gnx_rc = ds_map_find_value(global.class_registry, _unit_class);
        var _has_bc = false;
        if (variable_struct_exists(_gnx_rc, "birth_class") && is_array(_gnx_rc.birth_class))
        {
            _mon_class = _gnx_rc.birth_class[_mon_type];
            _has_bc = true;
        }
        else if (variable_struct_exists(_gnx_rc, "birth_classes") && is_array(_gnx_rc.birth_classes))
        {
            _mon_class = _gnx_rc.birth_classes[_mon_type];
            _has_bc = true;
        }
        if (_has_bc)
        {
            var _gnx_list = global.gnx_br_unlock[_mon_type][_mon_class];
            if (!array_contains(_gnx_list, _unit_class))
                array_push(_gnx_list, _unit_class);
            scr_mon_exp_edit(_mon_type, _mon_class, _unit_lvl, 3, false);
            scr_mon_num_edit(_mon_type, _mon_class, 1, true);
            global.val.nest_num[0]++;
            scr_check_steam_achievement(3);
        }
        exit;
    }

    switch (_mon_type)
    {
        case 0:
            _mon_class = 0;
            
            switch (_unit_class)
            {
                case 0:
                    _mon_class = 0;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 6:
                    _mon_class = 1;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 4:
                    _mon_class = 1;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 2:
                    _mon_class = 2;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 1:
                    _mon_class = 3;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 3:
                    _mon_class = 3;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 7:
                    _mon_class = 0;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 5:
                    _mon_class = 2;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
            }
            
            break;
        
        case 1:
            _mon_class = 0;
            
            switch (_unit_class)
            {
                case 0:
                    _mon_class = 1;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 6:
                    _mon_class = 1;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 4:
                    _mon_class = 2;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 2:
                    _mon_class = 2;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 1:
                    _mon_class = 0;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 3:
                    _mon_class = 3;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 7:
                    _mon_class = 3;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 5:
                    _mon_class = 0;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
            }
            
            break;
        
        case 2:
            _mon_class = 0;
            
            switch (_unit_class)
            {
                case 0:
                    _mon_class = 1;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 6:
                    _mon_class = 0;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 4:
                    _mon_class = 0;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 2:
                    _mon_class = 2;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 1:
                    _mon_class = 1;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 3:
                    _mon_class = 3;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 7:
                    _mon_class = 3;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 5:
                    _mon_class = 2;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
            }
            
            break;
        
        case 3:
            _mon_class = 0;
            
            switch (_unit_class)
            {
                case 0:
                    _mon_class = 0;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 6:
                    _mon_class = 0;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 4:
                    _mon_class = 1;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 2:
                    _mon_class = 1;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
                
                case 1:
                    _mon_class = 2;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;
                
                case 3:
                    _mon_class = 2;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;

                case 7:
                    _mon_class = 3;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 0);
                    break;

                case 5:
                    _mon_class = 3;
                    scr_mon_br_check(_mon_type, _mon_class, _unit_class, 1);
                    break;
            }

            break;
    }

    var _lvl = scr_mon_type_construct(_mon_type).lvl[_mon_class];
    scr_mon_exp_edit(_mon_type, _mon_class, _unit_lvl, 3, false);
    scr_mon_num_edit(_mon_type, _mon_class, 1, true);
    global.val.nest_num[0]++;
    scr_check_steam_achievement(3);
}

function scr_mon_br_check(arg0, arg1, arg2, arg3)
{
    if (global.val.br_unlock[arg0][arg1][arg3] == -1)
        global.val.br_unlock[arg0][arg1][arg3] = arg2;
}
