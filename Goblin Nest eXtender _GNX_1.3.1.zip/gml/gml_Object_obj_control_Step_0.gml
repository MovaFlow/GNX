scr_mouse_control();

// GNX-PERF: log draw stats every 120 frames (~2s) when enabled
if (global.gnx_perf_enabled)
{
    global.gnx_perf_frame++;
    if (global.gnx_perf_frame >= 120)
    {
        var _sd = global.gnx_perf_slots_drawn;
        var _sc = global.gnx_perf_slots_culled;
        var _md = global.gnx_perf_mons_drawn;
        var _mc = global.gnx_perf_mons_culled;
        var _pct = (_sd + _sc > 0) ? string(round((_sc / (_sd + _sc)) * 100)) : "0";
        var _f = file_text_open_append(GNX_LOG);
        file_text_write_string(_f, "[GNX-PERF] slots=" + string(_sd) + "/" + string(_sd + _sc)
            + " culled=" + _pct + "% mons=" + string(_md) + "/" + string(_md + _mc)
            + " fps=" + string(fps) + " fps_real=" + string(fps_real));
        file_text_writeln(_f);
        file_text_close(_f);
        global.gnx_perf_slots_drawn = 0;
        global.gnx_perf_slots_culled = 0;
        global.gnx_perf_mons_drawn = 0;
        global.gnx_perf_mons_culled = 0;
        global.gnx_perf_frame = 0;
    }
}

// GNX: per-frame quest completion check
scr_gnx_check_quest_completion("frame");

// GNX: tool system per-frame hooks (gated by gnx_has_tools inside each function)
scr_gnx_check_keybinds();
scr_gnx_apply_continuous_effects();
