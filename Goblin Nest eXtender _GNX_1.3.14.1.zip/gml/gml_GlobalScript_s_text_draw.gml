function scr_draw_textbox()
{
    if (!ff)
    {
        var _lang_pos = scr_change_lang();
        draw_set_halign(fa_left);
        
        for (var c = 0; c < draw_char; c++)
        {
            var _text = char[c][page];
            var _x = char_x[c][page] + _lang_pos[0];
            var _y = char_y[c][page] + _lang_pos[1];
            draw_set_alpha(0.3);
            draw_set_color(shadow_color);
            draw_text(_x + 1, _y + 1, _text);
            draw_set_alpha(1);
            draw_set_color(text_color);
            draw_text(_x, _y, _text);
        }
        
        draw_set_font(fnt_base_font_eng);
    }
}

function scr_draw_window_portrait()
{
    scr_draw_backdrop();
    draw_sprite(spr_raid_screen, 0, 170, 36);

    // GNX: runtime-loaded portraits are standalone sprites (ID >= 100);
    // vanilla portraits are sub-image indices (0-94) into spr_portrait sheet
    if (portrait_index >= 100 && sprite_exists(portrait_index))
        draw_sprite(portrait_index, 0, 173, 39);
    else
        draw_sprite(spr_portrait, portrait_index, 173, 39);
    var _lang_pos = scr_change_lang();
    var _y = 0;
    draw_set_halign(fa_center);
    draw_text(284 + _lang_pos[0], 40 + _y + _lang_pos[1], name_text);
    draw_set_font(fnt_base_font_eng);
    draw_set_halign(fa_left);
    draw_text(297, 214, string(textbox_id.page_number));
    draw_set_halign(fa_right);
    draw_text(293, 214, string(textbox_id.page + 1));
    draw_set_halign(fa_center);
    draw_text(295, 214, "/");
}

function scr_draw_backdrop()
{
    draw_set_alpha(0.7);
    draw_rectangle_color(0, 0, 480, 270, c_black, c_black, c_black, c_black, false);
    draw_set_alpha(1);
}

function scr_create_cat_skill_window(arg0, arg1)
{
    var _ex = 0;
    var _text_ex = 0;
    var _text_1, _text_2;
    
    switch (global.val.language)
    {
        case UnknownEnum.Value_0:
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Get more food from raiding.";
                            _text_2 = "Increases 8% per stack.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Monsters have a chance to not die.";
                            _text_2 = "Increases 4% per stack.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Front Formation AP increase.";
                            _text_2 = "Increases 3% per stack.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Higher chance to get items.";
                            _text_2 = "Increases 4% per stack.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Get more gold from raiding.";
                            _text_2 = "Increases 5% per stack.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Higher chance to capture units.";
                            _text_2 = "Increases 3% per stack.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Caravan speed increase.";
                            _text_2 = "Increases 3% per stack.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Back Formation AP increase.";
                            _text_2 = "Increases 3% per stack.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Mood increase after defeating the enemy in a raid.";
                            _text_2 = "Increases 0.5 per stack.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Chance to get milk after capturing units.";
                            _text_2 = "Increases 8% per stack.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Captured units have a chance to be a star higher.";
                            _text_2 = "Increases 2% per stack.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Get more gold and food from raiding.";
                            _text_2 = "Increases 3% per stack.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Front formation skills stack increase.";
                            _text_2 = "Increases by 1 per stack.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Back formation skills stack increase.";
                            _text_2 = "Increases by 1 per stack.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Rare star units spawn chance increase.";
                            _text_2 = "Increases 3% per stack.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Front and Back Formation AP increase.";
                            _text_2 = "Increases 2% per stack.";
                            break;
                    }
                    
                    break;
            }
            
            break;
        
        case UnknownEnum.Value_2:
            _ex = _text_ex;
            
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "洗劫获得更多食物。";
                            _text_2 = "每层叠加提升8%。";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "怪物有机会不死。";
                            _text_2 = "每层叠加提升4%。";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "前列编队AP增加。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "获得物品的几率更高。";
                            _text_2 = "每层叠加提升4%。";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "洗劫获得更多金币。";
                            _text_2 = "每层叠加提升5%。";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "成功捕获单位的几率更高。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "车队速度增加。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "后列编队AP增加。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "在洗劫中击败敌人后心情增加。";
                            _text_2 = "每层叠加提升0.5。";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "捕获单位后有一定几率获得乳汁。";
                            _text_2 = "每层叠加提升8%。";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "被捕获的单位有几率提升一颗星。";
                            _text_2 = "每层叠加提升2%。";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "洗劫获得更多金币和食物。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "前列编队技能叠加提升。";
                            _text_2 = "每层叠加提升1。";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "后列编队技能叠加提升。";
                            _text_2 = "每层叠加提升1。";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "稀有星级单位出现几率提升。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "前列与后列编队AP提升。";
                            _text_2 = "每层叠加提升2%。";
                            break;
                    }
                    
                    break;
            }
            
            break;
        
        case UnknownEnum.Value_9:
            _ex = _text_ex;
            
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "洗劫獲得更多食物。";
                            _text_2 = "每层叠加提升8%。";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "怪物有機會不死。。";
                            _text_2 = "每层叠加提升4%。";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "前列編隊AP增加。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "獲得物品的幾率更高。";
                            _text_2 = "每层叠加提升4%。";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "洗劫獲得更多金幣。";
                            _text_2 = "每层叠加提升5%。";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "成功捕獲單位的幾率更高。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "車隊速度增加。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "後列編隊AP增加。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "在洗劫中擊敗敵人後心情增加。";
                            _text_2 = "每层叠加提升0.5。";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "捕獲單位後有一定幾率獲得乳汁。";
                            _text_2 = "每层叠加提升8%。";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "被捕獲的單位有幾率提升一顆星。";
                            _text_2 = "每层叠加提升2%。";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "洗劫獲得更多金幣和食物。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "前列編隊技能疊加提升。";
                            _text_2 = "每层叠加提升1。";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "後列編隊技能疊加提升。";
                            _text_2 = "每层叠加提升1。";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "稀有星級單位出現幾率提升。";
                            _text_2 = "每层叠加提升3%。";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "前列與後列編隊AP提升。";
                            _text_2 = "每层叠加提升2%。";
                            break;
                    }
                    
                    break;
            }
            
            break;
        
        case UnknownEnum.Value_1:
            _ex = _text_ex;
            
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "襲撃でより多くの食料を獲得する";
                            _text_2 = "スタックごとに8%増加する";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "ンスターが死なない確率が上がる";
                            _text_2 = "スタックごとに4%増加する";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "前列フォーメーションのAPが増加する";
                            _text_2 = "スタックごとに3%増加する";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "アイテムを入手する確率が上がる";
                            _text_2 = "スタックごとに4%増加する";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "襲撃でより多くのゴールドを獲得する";
                            _text_2 = "スタックごとに5%増加する";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "ユニットを捕獲する確率が上がる";
                            _text_2 = "スタックごとに3%増加する";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "キャラバンの速度が増加する";
                            _text_2 = "スタックごとに3%増加する";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "後列フォーメーションのAPが増加する";
                            _text_2 = "スタックごとに3%増加する";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "襲撃で敵を倒した後、機嫌が上昇する";
                            _text_2 = "スタックごとに0.5増加する";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "ユニットを捕獲した後、ミルクを獲得する確率が上がる";
                            _text_2 = "スタックごとに8%増加する";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "捕獲したユニットがより高いスターになる確率が上がる";
                            _text_2 = "スタックごとに2%増加する";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "襲撃でより多くのゴールドと食料を獲得する";
                            _text_2 = "スタックごとに3%増加する";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "前列フォーメーションのスキルスタックが増加する";
                            _text_2 = "スタックごとに1増加する";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "後列フォーメーションのスキルスタックが増加する";
                            _text_2 = "スタックごとに1増加する";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "レアスターユニットの出現確率が増加する";
                            _text_2 = "スタックごとに3%増加する";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "前列と後列フォーメーションのAPが増加する";
                            _text_2 = "スタックごとに2%増加する";
                            break;
                    }
                    
                    break;
            }
            
            break;
        
        case UnknownEnum.Value_3:
            _ex = _text_ex;
            
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "습격에서 식량을 추가로 획득.";
                            _text_2 = "축적치당 8% 상승.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "몬스터의 사망 확률 감소.";
                            _text_2 = "축적치당 4% 상승.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "전열 AP 상승.";
                            _text_2 = "축적치당 3% 상승.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "아이템 획득 확률 상승.";
                            _text_2 = "축적치당 4% 상승.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "습격에서 금화를 추가로 획득.";
                            _text_2 = "축적치당 5% 상승.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "포로를 사로잡을 확률 상승.";
                            _text_2 = "축적치당 3% 상승.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "습격단 이동 속도 상승.";
                            _text_2 = "축적치당 3% 상승.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "후열 AP 상승.";
                            _text_2 = "축적치당 3% 상승.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "습격에서 적을 물리칠 시 사기 상승.";
                            _text_2 = "축적치당 0.5 상승.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "포로를 사로잡을 시 확률로 젖 획득.";
                            _text_2 = "축적치당 8% 상승.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "사로잡은 포로가 확률적으로 한 단계 더 높은 레어도를 지님.";
                            _text_2 = "축적치당 2% 상승.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "습격에서 금화와 식량을 추가로 획득.";
                            _text_2 = "축적치당 3% 상승.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "전열 스킬 축적치 상승.";
                            _text_2 = "축적치당 1 상승.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "후열 스킬 축적치 상승.";
                            _text_2 = "축적치당 1 상승.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "더 높은 레어도의 포획 대상이 출현할 확률 상승.";
                            _text_2 = "축적치당 3% 상승.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "전열과 후열의 AP 상승.";
                            _text_2 = "축적치당 2% 상승.";
                            break;
                    }
                    
                    break;
            }
            
            break;
        
        case UnknownEnum.Value_7:
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Получает больше еды с набегов.";
                            _text_2 = "Увеличивается 8% за стак.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Монстры имеют шанс не умереть.";
                            _text_2 = "Увеличивается 4% за стак.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Увеличивает СА Фронтового Строя.";
                            _text_2 = "Увеличивается 3% за стак.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Выше шанс получить предмет.";
                            _text_2 = "Увеличивается 4% за стак.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Получает больше золота с набегов.";
                            _text_2 = "Увеличивается 5% за стак.";
                            _width = 12.5;
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Выше шанс захватить юнита.";
                            _text_2 = "Увеличивается 3% за стак.";
                            _width = 10;
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Увеличивает скорость каравана.";
                            _text_2 = "Увеличивается 3% за стак.";
                            _width = 12;
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Увеличивает СА Тылового Строя.";
                            _text_2 = "Увеличивается 3% за стак.";
                            _width = 11.5;
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Увеличивает настроение после победы над врагом в набеге.";
                            _text_2 = "Увеличивается 0.5 за стак.";
                            _width = 21;
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Шанс получить молоко после захвата юнитов.";
                            _text_2 = "Увеличивается 8% за стак.";
                            _width = 16;
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Захваченные юниты имеют шанс быть на звезду выше.";
                            _text_2 = "Увеличивается 2% за стак.";
                            _width = 18;
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Получает больше золота и еды с набегов.";
                            _text_2 = "Увеличивается 3% за стак.";
                            _width = 14.5;
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Увеличивает стак навыков Фронтового Строя.";
                            _text_2 = "Увеличивается 1 за стак.";
                            _width = 16;
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Увеличивает стак навыков Тылового Строя.";
                            _text_2 = "Увеличивается 1 за стак.";
                            _width = 15;
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Увеличивает шанс появления редких звёздных юнитов.";
                            _text_2 = "Увеличивается 3% за стак.";
                            _width = 19;
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Увеличивает СА Фронтового и Тылового строя.";
                            _text_2 = "Увеличивается 2% за стак.";
                            _width = 16;
                            break;
                    }
                    
                    break;
            }
            
            break;
        
        case UnknownEnum.Value_4:
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Consigue más comida de los saqueos.";
                            _text_2 = "Aumenta 8% por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Los monstruos tienen probabilidad de no morir.";
                            _text_2 = "Aumenta 4% por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Aumento de PA en el Frente.";
                            _text_2 = "Aumenta 3% por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Mayor probabilidad de encontrar objetos.";
                            _text_2 = "Aumenta 4% por acumulación.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Consigue más oro de los saqueos.";
                            _text_2 = "Aumenta 5% por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Mayor probabilidad de capturar unidades.";
                            _text_2 = "Aumenta 3% por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Aumento de velocidad de la Caravana.";
                            _text_2 = "Aumenta 3% por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Aumento de PA en la Retaguardia.";
                            _text_2 = "Aumenta 3% por acumulación.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "El ánimo sube tras derrotar al enemigo durante un saqueo.";
                            _text_2 = "Aumenta 0.5 por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Probabilidad de conseguir leche tras capturar unidades.";
                            _text_2 = "Aumenta 8% por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Las unidades capturadas pueden ser de una estrella superior.";
                            _text_2 = "Aumenta 2% por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Consigue más oro y comida de los saqueos.";
                            _text_2 = "Aumenta 3% por acumulación.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Aumento de acumulación de habilidades del Frente.";
                            _text_2 = "Aumenta 1 por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Aumento de acumulación de habilidades de la Retaguardia.";
                            _text_2 = "Aumenta 1 por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Aumento de aparición de unidades estrella raras.";
                            _text_2 = "Aumenta 3% por acumulación.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Aumento de PA en el Frente y en la Retaguardia.";
                            _text_2 = "Aumenta 2% por acumulación.";
                            break;
                    }
                    
                    break;
            }
            
            break;
        
        case UnknownEnum.Value_6:
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Obtenez plus de nourriture lors des raids.";
                            _text_2 = "Augmentation de 8% par pile.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Les monstres ont une chance de ne pas mourir.";
                            _text_2 = "Augmentation de 4% par pile.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Augmentation des PA pour 'l'AVANT'. ";
                            _text_2 = "Augmentation de 3% par pile.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Chances accrues d'obtenir des objets.";
                            _text_2 = "Augmentation de 4% par pile.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Gagnez plus de pièces d'or lors des raids.";
                            _text_2 = "Augmentation de 5% par pile.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Chances accrues de capturer des unités.";
                            _text_2 = "Augmentation de 3% par pile.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Augmentation de la vitesse de la caravane.";
                            _text_2 = "Augmentation de 3% par pile.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Augmentation des PA pour le 'FOND'.";
                            _text_2 = "Augmentation de 3% par pile.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Augmentation du moral après avoir vaincu l'ennemi lors d'un raid.";
                            _text_2 = "Augmentation de 0.5 par pile.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Chance d'obtenir du lait après avoir capturé des unités.";
                            _text_2 = "Augmentation de 8% par pile.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Les unités capturées ont une chance d'avoir une étoile de plus.";
                            _text_2 = "Augmentation de 2% par pile.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Obtenez plus de pièces d'or et de nourriture lors des raids.";
                            _text_2 = "Augmentation de 3% par pile.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Augmentation des piles de compétences pour 'l'AVANT'. ";
                            _text_2 = "Augmentation de 1 par pile.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Augmentation des piles de compétences pour le 'FOND'.";
                            _text_2 = "Augmentation de 1 par pile.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Augmentation de la chance d'apparition d'unités rares.";
                            _text_2 = "Augmentation de 3 par pile.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Augmentation des PA en 'AVANT' et au 'FOND'.";
                            _text_2 = "Augmentation de 2 par pile.";
                            break;
                    }
                    
                    break;
            }
            
            break;
        
        case UnknownEnum.Value_8:
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Erlange mehr Essen durch Raubzüge.";
                            _text_2 = "Erhöhe 8% pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Monster haben eine Chance zu sterben.";
                            _text_2 = "Erhöhe 4% pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Vordere Formations AK steigern.";
                            _text_2 = "Erhöhe 3% pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Höhere Chance Items zu erlangen.";
                            _text_2 = "Erhöhe 4% pro Stapel.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Erlange mehr Gold durch Raubzüge.";
                            _text_2 = "Erhöhe 3% pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Höhere Chance Einheiten einzufangen.";
                            _text_2 = "Erhöhe 3% pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Karawanen Geschwindigkeit erhöhen.";
                            _text_2 = "Erhöhe 3% pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Hintere Formations AK steigern.";
                            _text_2 = "Erhöhe 3% pro Stapel.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Launen anstieg durch Vernichtung des Gegners im Raubzug.";
                            _text_2 = "Erhöhe 0.5 pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Chance,Milch zu erhalten, nachdem Einheiten eingefangen wurden.";
                            _text_2 = "Erhöhe 8% pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Gefangene Einheiten haben eine Chance ein Stern höher zu sein.";
                            _text_2 = "Erhöhe 2% pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Erlange mehr Gold und Nahrung durch Raubzüge.";
                            _text_2 = "Erhöhe 3% pro Stapel.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Vordere Formationsfähigkeiten Stapelerhöhung.";
                            _text_2 = "Erhöhe 1 pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Hintere Formationsfähigkeiten Stapelerhöhung.";
                            _text_2 = "Erhöhe 1 pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Seltene Stern Einheiten Erscheinungsrate erhöht.";
                            _text_2 = "Erhöhe 3% pro Stapel.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Vordere und hintere Formations AK erhöht.";
                            _text_2 = "Erhöhe 2% pro Stapel.";
                            break;
                    }
                    
                    break;
            }
            
            break;
        
        case UnknownEnum.Value_5:
            switch (arg0)
            {
                case UnknownEnum.Value_0:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Obtém mais comida de invasões.";
                            _text_2 = "Aumenta 8% por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Monstros têm a chance de não morrerem.";
                            _text_2 = "Aumenta 4% por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Aumento do PA da Formação da Linha de Frente.";
                            _text_2 = "Aumenta 3% por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Chances maiores de obter itens.";
                            _text_2 = "Aumenta 4% por acúmulo.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_1:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Obtém mais ouro de invasões.";
                            _text_2 = "Aumenta 5% por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Chances maiores de capturar unidades.";
                            _text_2 = "Aumenta 3% por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Aumento da velocidade da caravana.";
                            _text_2 = "Aumenta 3% por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Aumento do PA da Formação de Defesa.";
                            _text_2 = "Aumenta 3% por acúmulo.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_2:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Aumento da Moral após derrotar o inimigo em uma invasão.";
                            _text_2 = "Aumenta 0.5 por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Chance de obter leite após capturar unidades.";
                            _text_2 = "Aumenta 8% por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Unidades capturadas têm a chance de ser uma estrela mais alta.";
                            _text_2 = "Aumenta 2% por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Obtém mais ouro e comida de invasões.";
                            _text_2 = "Aumenta 3% por acúmulo.";
                            break;
                    }
                    
                    break;
                
                case UnknownEnum.Value_3:
                    switch (arg1)
                    {
                        case UnknownEnum.Value_0:
                            _text_1 = "Aumento do acúmulo de habilidades da formação da linha de frente.";
                            _text_2 = "Aumenta 1 por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_1:
                            _text_1 = "Aumento do acúmulo de habilidades da formação de defesa.";
                            _text_2 = "Aumenta 1 por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_2:
                            _text_1 = "Aumento da chance de aparecer unidades de estrelas raras.";
                            _text_2 = "Aumenta 3% por acúmulo.";
                            break;
                        
                        case UnknownEnum.Value_3:
                            _text_1 = "Aumento do PA da formação da Linha de Frente e de Defesa.";
                            _text_2 = "Aumenta 2% por acúmulo.";
                            break;
                    }
                    
                    break;
            }
            
            break;
    }
    
    var _length_1 = string_width(_text_1);
    var _length_2 = string_width(_text_2);
    var _width = (0.085 * max(_length_1, _length_2)) + _ex;
    
    if (global.val.language == UnknownEnum.Value_1 || global.val.language == UnknownEnum.Value_2 || global.val.language == UnknownEnum.Value_9 || global.val.language == UnknownEnum.Value_3)
        _width *= 1.3;
    
    with (instance_create_depth(127, 47 + (arg1 * 26), -2600, obj_window))
    {
        gui = true;
        interact_type = UnknownEnum.Value_10;
        sprite_index = spr_pixel;
        image_xscale = 36;
        image_yscale = 23;
        scr_window_end_step = -1;
        scr_window_draw = scr_cat_skill_draw;
        draw_width = _width;
        skill_text_1 = _text_1;
        skill_text_2 = _text_2;
    }
}

enum UnknownEnum
{
    Value_0,
    Value_1,
    Value_2,
    Value_3,
    Value_4,
    Value_5,
    Value_6,
    Value_7,
    Value_8,
    Value_9,
    Value_10
}
