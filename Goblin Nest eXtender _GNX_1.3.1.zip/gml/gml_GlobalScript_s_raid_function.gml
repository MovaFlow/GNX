function scr_create_raid()
{
    var _raid = instance_create_depth(x, y, -2400, obj_window);

    with (_raid)
    {
        sprite_index = spr_pixel;
        image_xscale = 480;
        image_yscale = 270;
        interact_type = 4;
        source_id = other.id;
        gui = true;
        trans = false;
        activate = false;
        trans_id = -1;
        seq_id = -1;
        raid_layer = -1;
        raid_surf = -1;
        ap_save = -1;
        raid_data = {};
        raid_data.raid_state = 0;
        raid_data.ff = true;
        raid_data.raid_pos = 0;
        raid_data.wait = 0;
        raid_data.stage = -1;
        raid_data.ap = [0, 0];
        raid_data.en_ap = [0, 0];
        raid_data.lost = false;
        raid_data.cat = 0;
        raid_data.rob_pos = -1;
        raid_data.spd = 0;
        raid_data.max_time = 0;
        raid_data.time_left = 0;
        raid_data.haste = 1;
        raid_data.skill_exp = [[-1, -1, -1, -1, -1], [-1, -1, -1, -1, -1], [-1, -1, -1, -1, -1], [-1, -1, -1, -1, -1]];
        raid_data.skill_num = [[-1, -1, -1, -1, -1], [-1, -1, -1, -1, -1], [-1, -1, -1, -1, -1], [-1, -1, -1, -1, -1]];
        raid_data.skill_type = [[-1, -1, -1, -1, -1], [-1, -1, -1, -1, -1], [-1, -1, -1, -1, -1], [-1, -1, -1, -1, -1]];
        scr_window_step = scr_raid_step;
        scr_window_end_step = scr_raid_end_step;
        scr_window_draw = scr_draw_raid;
        line_c = make_color_rgb(104, 46, 32);
        extra_row_num = 0;
        slider_y = 0;
        row_h = 20;
        inv_slider = -1;
        inv_surface = -1;
        raid_surf = -1;
    }

    return _raid;
}

function scr_raid_step()
{
    switch (raid_data.raid_state)
    {
        case 0:
            scr_raid_state_base();
            break;

        case 1:
            scr_raid_state_raiding();
            break;

        case 2:
            scr_raid_state_return();
            break;

        case 3:
            scr_raid_state_trade();
            break;

        case 4:
            scr_raid_state_shop();
            break;
    }
}

function scr_raid_end_step()
{
    if (trans)
    {
        trans = false;
        activate = !activate;

        if (instance_exists(obj_button))
        {
            with (obj_button)
            {
                if (interact_type == 21 || interact_type == 39 || interact_type == 22 || interact_type == 44 || interact_type == 45 || interact_type == 38 || interact_type == 62 || interact_type == 63 || interact_type == 47 || interact_type == 49 || interact_type == 50 || interact_type == 41 || interact_type == 43 || interact_type == 23 || interact_type == 24 || interact_type == 46 || interact_type == 48 || interact_type == 58 || interact_type == 59 || (interact_type == 20 && drag_type == 5))
                    instance_destroy();
            }
        }

        if (instance_exists(obj_window))
        {
            with (obj_window)
            {
                if (interact_type == 10 || interact_type == 12)
                    instance_destroy();
            }
        }

        if (activate)
        {
            global.camera_lock = true;
            global.muffle = 0.1;
            scr_set_raid_group(false);
            var _x = 61;
            var _y = 57;
            var _num = 0;
            scr_create_button_layout(_x - 42, _y + 1, depth - 5, 4, 1, 0, 23, 0, spr_mon_cat, 39, other.id, false, scr_create_mon_cat_button, -1, scr_draw_cat_mon_button);
            scr_reset_mon_cat_head(_x, _y, raid_data.cat);
            inv_slider = scr_create_inv_slider(0);
            scr_create_button(157, 160, depth - 1, spr_sort_button, 38, other.id, scr_create_sort_button, -1, scr_draw_sort_button, 0, 0);
            scr_create_button(466, 40, depth - 1, spr_form_save_button, 62, other.id, scr_create_saveform_button, -1, scr_draw_saveform_button, 0, 0);
            scr_create_button(327, 45, depth - 1, spr_form_load_button, 63, other.id, scr_create_loadform_button, -1, scr_draw_loadform_button, 0, 0);
            scr_create_button(369, 167, depth - 1, spr_get_button, 47, other.id, scr_create_sort_button, -1, scr_draw_get_button, 0, 0);
            scr_create_button(448, 167, depth - 1, spr_get_button, 47, other.id, scr_create_sort_button, -1, scr_draw_get_button, 1, 0);
            obj_item_desc = instance_create_depth(0, 0, depth - 5, obj_empty);

            with (obj_item_desc)
            {
                gui = true;
                scr_empty_draw = scr_draw_item_desc;
            }

            if (raid_layer != -1)
                layer_set_visible(raid_layer, activate);

            scr_reset_cage();

            switch (raid_data.raid_state)
            {
                case 0:
                    scr_create_map_buttons();
                    break;

                case 3:
                    raid_data.ff = true;
                    break;

                case 4:
                    raid_data.ff = true;
                    break;
            }

            with (obj_window)
            {
                if (interact_type == 5 && source_id == obj_np.obj_raid)
                    visible = true;
            }

            extra_row_num = scr_set_inventory_row();
        }
        else
        {
            global.camera_lock = false;
            global.muffle = 1;

            with (obj_window)
            {
                if (interact_type == 5 && source_id == obj_np.obj_raid)
                    visible = false;
            }

            if (raid_layer != -1)
                layer_set_visible(raid_layer, activate);

            with (obj_item_desc)
                instance_destroy();
        }
    }
}

function scr_raid_state_base()
{
    if (raid_data.ff)
    {
        raid_data.ff = true;
        raid_data.raid_pos = 0;
        raid_data.wait = 0;
    }
}

function scr_raid_state_raiding()
{
    if (raid_data.ff)
    {
        raid_data.ff = false;
        var _pos = raid_data.raid_pos;
        var _seq;

        switch (raid_data.stage)
        {
            case 0:
                _seq = seq_stage_1;
                break;

            case 1:
                _seq = seq_stage_2;
                break;

            case 2:
                _seq = seq_stage_3;
                break;

            case 3:
                _seq = seq_stage_4;
                break;

            case 4:
                _seq = seq_stage_5;
                break;
        }

        if (raid_layer == -1)
        {
            raid_layer = layer_create(9999, "seq");

            if (_seq != -1)
                seq_id = layer_sequence_create(raid_layer, 0, 0, _seq);
        }

        if (seq_id != -1)
        {
            layer_sequence_headdir(seq_id, 1);
            layer_sequence_headpos(seq_id, _pos);
        }

        layer_set_visible(raid_layer, activate);
        raid_data.spd = (60 / global.base_raid_time[raid_data.stage]) * raid_data.haste;
    }

    var _spd = raid_data.spd * global.val.cart_spd * global.w_spd;

    if (seq_id != -1)
        layer_sequence_speedscale(seq_id, _spd);

    raid_data.time_left -= global.w_spd;

    var _finished = (seq_id != -1) ? layer_sequence_is_finished(seq_id) : (raid_data.time_left <= 0);

    if (_finished)
    {
        raid_data.lost = scr_calculate_fight_outcome();
        raid_data.raid_state = 2;
        raid_data.ff = true;
        raid_data.raid_pos = (seq_id != -1) ? layer_sequence_get_headpos(seq_id) : 0;
    }
}

function scr_raid_state_return()
{
    if (raid_data.ff)
    {
        raid_data.ff = false;
        var _pos = raid_data.raid_pos;
        var _seq;

        switch (raid_data.stage)
        {
            case 0:
                _seq = seq_stage_1;
                break;

            case 1:
                _seq = seq_stage_2;
                break;

            case 2:
                _seq = seq_stage_3;
                break;

            case 3:
                _seq = seq_stage_4;
                break;

            case 4:
                _seq = seq_stage_5;
                break;
        }

        if (raid_layer == -1)
        {
            raid_layer = layer_create(-9998, "seq");

            if (_seq != -1)
                seq_id = layer_sequence_create(raid_layer, 0, 0, _seq);
        }

        if (seq_id != -1)
        {
            layer_sequence_headdir(seq_id, -1);
            layer_sequence_headpos(seq_id, _pos);
        }

        layer_set_visible(raid_layer, activate);
        raid_data.haste = 1 + scr_check_skill_data(6);
        raid_data.spd = (60 / global.base_raid_time[raid_data.stage]) * raid_data.haste;
        raid_data.max_time = round((global.base_raid_time[raid_data.stage] * 2) / (global.val.cart_spd * raid_data.haste));
        raid_data.time_left = raid_data.max_time * 0.5;
    }

    var _spd_mul = 1 + scr_check_skill_data(6);
    var _spd = raid_data.spd * global.val.cart_spd * global.w_spd;

    if (seq_id != -1)
        layer_sequence_speedscale(seq_id, _spd);

    raid_data.time_left -= global.w_spd;

    var _arrived = (seq_id != -1) ? (layer_sequence_get_headpos(seq_id) == 0) : (raid_data.time_left <= 0);

    if (_arrived)
    {
        scr_pop_up_create(11);

        if (raid_data.rob_pos != -1 && global.unlock.boss[1] == 0)
        {
            var _data = global.val.stage_info[raid_data.rob_pos[0]].info[raid_data.rob_pos[1]];
            var _units = _data.unit_list;

            if (array_length(_units) > 0 && _units[array_length(_units) - 1].class == 10)
            {
                array_delete(_units, array_length(_units) - 1, 1);
                var _ap = scr_set_unit_ap(10, 5);
                _data.en_ap[0] -= _ap[0];
                _data.en_ap[1] -= _ap[1];
            }

            raid_data.rob_pos = -1;
        }

        if (!raid_data.lost)
        {
            // GNX: escape check BEFORE encounter regen so boss_state gates spawns correctly
            scr_gnx_check_post_raid_escape();

            if (raid_data.stage != 4)
                scr_set_stage_data(raid_data.stage, global.val.stage_lvl_sel[raid_data.stage], true);

            scr_add_stage_exp(raid_data.stage, 5);

            if (raid_data.stage == 4)
                scr_set_stage_data(raid_data.stage, global.val.stage_lvl_sel[raid_data.stage], true);

            if (global.unlock.boss[1] == -1 && global.val.stage_info[1] != -1 && global.val.stage_info[1].max_lvl >= 2)
                scr_add_event(32, false);

            if (global.unlock.boss[1] == -1 && global.val.stage_info[2] != -1 && global.val.stage_info[2].max_lvl >= 1)
                scr_add_event(32, false);

            if (global.unlock.boss[3] == -1 && global.val.stage_info[3] != -1 && global.val.stage_info[0].max_lvl >= 3 && global.val.stage_info[1].max_lvl >= 3 && global.val.stage_info[2].max_lvl >= 3 && global.val.stage_info[3].max_lvl >= 2)
                scr_add_event(34, false);

            if (global.unlock.boss[4] == -1 && global.val.stage_info[3] != -1 && global.val.stage_info[3].max_lvl >= 1)
                scr_add_event(38, false);

            if (global.unlock.boss[4] <= -1 && global.val.stage_info[3] != -1 && global.val.stage_info[3].max_lvl == 3)
            {
                with (obj_slot)
                {
                    if (slot_data.slot_type == 1 && slot_data.h_type == 39)
                        scr_add_event(35, false);
                }
            }

            if (global.unlock.boss[1] == 0 && irandom_range(1, 100) <= 40)
            {
                scr_pop_up_create(26);
                var _array = [];

                for (var i = 0; i < ds_list_size(global.raid_inv_list); i++)
                {
                    if (ds_list_find_value(global.raid_inv_list, i).item_type == 0)
                        array_push(_array, i);
                }

                if (array_length(_array) > 0)
                {
                    var _choose = irandom_range(0, array_length(_array) - 1);
                    ds_list_delete(global.raid_inv_list, _array[_choose]);
                }

                raid_data.rob_pos = scr_check_raid_target();
                var _data = global.val.stage_info[raid_data.rob_pos[0]].info[raid_data.rob_pos[1]];
                var _units = _data.unit_list;

                if (array_length(_units) == 5)
                {
                    _ap = scr_set_unit_ap(_units[array_length(_units) - 1].class, _units[array_length(_units) - 1].lvl);
                    _data.en_ap[0] -= _ap[0];
                    _data.en_ap[1] -= _ap[1];
                    array_delete(_units, array_length(_units) - 1, 1);
                }

                array_push(_units, scr_create_unit_base(10, 5));
                var _ap = scr_set_unit_ap(10, 5);
                _data.en_ap[0] += _ap[0];
                _data.en_ap[1] += _ap[1];
            }

            // GNX: fire mod triggers on raid win
            scr_gnx_check_triggers("post_raid_win");
            scr_gnx_check_quest_completion("post_raid_win");
        }
        else
        {
            // GNX: fire mod triggers on raid loss
            scr_gnx_check_triggers("post_raid_loss");
        }

        // GNX: fire mod triggers after any raid (win or loss)
        scr_gnx_check_triggers("post_raid");

        // GNX: check quest completion post-raid
        scr_gnx_check_quest_completion("post_raid");

        raid_data.lost = false;

        if (seq_id != -1)
            layer_sequence_destroy(seq_id);

        layer_destroy(raid_layer);
        raid_layer = -1;
        seq_id = -1;
        raid_data.raid_state = 0;
        raid_data.ff = true;

        if (activate)
            scr_create_map_buttons();

        if (instance_exists(obj_carriage))
        {
            with (obj_carriage)
                instance_destroy();
        }
    }
}

function scr_set_raid_group(arg0)
{
    var _hold_id = obj_control.hold_id;

    with (obj_button)
    {
        if (interact_type == 22 && _hold_id != id)
            instance_destroy();
    }

    var _raid_id = obj_np.obj_raid;
    var _depth = _raid_id.depth - 5;
    var _x = 360;
    var _width = 22;

    with (_raid_id)
    {
        var _num = ds_list_size(global.front_row);
        scr_create_button_layout(_x, 64, _depth, _num, 5, _width, 0, 0, -1, 22, _raid_id, false, scr_create_group_head, -1, -1);
        _num = ds_list_size(global.back_row);
        scr_create_button_layout(_x, 119, _depth, _num, 5, _width, 0, 0, -1, 22, _raid_id, false, scr_create_group_head, -1, -1);

        if (arg0)
            scr_calculate_group_stat(-1);
    }
}
