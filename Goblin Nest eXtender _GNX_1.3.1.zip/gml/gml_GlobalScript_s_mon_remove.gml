function scr_unit_removal(arg0, arg1, arg2, arg3, arg4)
{
    var _placement = 0;
    var _preg = arg0;
    var _unit = -1;
    var _remove = true;
    
    if (arg4 != -1)
    {
        for (var ii = 0; ii < array_length(h_unit_list); ii++)
        {
            if (h_unit_list[ii] == arg4)
                _placement = h_unit_list[ii].mon_data.placement_num;
        }
    }
    
    switch (slot_data.h_type)
    {
        case 11:
            for (var i = 0; i < slot_data.max_mon_num; i++)
            {
                if (slot_data.mon_timer[i] == -1)
                    _placement = i;
            }
            
            arg2 = arg1;
            
            if (!arg1 && irandom_range(1, 100) <= 50 && unit_data != -1)
            {
                var _lvl = unit_data.lvl;
                
                if (unit_data.class >= 8)
                    _lvl = 2;
                
                var _icon_x;
                
                if (_placement == 1)
                    _icon_x = x + (image_xscale * 0.5) + 20;
                else
                    _icon_x = (x + (image_xscale * 0.5)) - 20;
                
                var _milk_num = 1 * min(5, _lvl + 1);
                global.val.food += _milk_num;
                scr_icon_pop_up_create(_icon_x, y - 62, _milk_num, 4, false);
            }
            
            break;
        
        case 36:
            if (arg4 != -1 && _placement == 0 && slot_data.mon_placement[1] != -1)
            {
                var _a = slot_data.mon_placement[0];
                slot_data.mon_placement[0] = slot_data.mon_placement[1];
                slot_data.mon_placement[1] = _a;
                slot_data.mon_placement[0].mon_data.placement_num = 0;
                slot_data.mon_placement[1].mon_data.placement_num = 1;
                slot_data.mon_placement[0].visible = false;
            }
            
            if (slot_data.mon_placement[1] != -1)
                _placement = 1;
            
            break;
        
        case 18:
            if (!arg1)
            {
                if (arg4 == -1)
                {
                    for (var ii = 0; ii < slot_data.max_mon_num; ii++)
                    {
                        if (slot_data.mon_placement[ii] != -1 && slot_data.mon_timer[ii] >= 600)
                        {
                            _placement = ii;
                            ii = slot_data.max_mon_num;
                        }
                    }
                    
                    if (arg0 && _placement != 1)
                        _preg = false;
                }
            }
            
            if (_placement == 0)
                slot_data.spr_touch = -1;
            
            break;
        
        case 19:
            if (!arg1)
            {
                if (arg4 == -1)
                {
                    for (var ii = 0; ii < slot_data.max_mon_num; ii++)
                    {
                        if (slot_data.mon_placement[ii] != -1 && slot_data.mon_timer[ii] >= 600)
                        {
                            _placement = ii;
                            ii = slot_data.max_mon_num;
                        }
                    }
                    
                    if (arg0 && _placement != 1)
                        _preg = false;
                }
            }
            
            break;
        
        case 38:
            if (!arg1)
            {
                if (arg4 == -1)
                {
                    for (var ii = 0; ii < slot_data.max_mon_num; ii++)
                    {
                        if (slot_data.mon_placement[ii] != -1 && slot_data.mon_timer[ii] >= 600)
                        {
                            _placement = ii;
                            ii = slot_data.max_mon_num;
                        }
                    }
                    
                    if (arg0 && _placement != 1)
                        _preg = false;
                }
            }
            
            break;
        
        case 23:
            if (!arg1)
            {
                if (arg4 == -1)
                {
                    for (var ii = 0; ii < slot_data.max_mon_num; ii++)
                    {
                        if (slot_data.mon_placement[ii] != -1 && slot_data.mon_timer[ii] >= 600)
                        {
                            _placement = ii;
                            ii = slot_data.max_mon_num;
                        }
                    }
                    
                    if (_placement == 0)
                        _remove = false;
                    else if (arg0)
                        _preg = false;
                }
            }
            
            break;
        
        case 24:
            if (array_length(h_unit_list) > 0)
                h_unit_list[0].scr_mon_begin_step = -1;
            
            break;
    }
    
    if (arg0)
    {
        if (_preg && slot_data.allow_preg && unit_data.preg == -1 && floor(unit_data.preg_c) != 0)
        {
            if (!slot_data.anal)
            {
                if (irandom_range(0, 100) <= unit_data.preg_prd || unit_data.class == 12)
                {
                    var _type = h_unit_list[0].mon_data.mon_type;
                    
                    switch (unit_data.class)
                    {
                        case 10:
                            _type = 1;
                            break;
                        
                        case 11:
                            _type = 3;
                            break;
                    }
                    
                    if (ds_map_exists(global.class_registry, unit_data.class))
                    {
                        var _rc_preg = ds_map_find_value(global.class_registry, unit_data.class);
                        
                        if (variable_struct_exists(_rc_preg, "preg_mon_type_override"))
                        {
                            _type = _rc_preg.preg_mon_type_override;
                            var _log = file_text_open_append(GNX_LOG);
                            file_text_write_string(_log, "[GNX] preg_mon_type_override class=" + string(unit_data.class) + " type=" + string(_type) + "\n");
                            file_text_close(_log);
                        }
                    }
                    
                    unit_data.preg = _type;
                    unit_data.preg_prd = 25;
                }
                else
                {
                    unit_data.preg_prd += 25;
                }
            }
            else
            {
                unit_data.preg_prd += 50;
            }
        }
        
        if (slot_data.slot_dirt != -1 && irandom_range(1, 100) <= 10)
            slot_data.slot_dirt = min(slot_data.slot_dirt + 1, 3);
        
        slot_data.anim_struct.sp_state = 0;
        scr_slot_get_coin_data(slot_data.h_type, unit_data);
    }
    else if (arg3)
    {
        scr_mood_value_set(-0.35);
    }
    
    if (slot_data.h_type <= 26 || slot_data.h_type >= 35)
    {
        if (_remove)
        {
            var _x = x + floor(image_xscale * 0.5) + irandom_range(-2, 2);
            var _y = y;
            var _door_id;
            
            if (!arg2)
                _door_id = scr_find_nearest_door(x, y, slot_data.slot_floor);
            else
                _door_id = -1;
            
            if (arg1)
            {
                while (array_length(h_unit_list) > 0)
                {
                    _placement = h_unit_list[0].mon_data.placement_num;
                    
                    if (h_unit_list[0].mon_data.slot_id != id)
                        array_delete(h_unit_list, 0, 1);
                    else
                        _unit = scr_remove_mon(_x, _y, _placement, _door_id);
                }
            }
            else
            {
                _unit = scr_remove_mon(_x, _y, _placement, _door_id);
            }
        }
        else
        {
            slot_data.mon_timer[_placement] = 0;
        }
        
        slot_data.h_step = 0;
        slot_data.h_wait = 0;
        slot_data.h_loop = 0;
        
        if (slot_data.anim_struct != -1)
        {
            slot_data.anim_struct.char_state = 0;
            slot_data.anim_struct.ff = true;
            slot_data.h_wait = irandom_range(240, 360);
        }
        
        if (_remove && arg4 == -1 && _unit != -1 && _unit.mon_data.removed_set == 0 && _unit.mon_data.mon_type == 0)
        {
            var _floor = slot_data.slot_floor;
            var _pos = ds_list_find_index(global.slot_list[_floor], id);
            var _drink_id = scr_check_drink_slot_range(_pos, 3, _floor);
            
            if (_drink_id != -1)
            {
                var _num = array_length(_drink_id.h_unit_list);
                var _drink_place;
                
                if (_num == 0)
                    _drink_place = choose(0, 1);
                else
                    _drink_place = !_drink_id.h_unit_list[0].mon_data.placement_num;
                
                _unit.mon_data.slot_id = _drink_id;
                _unit.mon_data.placement_num = _drink_place;
                array_push(_drink_id.h_unit_list, _unit);
            }
        }
        
        var _exists = false;
        
        for (var i = 0; i < slot_data.max_mon_num; i++)
        {
            if (slot_data.mon_placement[i] != -1)
            {
                _exists = true;
                i = slot_data.max_mon_num;
            }
        }
        
        switch (slot_data.h_type)
        {
            case 36:
                if (unit_data != -1)
                {
                    if (_exists)
                    {
                        slot_data.anim_struct.char_state = 1;
                    }
                    else
                    {
                        blink_spr = spr_cow_blink;
                        slot_data.anim_struct.blink_index = -1;
                        slot_data.anim_struct.blink_timer = 0;
                        slot_data.anim_struct.milk_index = -1;
                        slot_data.anim_struct.milk_timer = -1;
                        slot_data.anim_struct.milk_spd = -1;
                    }
                }
                
                break;
            
            case 38:
                if (unit_data != -1)
                {
                    if (_exists)
                        slot_data.anim_struct.char_state = 1;
                    
                    slot_data.anim_struct.sp_state = 0;
                    array_push(slot_data.sp_place, _placement);
                }
                
                break;
            
            case 18:
                if (unit_data != -1 && _exists)
                    slot_data.anim_struct.char_state = 1;
                
                break;
            
            case 19:
                if (unit_data != -1)
                {
                    if (_exists)
                        slot_data.anim_struct.char_state = 1;
                    
                    slot_data.anim_struct.sp_state = 0;
                    array_push(slot_data.sp_place, _placement);
                }
                
                break;
            
            case 23:
                if (unit_data != -1 && _exists)
                    slot_data.anim_struct.char_state = 1;
                
                break;
            
            case 17:
                if (arg4 != -1)
                {
                    if (array_length(h_unit_list) == 1)
                    {
                        var _id = h_unit_list[0];
                        
                        with (_id)
                        {
                            visible = true;
                            mon_data.ff = true;
                            mon_data.mon_state = 6;
                            mon_data.slot_id = scr_find_nearest_door(x, y, mon_data.mon_floor);
                        }
                        
                        slot_data.mon_placement = [-1, -1];
                        h_unit_list = [];
                    }
                }
                
                break;
            
            case 11:
                if (!arg1)
                {
                    if (arg4 == -1 && _unit != -1)
                    {
                        var _target_id = scr_check_empty_cell_range(id, 3);
                        var _place = -1;

                        if (_target_id != -1)
                        {
                            with (_target_id)
                            {
                                var _ar = scr_mon_find_placement();

                                if (_ar != -1)
                                {
                                    _place = _ar[1];
                                    array_push(h_unit_list, _unit);
                                    slot_data.load = true;
                                    slot_data.load_index = 0;
                                    slot_data.h_wait = irandom_range(240, 360);
                                    scr_create_slot_head(false, id);
                                }
                            }

                            if (_place != -1)
                            {
                                var _gfr = file_text_open_append(GNX_LOG);
                                file_text_write_string(_gfr, "[MON:" + string(_unit) + "] DRINK_REDISPATCH x=" + string(_unit.x) + " → h_type=" + string(_target_id.slot_data.h_type) + " cell_x=" + string(_target_id.x));
                                file_text_writeln(_gfr);
                                file_text_close(_gfr);
                                with (_unit)
                                {
                                    mon_data.slot_id = _target_id;
                                    mon_data.placement_num = _place;
                                    mon_data.task = 0;
                                }
                                var _gfr2 = file_text_open_append(GNX_LOG);
                                file_text_write_string(_gfr2, "[MON:" + string(_unit) + "] AFTER_REDISPATCH goblin_x=" + string(_unit.x));
                                file_text_writeln(_gfr2);
                                file_text_close(_gfr2);
                            }
                        }
                        else
                        {
                            // no valid cell in range — wander from drink center
                            var _cx = x + floor(image_xscale * 0.5);
                            var _cy = y;
                            var _gfr = file_text_open_append(GNX_LOG);
                            file_text_write_string(_gfr, "[MON:" + string(_unit) + "] DRINK_WANDER x=" + string(_unit.x) + " → wander from cx=" + string(_cx));
                            file_text_writeln(_gfr);
                            file_text_close(_gfr);
                            with (_unit)
                            {
                                x = _cx;
                                y = _cy;
                                mon_data.slot_id = -1;
                                mon_data.task = 0;
                                mon_data.mon_state = 5;
                                mon_data.ff = true;
                            }
                        }
                    }
                    
                    if (_exists)
                    {
                        slot_data.anim_struct.char_state = 1;
                        slot_data.anim_struct.ff = false;
                    }
                }
                
                break;
            
            case 37:
                if (unit_data != -1 && unit_data.preg != -1)
                {
                    slot_data.anim_struct.char_state = 1;
                    slot_data.anim_struct.ff = true;
                    slot_data.h_step = 6;
                }
                
                break;
            
            case 21:
                slot_data.anim_struct.sp_state = -1;
                break;
        }
    }
    else
    {
        slot_data.h_step = 0;
        slot_data.h_wait = 0;
        slot_data.h_loop = 0;
        
        if (h_unit_list != -1)
        {
            var _l = array_length(h_unit_list);
            
            for (var i = 0; i < _l; i++)
            {
                with (h_unit_list[i])
                    instance_destroy();
            }
        }
        
        h_unit_list = [];
    }
}

function scr_remove_mon(arg0, arg1, arg2, arg3)
{
    var _h_num = array_length(h_unit_list);
    var _unit;
    
    for (var i = 0; i < _h_num; i++)
    {
        with (h_unit_list[i])
        {
            if (mon_data.placement_num == arg2)
            {
                _unit = id;
                var _old_slot_id = mon_data.slot_id;
                var _old_placement_num = mon_data.placement_num;
                visible = true;
                scr_mon_draw = -1;
                mon_data.slot_id = -1;
                mon_data.ff = true;
                mon_data.spr_data = -1;
                mon_data.mood_slot_shift_x = 0;
                mon_data.mood_slot_shift_y = 0;
                mon_data.placement_num = -1;
                mon_data.follow = false;
                
                switch (mon_data.task)
                {
                    case 0:
                        if (arg3 != -1)
                        {
                            mon_data.slot_id = arg3;
							mon_data.follow = false;
                            x = arg0;
                            y = arg1;
                            
                            if (mon_data.removed_set == 3)
                                mon_data.removed_set = 4;
                            else
                                mon_data.removed_set = 0;
                            
                            mon_data.mon_state = 6;
                        }
                        else
                        {
                            if (mon_data.mon_state == 1)
                            {
                                x = arg0;
                                y = arg1;
                                mon_data.removed_set = 1;
                            }
                            
                            mon_data.mon_state = 5;
                        }
                        
                        _old_slot_id.slot_data.spr_touch = -1;
                        _old_slot_id.slot_data.spr_enter = -1;
                        break;
                    
                    case 1:
                        if (mon_data.mon_state == 1)
                        {
                            x = arg0;
                            y = arg1;
                        }
                        
                        mon_data.mon_state = 6;
                        
                        if (arg3 == -1)
                            arg3 = scr_find_nearest_door(x, y, mon_data.mon_floor);
                        
                        mon_data.slot_id = arg3;
                        break;
                    
                    case 3:
                        with (_old_slot_id)
                        {
                            slot_data.mod_index[0] = 0;
                            slot_data.visual = true;
                        }
                        
                        var _id;
                        
                        if (_old_placement_num == 0)
                        {
                            _id = id;
                            x += (image_xscale * 24);
                        }
                        else
                        {
                            _id = -1;
                            var _test_id = 0;
                            
                            for (var a = 0; a < array_length(_old_slot_id.h_unit_list); a++)
                            {
                                if (_old_slot_id.h_unit_list[a].mon_data.placement_num == 0)
                                    _id = _old_slot_id.h_unit_list[a];
                            }
                            
                            x += (image_xscale * -24);
                        }
                        
                        if (_id != -1)
                        {
                            with (_id)
                            {
                                if (mon_data.carry_start_id != -1)
                                {
                                    mon_data.carry_start_id.slot_data.load = false;
                                    mon_data.carry_start_id.slot_data.carry = false;
                                    mon_data.carry_start_id.slot_head_id = -1;
                                    mon_data.carry_start_id = -1;
                                }
                                
                                if (mon_data.carry_end_id != -1)
                                {
                                    mon_data.carry_end_id.slot_data.load = false;
                                    mon_data.carry_end_id.slot_data.carry = false;
                                    mon_data.carry_end_id.slot_head_id = -1;
                                    mon_data.carry_end_id = -1;
                                }
                                
                                _old_slot_id.scr_slot_step = scr_slot_state;
                                _old_slot_id.slot_data.anim_struct.char_state = 0;
                            }
                        }
                        
                        mon_data.slot_id = arg3;
                        mon_data.mon_state = 6;
                        
                        if (carry_emitter != -1)
                        {
                            part_emitter_destroy(obj_np.part_system_f, carry_emitter);
                            carry_emitter = -1;
                            mon_data.carry_wait = 0;
                        }
                        
                        break;
                    
                    case 5:
                        if (arg3 == -1)
                        {
                            mon_data.removed_set = 1;
                            mon_data.slot_id = scr_find_nearest_door(x, y, mon_data.mon_floor);
                        }
                        else
                        {
                            mon_data.slot_id = arg3;
                            mon_data.removed_set = 3;
                        }

                        x = arg0 + (-22 + (_old_placement_num * 46));
                        y = arg1;
                        mon_data.mon_state = 6;
                        {
                            var _log_r5h = -1;
                            if (mon_data.slot_id != -1 && instance_exists(mon_data.slot_id) && variable_instance_exists(mon_data.slot_id, "slot_data") && variable_struct_exists(mon_data.slot_id.slot_data, "h_type"))
                                _log_r5h = mon_data.slot_id.slot_data.h_type;
                            var _gfr5 = file_text_open_append(GNX_LOG);
                            file_text_write_string(_gfr5, "[MON:" + string(id) + "] REMOVED(drink) new_x=" + string(x) + " slot_id_h=" + string(_log_r5h) + " rset=" + string(mon_data.removed_set));
                            file_text_writeln(_gfr5);
                            file_text_close(_gfr5);
                        }
                        break;
                    
                    case 4:
                        with (_old_slot_id)
                        {
                            slot_data.mod_index[0] = 0;
                            slot_data.visual = true;
                        }
                        
                        mon_data.mon_state = 5;
                        break;
                }
                
                switch (mon_data.removed_set)
                {
                    case 0:
                        mon_data.mood_type = 3;
                        mon_data.mood_timer = 180;
                        break;
                    
                    case 4:
                        mon_data.mood_type = 3;
                        mon_data.mood_timer = 180;
                        break;
                    
                    case 3:
                        mon_data.mood_type = 3;
                        mon_data.mood_timer = 180;
                        break;
                    
                    case 1:
                        mon_data.mood_type = 0;
                        mon_data.mood_timer = 180;
                        scr_mood_value_set(-0.7);
                        break;
                }
                
                with (_old_slot_id)
                {
                    slot_data.mon_timer[arg2] = 0;
                    slot_data.mon_placement[arg2] = -1;
                    array_delete(h_unit_list, i, 1);
                }
                
                i = _h_num;
            }
        }
    }
    
    return _unit;
}

