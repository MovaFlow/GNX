function scr_create_mon(arg0, arg1, arg2, arg3, arg4, arg5)
{
    var _mon = instance_create_depth(arg1, arg2, -800, obj_mon);
    
    with (_mon)
    {
        mon_data = {};
        mon_data.mood_type = -1;
        mon_data.mood_timer = 0;
        mon_data.follow = false;
        mon_data.index = 0;
        mon_data.ff = true;
        mon_data.wait = 0;
        mon_data.xto = x;
        mon_data.yto = y;
        mon_data.wander_wait = 0;
        mon_data.wander_round = 0;
        mon_data.ispeed = 1;
        mon_data.placement_num = arg5;
        mon_data.mood_slot_shift_x = 0;
        mon_data.mood_slot_shift_y = 0;
        mon_data.display = false;
        mon_data.task = UnknownEnum.Value_0;
        mon_data.removed_set = -1;
        mon_data.mon_type = arg0;
        mon_data.mon_floor = arg3;
        mon_data.spr_data = -1;
        scr_mon_step = -1;
        scr_mon_begin_step = -1;
        scr_mon_end_step = -1;
        scr_mon_draw = -1;
        mon_spr = 
        {
            head_b: -1,
            head_l: -1,
            body_b: -1,
            body_l: -1,
            hand_b: -1,
            hand_l: -1,
            enter: -1,
            pen: -1,
            touch: -1,
            prop: -1,
            prop_l: -1
        };
        var _slot_h_type = -1;
        
        if (arg4 != -1)
        {
            mon_data.slot_id = ds_list_find_value(global.slot_list[arg3], arg4);
            
            if (mon_data.slot_id.slot_data.anim_struct != -1)
                _slot_h_type = mon_data.slot_id.slot_data.h_type;
        }
        else
        {
            mon_data.slot_id = -1;
        }
        
        var _state;
        
        switch (arg0)
        {
            case UnknownEnum.Value_0:
                if (_slot_h_type == UnknownEnum.Value_4)
                {
                    mon_data.task = UnknownEnum.Value_1;
                    spr_walk_e = spr_goblin_milk_walk_e;
                    spr_walk_f = spr_goblin_milk_walk_f;
                    mon_data.milk_full = false;
                    mon_data.spd = random_range(0.5, 0.6);
                    _state = UnknownEnum.Value_6;
                    scr_mon = 
                    {
                        idle: -1,
                        walk: scr_mon_state_walk_milk,
                        wander: -1,
                        h: scr_mon_state_h
                    };
                }
                else
                {
                    spr_idle = spr_goblin_idle;
                    spr_walk = spr_goblin_walk;
                    spr_b_walk = spr_goblin_b_walk;
                    mon_data.mood_shift_x = 6;
                    mon_data.mood_shift_y = -56;
                    mon_data.spd = choose(0.9, 1, 1.1);
                    _state = UnknownEnum.Value_0;
                    scr_mon = 
                    {
                        idle: scr_mon_state_idle,
                        walk: scr_mon_state_walk,
                        wander: scr_mon_state_wander,
                        h: scr_mon_state_h
                    };
                }
                
                break;
            
            case UnknownEnum.Value_1:
                spr_idle = spr_hobgoblin_idle;
                spr_walk = spr_hobgoblin_walk;
                spr_b_walk = spr_hobgoblin_b_walk;
                spr_carry = spr_hobgoblin_carry;
                mon_data.mood_shift_x = 6;
                mon_data.mood_shift_y = -82;
                carry_emitter = -1;
                
                if (_slot_h_type == UnknownEnum.Value_17)
                {
                    mon_data.spd = 1;
                    mon_data.task = UnknownEnum.Value_3;
                    mon_data.carry_wait = 0;
                    carry_emitter = -1;
                    _state = UnknownEnum.Value_7;
                }
                else
                {
                    mon_data.spd = choose(1.1, 1.2, 1.3);
                    _state = UnknownEnum.Value_0;
                }
                
                scr_mon = 
                {
                    idle: scr_mon_state_idle,
                    walk: scr_mon_state_walk,
                    wander: scr_mon_state_wander,
                    h: scr_mon_state_h,
                    carry_s: scr_mon_state_carry_start,
                    carry: scr_mon_state_carry,
                    carry_i: scr_mon_state_carry_idle
                };
                break;
            
            case UnknownEnum.Value_3:
                spr_idle = spr_ogre_idle;
                spr_walk = spr_ogre_walk;
                spr_b_walk = spr_ogre_walk;
                spr_unit = -1;
                spr_patrol = spr_ogre_walk_carry;
                mon_data.mood_shift_x = 6;
                mon_data.mood_shift_y = -92;
                mon_data.spd = choose(0.6, 0.7);
                mon_data.ispeed = 0.65;
                _state = UnknownEnum.Value_6;
                
                if (_slot_h_type == UnknownEnum.Value_24)
                {
                    mon_data.task = UnknownEnum.Value_4;
                    mon_data.spd = 0.5;
                }
                
                scr_mon = 
                {
                    idle: scr_mon_state_idle,
                    walk: scr_mon_state_walk,
                    wander: scr_mon_state_wander,
                    h: scr_mon_state_h,
                    patrol: scr_mon_state_patrol
                };
                break;
        }
        
        mon_data.mon_state = _state;
        scr_mon_step = scr_mon_state;
        sprite_index = spr_empty;
        image_xscale = choose(1, -1);
    }
    
    return _mon;
}

function scr_mon_state()
{
    switch (mon_data.mon_state)
    {
        case UnknownEnum.Value_0:
            script_execute(scr_mon.idle);
            break;
        
        case UnknownEnum.Value_6:
            script_execute(scr_mon.walk);
            break;
        
        case UnknownEnum.Value_5:
            script_execute(scr_mon.wander);
            break;
        
        case UnknownEnum.Value_7:
            script_execute(scr_mon.carry_s);
            break;
        
        case UnknownEnum.Value_8:
            script_execute(scr_mon.carry);
            break;
        
        case UnknownEnum.Value_9:
            script_execute(scr_mon.carry_i);
            break;
        
        case UnknownEnum.Value_1:
            script_execute(scr_mon.h);
            break;
        
        case UnknownEnum.Value_10:
            script_execute(scr_mon.patrol);
            break;
    }
    
    if (mon_data.mood_type != -1)
    {
        mon_data.mood_timer -= global.w_spd;
        
        if (mon_data.mood_timer <= 0)
        {
            mon_data.mood_type = -1;
            mon_data.mood_timer = 0;
        }
    }
}

function scr_find_nearest_door(arg0, arg1, arg2)
{
    var _door = -1;
    var _new_dist = -1;
    
    with (obj_slot)
    {
        if (slot_data.slot_type == UnknownEnum.Value_3 && slot_data.slot_floor == arg2)
        {
            var _door_x = x + floor(image_xscale * 0.5);
            var _door_y = y;
            var _dist = point_distance(arg0, arg1, _door_x, _door_y);
            
            if (_new_dist == -1 || _dist < _new_dist)
            {
                _door = id;
                _new_dist = _dist;
            }
        }
    }
    
    return _door;
}

function scr_check_door_allow(arg0, arg1)
{
    var _allow_ar = [true, true, true, true];
    var _exists = false;
    
    with (obj_slot)
    {
        if (slot_data.slot_type == UnknownEnum.Value_3 && slot_data.slot_floor == arg0)
        {
            for (var i = 0; i < (array_length(slot_data.mod_index) - 1); i++)
            {
                if (_allow_ar[i])
                    _allow_ar[i] = slot_data.mod_index[i + 1];
            }
        }
    }
    
    for (var i = 0; i < array_length(arg1); i++)
    {
        if (_allow_ar[arg1[i]])
        {
            array_delete(arg1, i, 1);
            i--;
        }
    }
    
    return arg1;
}

function scr_mon_frame(arg0)
{
    var _num = array_length(h_unit_list);
    
    for (var i = 0; i < _num; i++)
    {
        with (h_unit_list[i])
            mon_data.index = arg0;
    }
}

function scr_mon_contact(arg0, arg1, arg2)
{
    var _slot_type = arg2.slot_id.slot_data.slot_type;
    var _mon_type = arg2.mon_type;
    var _h = false;
    var _slot_width = -1;
    var _carry = false;
    var _set_spr = false;
    mon_data.mood_type = -1;
    mon_data.mood_timer = 0;
    var _id = id;
    var _place = mon_data.placement_num;
    
    switch (_slot_type)
    {
        case UnknownEnum.Value_3:
            global.val.nest_num[_mon_type + 1]--;
            break;
        
        case UnknownEnum.Value_0:
            mon_data.mon_state = UnknownEnum.Value_1;
            mon_data.ff = true;
            var _special = false;
            
            with (mon_data.slot_id)
            {
                if (slot_data.anal != -1)
                {
                    if (unit_data.preg_c < 1 && irandom_range(1, 100) <= global.gnx_anal_chance)
                        slot_data.anal = true;
                    else if (irandom_range(1, 100) <= global.gnx_anal_chance_preg)
                        slot_data.anal = true;
                    else
                        slot_data.anal = false;
                }
                
                slot_data.mon_placement[_place] = _id;
                var _mon_exists = 0;
                
                for (var i = 0; i < slot_data.max_mon_num; i++)
                {
                    if (slot_data.mon_placement[i] != -1)
                        _mon_exists++;
                }
                
                if (_mon_exists >= array_length(h_unit_list))
                    slot_data.load = false;
                
                if (!_special)
                {
                    slot_data.anim_struct.char_state = UnknownEnum.Value_1;
                    slot_data.anim_struct.ff = true;
                }
            }
            
            _slot_width = 45;
            break;
        
        case UnknownEnum.Value_1:
            mon_data.mon_state = UnknownEnum.Value_1;
            mon_data.ff = true;
            var _special = false;
            
            with (mon_data.slot_id)
            {
                slot_data.mon_placement[_place] = _id;
                var _mon_exists = 0;
                
                for (var i = 0; i < slot_data.max_mon_num; i++)
                {
                    if (slot_data.mon_placement[i] != -1)
                        _mon_exists++;
                }
                
                if (_mon_exists >= array_length(h_unit_list))
                    slot_data.load = false;
                
                switch (slot_data.h_type)
                {
                    case UnknownEnum.Value_36:
                        if (slot_data.mon_placement[0] == -1 && other.mon_data.mon_type == UnknownEnum.Value_0)
                        {
                            slot_data.mon_placement[0] = slot_data.mon_placement[1];
                            slot_data.mon_placement[1] = -1;
                            
                            for (var i = 0; i < array_length(h_unit_list); i++)
                            {
                                if (h_unit_list[i].mon_data.placement_num == 0)
                                    h_unit_list[i].mon_data.placement_num = 1;
                            }
                            
                            other.mon_data.placement_num = 0;
                            _place = 0;
                        }
                        
                        if (_place == 0)
                        {
                            _id.visible = false;
                        }
                        else
                        {
                            _special = true;
                            slot_data.h_step++;
                            slot_data.anim_struct.ff = true;
                        }
                        
                        break;
                    
                    case UnknownEnum.Value_17:
                        var _set_move = true;
                        
                        for (var i = 0; i < slot_data.max_mon_num; i++)
                        {
                            if (slot_data.mon_placement[i] == -1)
                                _set_move = false;
                        }
                        
                        if (!_set_move)
                        {
                            for (var i = 0; i < array_length(slot_data.mon_placement); i++)
                            {
                                if (slot_data.mon_placement[i] != -1)
                                {
                                    with (slot_data.mon_placement[i])
                                    {
                                        mon_data.mon_state = UnknownEnum.Value_0;
                                        mon_data.wait = 1000;
                                        mon_data.ff = false;
                                        sprite_index = spr_idle;
                                    }
                                }
                            }
                        }
                        else
                        {
                            slot_data.mon_placement[0].mon_data.mon_state = UnknownEnum.Value_8;
                            slot_data.mon_placement[0].mon_data.ff = true;
                            slot_data.mon_placement[1].mon_data.mon_state = UnknownEnum.Value_9;
                            slot_data.mon_placement[1].mon_data.ff = true;
                        }
                        
                        _carry = true;
                        break;
                    
                    case UnknownEnum.Value_18:
                        if (slot_data.anim_struct.char_state == UnknownEnum.Value_0)
                        {
                            slot_data.anim_struct.char_state = UnknownEnum.Value_1;
                            slot_data.anim_struct.ff = true;
                        }
                        else
                        {
                            _set_spr = true;
                        }
                        
                        _special = true;
                        break;
                    
                    case UnknownEnum.Value_19:
                        for (var i = 0; i < array_length(slot_data.sp_place); i++)
                        {
                            if (slot_data.sp_place[i] == _place)
                                array_delete(slot_data.sp_place, i, 1);
                        }
                        
                        break;
                    
                    case UnknownEnum.Value_38:
                        _id.visible = false;
                        
                        for (var i = 0; i < array_length(slot_data.sp_place); i++)
                        {
                            if (slot_data.sp_place[i] == _place)
                                array_delete(slot_data.sp_place, i, 1);
                        }
                        
                        break;
                    
                    case UnknownEnum.Value_24:
                        var _set_move = false;
                        var _unit_data = unit_data;
                        
                        with (_id)
                        {
                            mon_data.mon_state = UnknownEnum.Value_10;
                            mon_data.ff = true;
                            spr_unit = scr_set_patrol_spr_data(_unit_data);
                            scr_mon_begin_step = scr_ogre_spd_b;
                            sprite_index = spr_patrol;
                        }
                        
                        slot_data.visual = false;
                        _carry = true;
                        break;
                    
                    case UnknownEnum.Value_21:
                        _id.visible = false;
                        break;
                    
                    case UnknownEnum.Value_22:
                        _id.visible = false;
                        break;
                    
                    case UnknownEnum.Value_23:
                        if (_place == 0)
                            _id.visible = false;
                        
                        break;
                }
                
                if (!_special)
                {
                    slot_data.anim_struct.char_state = UnknownEnum.Value_1;
                    slot_data.anim_struct.ff = true;
                }
            }
            
            _slot_width = 77;
            break;
    }
    
    if (_slot_width == -1)
    {
        instance_destroy();
    }
    else if (!_carry)
    {
        var _spr = 
        {
            mon_step: UnknownEnum.Value_0,
            spr_type: -1,
            shift_x: 0,
            shift_y: 0,
            hand_xscale: 1,
            pen_y: 0,
            prop: -1,
            prop_shift_x: floor(_slot_width * 0.5),
            prop_shift_y: 0,
            mon_frame_c: 0,
            base_frame_c: 0,
            start_frame: 0,
            skin_type: -1,
            slot_width: _slot_width
        };
        mon_data.spr_data = _spr;
        var _slot_dirt = ceil(mon_data.slot_id.slot_data.slot_dirt) - 1;
        
        if (_slot_dirt >= 0 && global.dirt_fix <= 0)
        {
            switch (_slot_dirt)
            {
                case 0:
                    mon_data.mood_type = UnknownEnum.Value_2;
                    break;
                
                case 1:
                    mon_data.mood_type = UnknownEnum.Value_1;
                    break;
                
                case 2:
                    mon_data.mood_type = UnknownEnum.Value_0;
                    break;
            }
            
            mon_data.mood_timer = 180;
            scr_mood_value_set(-0.18 * (_slot_dirt + 1));
        }
    }
    
    if (_set_spr)
        scr_set_mon_spr_data(mon_data.slot_id, -1);
}

function scr_mon_num_edit(arg0, arg1, arg2, arg3)
{
    var _num = 0;
    
    if (arg2 > 0)
        global.val.birth_num += arg2;
    
    switch (arg0)
    {
        case UnknownEnum.Value_0:
            if (global.val.goblin.num[arg1] != -1)
                global.val.goblin.num[arg1] = max(0, global.val.goblin.num[arg1] + arg2);
            else
                global.val.goblin.num[arg1] = arg2;
            
            var _ar_num = array_length(global.val.goblin.num);
            
            for (var i = 0; i < _ar_num; i++)
            {
                if (global.val.goblin.num[i] != -1)
                    _num += global.val.goblin.num[i];
            }
            
            break;
        
        case UnknownEnum.Value_1:
            if (global.val.hobgoblin.num[arg1] != -1)
                global.val.hobgoblin.num[arg1] = max(0, global.val.hobgoblin.num[arg1] + arg2);
            else
                global.val.hobgoblin.num[arg1] = 1;
            
            var _ar_num = array_length(global.val.hobgoblin.num);
            
            for (var i = 0; i < _ar_num; i++)
            {
                if (global.val.hobgoblin.num[i] != -1)
                    _num += global.val.hobgoblin.num[i];
            }
            
            break;
        
        case UnknownEnum.Value_2:
            if (global.val.tentacle.num[arg1] != -1)
                global.val.tentacle.num[arg1] = max(0, global.val.tentacle.num[arg1] + arg2);
            else
                global.val.tentacle.num[arg1] = 1;
            
            var _ar_num = array_length(global.val.tentacle.num);
            
            for (var i = 0; i < _ar_num; i++)
            {
                if (global.val.tentacle.num[i] != -1)
                    _num += global.val.tentacle.num[i];
            }
            
            break;
        
        case UnknownEnum.Value_3:
            if (global.val.ogre.num[arg1] != -1)
                global.val.ogre.num[arg1] = max(0, global.val.ogre.num[arg1] + arg2);
            else
                global.val.ogre.num[arg1] = 1;
            
            var _ar_num = array_length(global.val.ogre.num);
            
            for (var i = 0; i < _ar_num; i++)
            {
                if (global.val.ogre.num[i] != -1)
                    _num += global.val.ogre.num[i];
            }
            
            break;
    }
    
    global.val.mon_num[arg0] = _num;
}

function scr_mon_give_milk(arg0, arg1)
{
    var _item_lvl = arg0.image_index;
    var _type = arg1.unit_data.mon_type;
    var _mon_array = scr_mon_type_construct(_type);
    var _skill_lvl = _mon_array.skill_lvl[arg1.unit_data.class];
    
    if (_skill_lvl <= _item_lvl && _skill_lvl < 5)
    {
        var _info = {};
        var _size = ds_list_size(global.inv_list);
        var _max_num;
        
        for (var i = 0; i < _size; i++)
        {
            var _item_data = ds_list_find_value(global.inv_list, i);
            
            if (_item_data.item_type == UnknownEnum.Value_4 && _item_data.index == _item_lvl)
            {
                _max_num = _item_data.num;
                i = _size;
            }
        }
        
        _info.max_num = _max_num;
        _info.milk_lvl = _item_lvl;
        _info.sell = false;
        _info.save_num = -1;
        num_window = scr_create_window_num_sel(arg1.x, arg1.y, arg1, arg1.depth - 10, true, _info, -1, scr_milk_num_enter, -1);
    }
    else
    {
        with (arg1)
        {
            fail_shake = true;
            fail_ori_x = shift_x;
        }
    }
}

function scr_ogre_spd_b()
{
    var _list = ds_list_create();
    var _num = instance_place_list(x, y, obj_mon, _list, false);
    
    for (var i = 0; i < _num; i++)
    {
        var _mon = ds_list_find_value(_list, i);
        
        with (_mon)
        {
            spd_b = 0.75;
            
            if (mon_data.mon_type == UnknownEnum.Value_1 && mon_data.task == UnknownEnum.Value_3 && mon_data.placement_num == 0 && mon_data.carry_start_id == -1 && mon_data.carry_end_id == -1 && mon_data.slot_id.slot_data.slot_type != UnknownEnum.Value_3 && mon_data.slot_id.unit_data == -1)
            {
                with (mon_data.slot_id)
                {
                    var _carry = scr_check_carry_slot_range(slot_range);
                    
                    if (_carry != -1)
                    {
                        var _c_slot_id = _carry[0];
                        var _t_slot_id = _carry[1];
                        
                        if (_c_slot_id != id)
                        {
                            with (_c_slot_id)
                            {
                                slot_data.load = true;
                                slot_data.carry = true;
                                scr_create_slot_head(false, id);
                            }
                        }
                        
                        with (_t_slot_id)
                        {
                            slot_data.load = true;
                            slot_data.carry = true;
                            scr_create_slot_head(false, id);
                        }
                        
                        slot_data.anim_struct.char_state = UnknownEnum.Value_1;
                        slot_data.anim_struct.ff = true;
                        
                        with (other)
                        {
                            mon_data.carry_start_id = _c_slot_id;
                            mon_data.carry_end_id = _t_slot_id;
                        }
                    }
                }
            }
        }
    }
    
    ds_list_destroy(_list);
}

enum UnknownEnum
{
    Value_0,
    Value_1,
    Value_2,
    Value_3,
    Value_4,
    Value_5,
    Value_6,
    Value_7,
    Value_8,
    Value_9,
    Value_10,
    Value_17 = 17,
    Value_18,
    Value_19,
    Value_21 = 21,
    Value_22,
    Value_23,
    Value_24,
    Value_36 = 36,
    Value_38 = 38
}
