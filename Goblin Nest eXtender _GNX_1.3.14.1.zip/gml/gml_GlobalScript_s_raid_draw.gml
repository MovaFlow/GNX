function scr_draw_raid()
{
    if (activate)
    {
        scr_draw_backdrop();
        draw_sprite(spr_raid_bg, 0, 4, 36);
        scr_draw_group_window(0);
        draw_set_halign(fa_center);
        var _lang_pos = scr_change_lang();
        
        switch (global.val.language)
        {
            case 0:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "INVENTORY");
                draw_text(30 + _lang_pos[0], 47 + _lang_pos[1], "NEST");
                draw_text(390 + _lang_pos[0], 43 + _lang_pos[1], "FORMATION");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "MAX");
                draw_text(343 + _lang_pos[0], 165 + _lang_pos[1], "STORAGE");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "CAGE");
                break;
            
            case 9:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "背包");
                draw_text(31 + _lang_pos[0], 47 + _lang_pos[1], "巢穴");
                draw_text(391 + _lang_pos[0], 43 + _lang_pos[1], "編隊");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "最大");
                draw_text(342 + _lang_pos[0], 165 + _lang_pos[1], "倉庫");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "籠子");
                break;
            
            case 2:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "背包");
                draw_text(31 + _lang_pos[0], 47 + _lang_pos[1], "巢穴");
                draw_text(391 + _lang_pos[0], 43 + _lang_pos[1], "编队");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "最大");
                draw_text(342 + _lang_pos[0], 165 + _lang_pos[1], "仓库");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "笼子");
                break;
            
            case 1:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "持ち物");
                draw_text(31 + _lang_pos[0], 47 + _lang_pos[1], "巣");
                draw_text(391 + _lang_pos[0], 43 + _lang_pos[1], "陣形");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "最大");
                draw_text(343 + _lang_pos[0], 165 + _lang_pos[1], "保管庫");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "檻");
                break;
            
            case 3:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "소지품");
                draw_text(31 + _lang_pos[0], 47 + _lang_pos[1], "둥지");
                draw_text(391 + _lang_pos[0], 43 + _lang_pos[1], "대형");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "최대");
                draw_text(343 + _lang_pos[0], 165 + _lang_pos[1], "창고");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "우리");
                break;
            
            case 7:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "ИНВЕНТАРЬ");
                draw_text(31 + _lang_pos[0], 47 + _lang_pos[1], "ГНЕЗД");
                draw_text(390 + _lang_pos[0], 43 + _lang_pos[1], "СТРОЙ");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "МАКС");
                draw_text(343 + _lang_pos[0], 165 + _lang_pos[1], "СКЛАД");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "КЛЕТКА");
                break;
            
            case 4:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "INVENTARIO");
                draw_text(30 + _lang_pos[0], 47 + _lang_pos[1], "NIDO");
                draw_text(390 + _lang_pos[0], 43 + _lang_pos[1], "FORMACIÓN");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "MÁX");
                draw_text(343 + _lang_pos[0], 165 + _lang_pos[1], "DEPÓSITO");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "JAULA");
                break;
            
            case 6:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "INVENTAIRE");
                draw_text(31 + _lang_pos[0], 47 + _lang_pos[1], "NID");
                draw_text(390 + _lang_pos[0], 43 + _lang_pos[1], "FORMATION");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "MAX");
                draw_text(343 + _lang_pos[0], 165 + _lang_pos[1], "STOCKAGE");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "CAGE");
                break;
            
            case 8:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "INVENTAR");
                draw_text(31 + _lang_pos[0], 47 + _lang_pos[1], "NEST");
                draw_text(390 + _lang_pos[0], 43 + _lang_pos[1], "FORMATION");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "MAX");
                draw_text(343 + _lang_pos[0], 165 + _lang_pos[1], "LAGER");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "KÄFIG");
                break;
            
            case 5:
                draw_text(41 + _lang_pos[0], 158 + _lang_pos[1], "INVENTÁRIO");
                draw_text(31 + _lang_pos[0], 47 + _lang_pos[1], "NINHO");
                draw_text(390 + _lang_pos[0], 43 + _lang_pos[1], "FORMAÇÃO");
                draw_text(439 + _lang_pos[0], 43 + _lang_pos[1], "MÁX");
                draw_text(342 + _lang_pos[0], 165 + _lang_pos[1], "ARMAZÉM");
                draw_text(424 + _lang_pos[0], 165 + _lang_pos[1], "JAULA");
                break;
        }
        
        draw_set_font(fnt_base_font_eng);
        // GNX: custom map sprite when on mod map, vanilla otherwise
        if (global.gnx_multimap_enabled && global.gnx_map_sprite != -1 && sprite_exists(global.gnx_map_sprite))
            draw_sprite(global.gnx_map_sprite, 0, 173, 39);
        else
            draw_sprite(spr_map, 0, 173, 39);
        var _black = false;
        
        // GNX: draw travel buttons in GUI space (state 0 only)
        if (raid_data.raid_state == 0)
            scr_gnx_draw_travel_buttons_gui();

        switch (raid_data.raid_state)
        {
            case 0:
                scr_draw_stage_info();
                break;
            
            case 1:
                scr_draw_stage_info();
                scr_draw_stage_icon();
                _black = true;
                break;
            
            case 2:
                scr_draw_stage_info();
                scr_draw_stage_icon();
                _black = true;
                break;
            
            case 3:
                scr_draw_raid_trade();
                break;
            
            case 4:
                scr_draw_raid_shop();
                break;
        }
        
        scr_draw_inventory();
        scr_draw_raid_inventory();
        var _num = array_length(global.val.cage);
        
        for (var i = 0; i < _num; i++)
            draw_sprite(spr_cage_frame, 0, 374 + (24 * i), 172);
        
        draw_set_halign(fa_right);
        
        if (global.max_troop[global.val.troop_size] == -1)
            draw_sprite(spr_infinity, 0, 449, 45);
        else
            draw_text(459, 43, string(global.max_troop[global.val.troop_size]));
        
        scr_draw_group_boxline();
        scr_draw_milk_boxline();
    }
}

function scr_draw_group_window(arg0)
{
    var _md = scr_calculate_mood_rate();
    _md.mood = min(_md.mood, 3);
    var _text_c = global.mood_c[_md.mood];
    var _row_text;
    
    switch (global.val.language)
    {
        case 0:
            _row_text = ["FRONT", "BACK"];
            break;
        
        case 9:
            _row_text = ["前列", "後列"];
            break;
        
        case 2:
            _row_text = ["前列", "后列"];
            break;
        
        case 1:
            _row_text = ["前列", "後列"];
            break;
        
        case 3:
            _row_text = ["전열", "후열"];
            break;
        
        case 7:
            _row_text = ["ФРОНТ", "ТЫЛ"];
            break;
        
        case 4:
            _row_text = ["FRENTE", "DETRÁS"];
            break;
        
        case 6:
            _row_text = ["AVANT", "FOND"];
            break;
        
        case 8:
            _row_text = ["VORNE", "HINTEN"];
            break;
        
        case 5:
            _row_text = ["FRENTE", "DEFESA"];
            break;
    }
    
    var _row_y = [64, 119];
    var _icon_y = 0;
    
    if (global.val.language == 9 || global.val.language == 2 || global.val.language == 1 || global.val.language == 3)
        _icon_y = 1;
    
    var _line_c = line_c;
    var _x = 348;
    
    for (var i = 0; i < 2; i++)
    {
        var _y = _row_y[i] - 15;
        draw_set_halign(fa_center);
        var _lang_pos = scr_change_lang();
        draw_set_color(c_white);
        draw_text((_x - 19) + _lang_pos[0], _y + 12 + _lang_pos[1], _row_text[i]);
        draw_sprite(spr_raid_stat_icon, i, _x - 22, _y + 21 + _icon_y);
        draw_set_font(fnt_base_font_eng);
        draw_set_color(_text_c);
        var _a;
        
        if (raid_data.raid_state == 1)
            _a = max(sign(raid_data.ap[i]), floor(raid_data.ap[i]));
        else
            _a = max(sign(raid_data.ap[i]), floor(raid_data.ap[i] * _md.md_rate));
        
        draw_text(_x - 19, _y + 40, _a);
    }
    
    draw_set_color(c_white);
}

function scr_draw_stage_info()
{
    draw_set_halign(fa_left);
    draw_sprite(spr_raid_stage_info, 0, 169, 130);
    var _lang_pos = scr_change_lang();
    
    switch (global.val.language)
    {
        case 0:
            draw_text(183 + _lang_pos[0], 134 + _lang_pos[1], "FRONT");
            draw_text(185 + _lang_pos[0], 145 + _lang_pos[1], "BACK");
            draw_text(182 + _lang_pos[0], 156 + _lang_pos[1], "CAPTURE");
            draw_text(279 + _lang_pos[0], 156 + _lang_pos[1], "REWARD");
            draw_text(283 + _lang_pos[0], 203 + _lang_pos[1], "TIME");
            break;
        
        case 9:
            draw_text(183 + _lang_pos[0], 133 + _lang_pos[1], "前列 ");
            draw_text(183 + _lang_pos[0], 144 + _lang_pos[1], "後列");
            draw_text(183 + _lang_pos[0], 155 + _lang_pos[1], "捕獲");
            draw_text(282 + _lang_pos[0], 155 + _lang_pos[1], "獎勵");
            draw_text(282 + _lang_pos[0], 202 + _lang_pos[1], "時間");
            break;
        
        case 2:
            draw_text(183 + _lang_pos[0], 133 + _lang_pos[1], "前列 ");
            draw_text(183 + _lang_pos[0], 144 + _lang_pos[1], "后列");
            draw_text(183 + _lang_pos[0], 155 + _lang_pos[1], "捕获");
            draw_text(282 + _lang_pos[0], 155 + _lang_pos[1], "奖励");
            draw_text(282 + _lang_pos[0], 202 + _lang_pos[1], "时间");
            break;
        
        case 1:
            draw_text(183 + _lang_pos[0], 133 + _lang_pos[1], "前列");
            draw_text(183 + _lang_pos[0], 144 + _lang_pos[1], "後列");
            draw_text(183 + _lang_pos[0], 155 + _lang_pos[1], "捕獲");
            draw_text(282 + _lang_pos[0], 155 + _lang_pos[1], "報酬");
            draw_text(282 + _lang_pos[0], 202 + _lang_pos[1], "時間");
            break;
        
        case 3:
            draw_text(183 + _lang_pos[0], 133 + _lang_pos[1], "전열 ");
            draw_text(183 + _lang_pos[0], 144 + _lang_pos[1], "후열");
            draw_text(183 + _lang_pos[0], 155 + _lang_pos[1], "생포");
            draw_text(282 + _lang_pos[0], 155 + _lang_pos[1], "보상");
            draw_text(282 + _lang_pos[0], 202 + _lang_pos[1], "시간");
            break;
        
        case 7:
            draw_text(182 + _lang_pos[0], 134 + _lang_pos[1], "ФРОНТ");
            draw_text(185 + _lang_pos[0], 145 + _lang_pos[1], "ТЫЛ");
            draw_text(182 + _lang_pos[0], 156 + _lang_pos[1], "ЗАХВАТ");
            draw_text(280 + _lang_pos[0], 156 + _lang_pos[1], "ПЛАТА");
            draw_text(281 + _lang_pos[0], 203 + _lang_pos[1], "ВРЕМЯ");
            break;
        
        case 4:
            draw_text(181 + _lang_pos[0], 134 + _lang_pos[1], "FRENTE");
            draw_text(181 + _lang_pos[0], 145 + _lang_pos[1], "DETRÁS");
            draw_text(181 + _lang_pos[0], 156 + _lang_pos[1], "CAPTURA");
            draw_text(279 + _lang_pos[0], 156 + _lang_pos[1], "RECOMP");
            draw_text(279 + _lang_pos[0], 203 + _lang_pos[1], "TIEMPO");
            break;
        
        case 6:
            draw_text(183 + _lang_pos[0], 134 + _lang_pos[1], "AVANT");
            draw_text(185 + _lang_pos[0], 145 + _lang_pos[1], "FOND");
            draw_text(182 + _lang_pos[0], 156 + _lang_pos[1], "CAPTURE");
            draw_text(279 + _lang_pos[0], 156 + _lang_pos[1], "RÉCOMP");
            draw_text(280 + _lang_pos[0], 203 + _lang_pos[1], "TEMPS");
            break;
        
        case 8:
            draw_text(183 + _lang_pos[0], 134 + _lang_pos[1], "VORNE");
            draw_text(181 + _lang_pos[0], 145 + _lang_pos[1], "HINTEN");
            draw_text(181 + _lang_pos[0], 156 + _lang_pos[1], "EINFANGEN");
            draw_text(281 + _lang_pos[0], 156 + _lang_pos[1], "PREIS");
            draw_text(283 + _lang_pos[0], 203 + _lang_pos[1], "ZEIT");
            break;
        
        case 5:
            draw_text(181 + _lang_pos[0], 134 + _lang_pos[1], "FRENTE");
            draw_text(181 + _lang_pos[0], 145 + _lang_pos[1], "DEFESA");
            draw_text(181 + _lang_pos[0], 156 + _lang_pos[1], "CAPTURAR");
            draw_text(279 + _lang_pos[0], 156 + _lang_pos[1], "RECOMP");
            draw_text(280 + _lang_pos[0], 203 + _lang_pos[1], "TEMPO");
            break;
    }
    
    draw_set_font(fnt_base_font_eng);
    
    for (var i = 0; i < 2; i++)
        draw_sprite(spr_raid_stat_icon, i, 174, 135 + (11 * i));
    
    if (raid_data.stage != -1)
    {
        var _stage_lvl = min(2, global.val.stage_lvl_sel[raid_data.stage]);
        var _data = global.val.stage_info[raid_data.stage].info[_stage_lvl];
        var _player_hp, _player_ap;
        
        if (raid_data.raid_state != 1)
        {
            var _md = scr_calculate_mood_rate();
            _player_hp = floor(obj_np.obj_raid.raid_data.ap[0] * _md.md_rate);
            _player_ap = floor(obj_np.obj_raid.raid_data.ap[1] * _md.md_rate);
        }
        else
        {
            _player_hp = floor(obj_np.obj_raid.raid_data.ap[0]);
            _player_ap = floor(obj_np.obj_raid.raid_data.ap[1]);
        }
        
        var _enemy_hp = _data.en_ap[0];
        var _enemy_ap = _data.en_ap[1];
        draw_set_halign(fa_center);
        var _x = 234;
        var _y = 134;
        
        for (var i = 0; i < 2; i++)
            draw_text(_x, _y + (11 * i), string(_data.en_ap[i]));
        
        var _time_need = round((global.base_raid_time[raid_data.stage] * 2) / (global.val.cart_spd * raid_data.haste));
        var _time = time_convert(_time_need);
        draw_text(292, 214, string(_time[0]) + "H." + string(_time[1]) + "M");
        
        if (_player_hp >= _enemy_hp)
            draw_sprite(spr_tick, 0, 270, 137);
        
        if (_player_ap >= _enemy_ap)
            draw_sprite(spr_tick, 0, 270, 148);
        
        _x = 182;
        _y = 178;
        var _unit_list = _data.unit_list;
        var _num = array_length(_unit_list);
        
        for (var i = 0; i < _num; i++)
            scr_draw_stage_unit_head(_x + (20 * i), _y, _unit_list[i], true);
        
        _x = 183;
        _y = 209;
        var _item_list = _data.item;
        _num = array_length(_item_list);
        var _width = 20;
        
        for (var i = 0; i < _num; i++)
            scr_draw_item(_x + (i * _width), _y, _item_list[i], true);
        
        var _item_data = {};
        _x = 291;
        
        if (array_length(global.reward[raid_data.stage][_stage_lvl]) > 0)
        {
            _item_data = global.reward[raid_data.stage][_stage_lvl][0];
            scr_draw_item(_x, 171, _item_data, true);
            _item_data = global.reward[raid_data.stage][_stage_lvl][1];
            scr_draw_item(_x, 188, _item_data, true);
        }
        
        _stage_lvl = min(global.val.stage_lvl_sel[raid_data.stage], 2);
        _num = 0;
        var _dnum = 0;
        var _a = 0;
        var _cap_mul = 0;
        var _rev_mul = 0;
        var _dd = false;
        
        if (_player_hp >= _enemy_hp && _player_ap >= _enemy_ap)
        {
            _cap_mul = scr_check_skill_data(5);
            _rev_mul = scr_check_skill_data(1);
            var _over_diff = (_player_hp + _player_ap) / (_enemy_hp + _enemy_ap);
            var _list_num = array_length(_data.unit_list);
            var _max_lvl = 0;
            
            for (var i = 0; i < _list_num; i++)
            {
                if (_data.unit_list[i].lvl > _max_lvl)
                {
                    if (_data.unit_list[i].class == 8)
                        _max_lvl = 8;
                    else
                        _max_lvl = _data.unit_list[i].lvl;
                }
                
                if (global.unlock.boss[3] == 0 && _data.unit_list[i].class == 12)
                    _dd = true;
            }
            
            if (raid_data.stage == 4 && _stage_lvl == 1)
                _dd = true;
            
            _num = ((_over_diff - 1) / (1 + (_max_lvl * 0.3))) * 100;
            _num = clamp(floor(_num + (_cap_mul * 100)), 0, 140);
            _dnum = (1 - clamp(((_over_diff - 1) * 0.8) + 0.1, 0.1, 0.9)) * 100;
            _dnum = max(0, round(_dnum - (_dnum * min(1, _rev_mul)))) + floor(_dd * (_dnum * 0.5));
        }
        
        draw_set_halign(fa_right);
        
        if (_cap_mul > 0)
            draw_set_color(c_lime);
        else
            draw_set_color(c_white);
        
        draw_text(236, 156, string(_num));
        
        if (_dd)
        {
            if (_rev_mul > 0)
                draw_set_color(c_orange);
            else
                draw_set_color(c_red);
        }
        else if (_rev_mul > 0)
        {
            draw_set_color(c_lime);
        }
        else
        {
            draw_set_color(c_white);
        }
        
        draw_text(268, 156, string(_dnum));
        draw_set_color(c_white);
        draw_text(241, 156, "%");
        draw_text(273, 156, "%");
        
        if (raid_data.raid_state == 0)
        {
            _x = 285;
            _y = 129;
            _num = array_length(global.val.stage_item[raid_data.stage][_stage_lvl]);
            draw_set_halign(fa_left);
            draw_sprite(spr_chest, 0, _x, _y);
            draw_sprite(spr_x, 0, _x + 9, _y + 1);
            draw_text(_x + 13, _y - 3, string(_num));
        }
    }
}

function scr_draw_stage_icon()
{
    draw_sprite(spr_button_stage, 0, 240, 92);
    
    if (global.val.stage_info[1] != -1)
        draw_sprite(spr_button_stage, 1, 188, 108);
    
    if (global.val.stage_info[2] != -1)
        draw_sprite(spr_button_stage, 2, 266, 50);
    
    if (global.val.stage_info[3] != -1)
        draw_sprite(spr_button_stage, 3, 272, 103);
    
    if (global.val.stage_info[4] != -1)
        draw_sprite(spr_button_stage, 4, 294, 80);
    
    draw_sprite(spr_raid_shop_button, 0, 233, 50);
    draw_sprite(spr_raid_trade_button, 0, 223, 76);
    
    if (instance_exists(obj_carriage))
        draw_sprite(spr_carriage, image_index, obj_carriage.x, obj_carriage.y);
}

