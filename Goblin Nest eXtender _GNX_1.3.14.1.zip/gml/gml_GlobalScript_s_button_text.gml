// GNX: patched s_button_text.gml
// Rebased onto vanilla 1.38 base.
// - cell_registry lookup in scr_h_slot_text_data for modded cells
// - UnknownEnum -> numeric literals

function scr_h_slot_text_data(arg0)
{
    var _button_text = -1;
    var _price = -1;
    var _spawn_info = -1;
    var _code_text = -1;
    var _shop_price = -1;
    
    if (ds_map_exists(global.cell_registry, arg0))
    {
        var _gnx_cell = ds_map_find_value(global.cell_registry, arg0);
        _button_text = _gnx_cell.name;

        if (variable_struct_exists(_gnx_cell, "gnx_price"))
        {
            _price = _gnx_cell.gnx_price;
            _spawn_info = _gnx_cell.gnx_spawn_info;
        }

        // GNX cells: set blueprint display fields from registry
        if (variable_struct_exists(_gnx_cell, "gnx_code_text"))
            _code_text = _gnx_cell.gnx_code_text;
        if (_price != -1)
            _shop_price = _price;
    }
    
    switch (arg0)
    {
        case 1:
            _button_text = "WALL 1";
            _code_text = "A";
            _price = 50;
            _spawn_info = 
            {
                coin: 1,
                mood: 1,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 2:
            _button_text = "WALL 2";
            _code_text = "A";
            _price = 50;
            _spawn_info = 
            {
                coin: 1,
                mood: 1,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 7:
            _button_text = "WALL 3";
            _code_text = "B";
            _price = 100;
            _shop_price = 120;
            _spawn_info = 
            {
                coin: 0.5,
                mood: 2,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 8:
            _button_text = "WALL 4";
            _code_text = "C";
            _price = 150;
            _shop_price = 180;
            _spawn_info = 
            {
                coin: 2,
                mood: 0.5,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 9:
            _button_text = "M.PRESS 1";
            _code_text = "D";
            _price = 280;
            _spawn_info = 
            {
                coin: 2,
                mood: 1,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 13:
            _button_text = "PRONE";
            _code_text = "E";
            _price = 320;
            _shop_price = 250;
            _spawn_info = 
            {
                coin: 2,
                mood: 2,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 14:
            _button_text = "RIDE 1";
            _code_text = "F";
            _price = 350;
            _shop_price = 320;
            _spawn_info = 
            {
                coin: 1,
                mood: 1,
                coin_mul: false,
                mood_mul: true
            };
            break;
        
        case 5:
            _button_text = "BIRTH 1";
            _code_text = "G";
            _price = 30;
            break;
        
        case 12:
            _button_text = "BIRTH 2";
            _code_text = "G";
            _price = 350;
            break;
        
        case 4:
            _button_text = "MILK 1";
            _code_text = "H";
            _price = 40;
            break;
        
        case 10:
            _button_text = "DISPLAY";
            _code_text = "H";
            _price = 150;
            _shop_price = 120;
            _spawn_info = 
            {
                coin: 0,
                mood: 0.5,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 11:
            _button_text = "DRINK";
            _code_text = "I";
            _price = 320;
            _spawn_info = 
            {
                coin: 0,
                mood: 1,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 6:
            _button_text = "ORAL";
            _code_text = "J";
            _price = 220;
            _shop_price = 200;
            _spawn_info = 
            {
                coin: 2,
                mood: 2,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 3:
            _button_text = "TITFUCK";
            _code_text = "K";
            _price = 200;
            _spawn_info = 
            {
                coin: 1,
                mood: 1,
                coin_mul: false,
                mood_mul: true
            };
            break;
        
        case 15:
            _button_text = "FOREPLAY";
            _code_text = "L";
            _price = 300;
            _shop_price = 280;
            _spawn_info = 
            {
                coin: 1,
                mood: 2,
                coin_mul: true,
                mood_mul: false
            };
            break;
        
        case 31:
            _button_text = "T.WALL 1";
            _code_text = "A";
            _price = 300;
            _spawn_info = 
            {
                coin: 0,
                mood: 2,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 32:
            _button_text = "T.WALL 2";
            _code_text = "A";
            _price = 300;
            _spawn_info = 
            {
                coin: 0,
                mood: 2,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 29:
            _button_text = "T.WALL 3";
            _code_text = "B";
            _price = 350;
            _shop_price = 320;
            _spawn_info = 
            {
                coin: 0,
                mood: 0.5,
                coin_mul: false,
                mood_mul: true
            };
            break;
        
        case 27:
            _button_text = "BIND 1";
            _code_text = "C";
            _price = 380;
            _spawn_info = 
            {
                coin: 0,
                mood: 1,
                coin_mul: false,
                mood_mul: true
            };
            break;
        
        case 28:
            _button_text = "BIND 2";
            _code_text = "D";
            _price = 380;
            _spawn_info = 
            {
                coin: 0,
                mood: 1,
                coin_mul: false,
                mood_mul: true
            };
            break;
        
        case 34:
            _button_text = "CLEAN";
            _code_text = "E";
            _price = 250;
            break;
        
        case 33:
            _button_text = "RECOVER";
            _code_text = "G";
            _price = 450;
            _shop_price = 340;
            break;
        
        case 30:
            _button_text = "MILK 2";
            _code_text = "H";
            _price = 400;
            _shop_price = 520;
            break;
        
        case 19:
            _button_text = "G.BANG 1";
            _price = 350;
            _code_text = "A";
            _shop_price = 240;
            _spawn_info = 
            {
                coin: 1,
                mood: 1,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 18:
            _button_text = "G.BANG 2";
            _price = 450;
            _code_text = "B";
            _shop_price = 450;
            _spawn_info = 
            {
                coin: 2,
                mood: 2,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 20:
            _button_text = "M.PRESS 2";
            _price = 580;
            _code_text = "C";
            _spawn_info = 
            {
                coin: 1,
                mood: 2,
                coin_mul: true,
                mood_mul: false
            };
            break;
        
        case 21:
            _button_text = "BEHIND";
            _price = 620;
            _code_text = "D";
            _shop_price = 450;
            _spawn_info = 
            {
                coin: 3,
                mood: 1,
                coin_mul: false,
                mood_mul: true
            };
            break;
        
        case 22:
            _button_text = "RIDE 2";
            _price = 650;
            _code_text = "E";
            _spawn_info = 
            {
                coin: 1,
                mood: 1,
                coin_mul: true,
                mood_mul: true
            };
            break;
        
        case 23:
            _button_text = "G.BANG 3";
            _price = 650;
            _code_text = "F";
            _shop_price = 450;
            _spawn_info = 
            {
                coin: 1,
                mood: 2,
                coin_mul: true,
                mood_mul: false
            };
            break;
        
        case 17:
            _button_text = "TRANSFER";
            _price = 350;
            _code_text = "G";
            break;
        
        case 24:
            _button_text = "PATROL";
            _price = 1000;
            _code_text = "H";
            break;
        
        case 25:
            _button_text = "CLONE";
            _price = 4000;
            _code_text = "I";
            break;
        
        case 36:
            _button_text = "DAIRY";
            _price = 400;
            _code_text = "A";
            _shop_price = 350;
            _spawn_info = 
            {
                coin: 2,
                mood: 3,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 37:
            _button_text = "GIANT";
            _price = 800;
            _code_text = "B";
            _shop_price = 550;
            _spawn_info = 
            {
                coin: 3,
                mood: 2,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 38:
            _button_text = "CHAINS";
            _price = 1000;
            _code_text = "C";
            _shop_price = 500;
            _spawn_info = 
            {
                coin: 3,
                mood: 3,
                coin_mul: false,
                mood_mul: false
            };
            break;
        
        case 42:
            _button_text = "R.SHRINE";
            _price = 700;
            _code_text = "R";
            break;
        
        case 41:
            _button_text = "F.SHRINE";
            _price = 1000;
            _code_text = "F";
            _shop_price = 600;
            break;
        
        case 40:
            _button_text = "S.SHRINE";
            _price = 2000;
            _code_text = "S";
            break;
        
        case 39:
            _button_text = "L.SHRINE";
            _price = 4000;
            _code_text = "L";
            _shop_price = 666;
            _spawn_info = 
            {
                coin: 3,
                mood: 3,
                coin_mul: true,
                mood_mul: true
            };
            break;
    }
    
    var _data = {};
    _data.text_type = _button_text;
    _data.code_text = _code_text;
    _data.price = _price;
    _data.shop_price = _shop_price;
    _data.spawn_info = _spawn_info;
    return _data;
}

function scr_slot_type_price_data(arg0)
{
    var _data = {};
    
    switch (arg0)
    {
        case 0:
            _data.button_text = "CELL";
            _data.price = 100;
            break;
        
        case 1:
            _data.button_text = "BIG CELL";
            _data.price = 300;
            break;
        
        case 2:
            _data.button_text = "TENTACLE";
            _data.price = 150;
            break;
        
        case 3:
            _data.button_text = "ENTRANCE";
            _data.price = 60;
            break;
    }
    
    if (global.val.language != 0)
        _data.button_text = scr_lang_slot_text_2(arg0);
    
    return _data;
}

function scr_slot_get_coin_data(arg0, arg1)
{
    var _data = scr_h_slot_text_data(arg0);
    var _c_mul = _data.spawn_info.coin_mul;
    var _m_mul = _data.spawn_info.mood_mul;
    var _c_num = 1 + (_data.spawn_info.coin * 2);
    var _m_num = _data.spawn_info.mood * 0.5;
    _c_num += (_c_num * min(5, arg1.lvl) * _c_mul);
    _m_num += (_m_num * min(5, arg1.lvl) * _m_mul);
    
    if (_c_num != 0)
    {
        var _md = scr_calculate_mood_rate();
        _c_num = floor(_c_num * max(1, _md.md_rate));
        global.val.money += _c_num;
        scr_check_steam_achievement(4);
        var _x = x + (image_xscale * 0.5);
        var _y = y - 50;
        scr_icon_pop_up_create(_x, _y, _c_num, 2, false);
        scr_play_get_coin_sfx(_x, _y);
    }
    
    if (_m_num != 0)
        scr_mood_value_set(_m_num * 0.5);
}

function scr_create_between_button()
{
    scr_create_button_slot(interact_type, button_num);
    
    switch (global.val.language)
    {
        case 0:
            switch (button_num)
            {
                case 0:
                    button_text = "NEW";
                    break;
                
                case 1:
                    button_text = "EDIT";
                    break;
                
                case 2:
                    button_text = "UP";
                    break;
                
                case 3:
                    button_text = "DOWN";
                    break;
            }
            
            break;
        
        case 9:
            switch (button_num)
            {
                case 0:
                    button_text = "新建";
                    break;
                
                case 1:
                    button_text = "編輯";
                    break;
                
                case 2:
                    button_text = "上移";
                    break;
                
                case 3:
                    button_text = "下移";
                    break;
            }
            
            break;
        
        case 2:
            switch (button_num)
            {
                case 0:
                    button_text = "新建";
                    break;
                
                case 1:
                    button_text = "编辑";
                    break;
                
                case 2:
                    button_text = "上移";
                    break;
                
                case 3:
                    button_text = "下移";
                    break;
            }
            
            break;
        
        case 1:
            switch (button_num)
            {
                case 0:
                    button_text = "新規";
                    break;
                
                case 1:
                    button_text = "編集";
                    break;
                
                case 2:
                    button_text = "上へ";
                    break;
                
                case 3:
                    button_text = "下へ";
                    break;
            }
            
            break;
        
        case 3:
            switch (button_num)
            {
                case 0:
                    button_text = "신규";
                    break;
                
                case 1:
                    button_text = "편집";
                    break;
                
                case 2:
                    button_text = "위";
                    break;
                
                case 3:
                    button_text = "아래";
                    break;
            }
            
            break;
        
        case 7:
            switch (button_num)
            {
                case 0:
                    button_text = "НОВОЕ";
                    break;
                
                case 1:
                    button_text = "РЕДАКТ.";
                    break;
                
                case 2:
                    button_text = "ВВЕРХ";
                    break;
                
                case 3:
                    button_text = "ВНИЗ";
                    break;
            }
            
            break;
        
        case 4:
            switch (button_num)
            {
                case 0:
                    button_text = "NUEVO";
                    break;
                
                case 1:
                    button_text = "EDITAR";
                    break;
                
                case 2:
                    button_text = "SUBIR";
                    break;
                
                case 3:
                    button_text = "BAJAR";
                    break;
            }
            
            break;
        
        case 6:
            switch (button_num)
            {
                case 0:
                    button_text = "NOUVEAU";
                    break;
                
                case 1:
                    button_text = "ÉDITER";
                    break;
                
                case 2:
                    button_text = "EN HAUT";
                    break;
                
                case 3:
                    button_text = "EN BAS";
                    break;
            }
            
            break;
        
        case 8:
            switch (button_num)
            {
                case 0:
                    button_text = "NEU";
                    break;
                
                case 1:
                    button_text = "BEARBEITEN";
                    break;
                
                case 2:
                    button_text = "HOCH";
                    break;
                
                case 3:
                    button_text = "RUNTER";
                    break;
            }
            
            break;
        
        case 5:
            switch (button_num)
            {
                case 0:
                    button_text = "NOVO";
                    break;
                
                case 1:
                    button_text = "EDITAR";
                    break;
                
                case 2:
                    button_text = "CIMA";
                    break;
                
                case 3:
                    button_text = "BAIXO";
                    break;
            }
            
            break;
    }
    
    if (button_num == 0 && global.slot_x[source_id.source_id.slot_data.slot_floor] >= (room_width - 77))
        instance_destroy();
    
    if (button_num == 2 && source_id.source_id.slot_data.slot_floor == 0)
        instance_destroy();
    
    if (button_num == 3 && source_id.source_id.slot_data.slot_floor == global.val.floor)
        instance_destroy();
}

function scr_create_modify_button()
{
    scr_create_button_slot(interact_type, button_num);
    
    switch (global.val.language)
    {
        case 0:
            switch (button_num)
            {
                case 0:
                    button_text = "STYLE";
                    break;
                
                case 1:
                    button_text = "TOP";
                    break;
                
                case 2:
                    button_text = "MIDDLE";
                    break;
                
                case 3:
                    button_text = "BOTTOM";
                    break;
                
                case 4:
                    button_text = "RESET";
                    break;
            }
            
            break;
        
        case 9:
            switch (button_num)
            {
                case 0:
                    button_text = "風格";
                    break;
                
                case 1:
                    button_text = "頂部";
                    break;
                
                case 2:
                    button_text = "中間";
                    break;
                
                case 3:
                    button_text = "底部";
                    break;
                
                case 4:
                    button_text = "重置";
                    break;
            }
            
            break;
        
        case 2:
            switch (button_num)
            {
                case 0:
                    button_text = "风格";
                    break;
                
                case 1:
                    button_text = "顶部";
                    break;
                
                case 2:
                    button_text = "中间";
                    break;
                
                case 3:
                    button_text = "底部";
                    break;
                
                case 4:
                    button_text = "重置";
                    break;
            }
            
            break;
        
        case 1:
            switch (button_num)
            {
                case 0:
                    button_text = "形式";
                    break;
                
                case 1:
                    button_text = "上";
                    break;
                
                case 2:
                    button_text = "中";
                    break;
                
                case 3:
                    button_text = "下";
                    break;
                
                case 4:
                    button_text = "初期";
                    break;
            }
            
            break;
        
        case 3:
            switch (button_num)
            {
                case 0:
                    button_text = "스타일";
                    break;
                
                case 1:
                    button_text = "상단";
                    break;
                
                case 2:
                    button_text = "중단";
                    break;
                
                case 3:
                    button_text = "하단";
                    break;
                
                case 4:
                    button_text = "초기화";
                    break;
            }
            
            break;
        
        case 7:
            switch (button_num)
            {
                case 0:
                    button_text = "СТИЛЬ";
                    break;
                
                case 1:
                    button_text = "ВЕРХ";
                    break;
                
                case 2:
                    button_text = "СЕРЕДИНА";
                    break;
                
                case 3:
                    button_text = "НИЗ";
                    break;
                
                case 4:
                    button_text = "СБРОС";
                    break;
            }
            
            break;
        
        case 4:
            switch (button_num)
            {
                case 0:
                    button_text = "ESTILO";
                    break;
                
                case 1:
                    button_text = "ARRIBA";
                    break;
                
                case 2:
                    button_text = "MITAD";
                    break;
                
                case 3:
                    button_text = "ABAJO";
                    break;
                
                case 4:
                    button_text = "REINICIAR";
                    break;
            }
            
            break;
        
        case 6:
            switch (button_num)
            {
                case 0:
                    button_text = "STYLE";
                    break;
                
                case 1:
                    button_text = "HAUT";
                    break;
                
                case 2:
                    button_text = "MILIEU";
                    break;
                
                case 3:
                    button_text = "BAS";
                    break;
                
                case 4:
                    button_text = "RÉINITIALISER";
                    break;
            }
            
            break;
        
        case 8:
            switch (button_num)
            {
                case 0:
                    button_text = "STIL";
                    break;
                
                case 1:
                    button_text = "OBEN";
                    break;
                
                case 2:
                    button_text = "MITTE";
                    break;
                
                case 3:
                    button_text = "BODEN";
                    break;
                
                case 4:
                    button_text = "ZURÜCKSETZEN";
                    break;
            }
            
            break;
        
        case 5:
            switch (button_num)
            {
                case 0:
                    button_text = "ESTILO";
                    break;
                
                case 1:
                    button_text = "CIMA";
                    break;
                
                case 2:
                    button_text = "MEIO";
                    break;
                
                case 3:
                    button_text = "BAIXO";
                    break;
                
                case 4:
                    button_text = "REINICIAR";
                    break;
            }
            
            break;
    }
}

function scr_create_modify_prop()
{
    scr_create_button_slot(interact_type, button_num);
    button_text = scr_set_prop_text(button_num).text_type;
    
    if (global.val.language != 0 && button_num < 100)
        button_text = scr_lang_prop_text(button_num);
}

function scr_create_modify_between()
{
    scr_create_button_slot(interact_type, button_num);
    button_text = scr_set_between_text(button_num).text_type;
}

function scr_set_between_text(arg0)
{
    var _code_text = -1;
    var _name = -1;
    var _shop_price = -1;
    
    switch (global.val.language)
    {
        case 0:
            switch (arg0)
            {
                case 1:
                    _name = "PILLAR";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "PLANK";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "ROCK";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "TENDRILS";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "BRICK";
                    _code_text = "E";
                    break;
            }
            
            break;
        
        case 9:
            switch (arg0)
            {
                case 1:
                    _name = "門柱";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "木板";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "巖石";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "卷鬚";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "磚";
                    _code_text = "E";
                    break;
            }
            
            break;
        
        case 2:
            switch (arg0)
            {
                case 1:
                    _name = "门柱";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "木板";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "岩石";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "卷须";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "砖";
                    _code_text = "E";
                    break;
            }
            
            break;
        
        case 1:
            switch (arg0)
            {
                case 1:
                    _name = "柱";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "板";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "岩";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "蔓";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "レンガ";
                    _code_text = "E";
                    break;
            }
            
            break;
        
        case 3:
            switch (arg0)
            {
                case 1:
                    _name = "기둥";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "판자";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "돌";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "촉수";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "벽돌";
                    _code_text = "E";
                    break;
            }
            
            break;
        
        case 7:
            switch (arg0)
            {
                case 1:
                    _name = "КОЛОННА";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "ДОСКА";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "КАМЕНЬ";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "ЩУПАЛЬЦА";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "КИРПИЧ";
                    _code_text = "E";
                    break;
            }
            
            break;
        
        case 4:
            switch (arg0)
            {
                case 1:
                    _name = "PILAR";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "TABLA";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "ROCA";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "TENTÁCULO";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "LADRILLO";
                    _code_text = "E";
                    break;
            }
            
            break;
        
        case 6:
            switch (arg0)
            {
                case 1:
                    _name = "PILIER";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "PLANCHE";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "ROCHE";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "TENTACULES";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "BRIQUE";
                    _code_text = "E";
                    break;
            }
            
            break;
        
        case 8:
            switch (arg0)
            {
                case 1:
                    _name = "SÄULE";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "PLANKE";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "STEIN";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "RANKEN";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "ZIEGEL";
                    _code_text = "E";
                    break;
            }
            
            break;
        
        case 5:
            switch (arg0)
            {
                case 1:
                    _name = "PILAR";
                    _code_text = "A";
                    break;
                
                case 0:
                    _name = "TÁBUA";
                    _code_text = "B";
                    break;
                
                case 2:
                    _name = "PEDRA";
                    _code_text = "C";
                    break;
                
                case 4:
                    _name = "FILAMENTOS";
                    _code_text = "D";
                    break;
                
                case 3:
                    _name = "TIJOLO";
                    _code_text = "E";
                    break;
            }
            
            break;
    }
    
    var _data = {};
    _data.text_type = _name;
    _data.code_text = _code_text;
    _data.shop_price = _shop_price;
    return _data;
}

function scr_set_prop_text(arg0)
{
    // GNX: custom prop text
    if (arg0 >= 100)
    {
        var _rprop = ds_map_find_value(global.prop_registry, arg0);
        if (_rprop != undefined)
        {
            var _data = {};
            _data.text_type = _rprop.display_name_key;
            _data.code_text = _rprop.code_text;
            _data.shop_price = _rprop.price;
            return _data;
        }
    }

    var _code_text = -1;
    var _name = -1;
    var _shop_price = -1;
    
    switch (arg0)
    {
        case 37:
            _name = "FIRE";
            _code_text = "A";
            break;
        
        case 6:
            _name = "HELM";
            _code_text = "A";
            break;
        
        case 0:
            _name = "CRATE 1";
            _code_text = "A";
            break;
        
        case 1:
            _name = "CRATE 2";
            _code_text = "C";
            break;
        
        case 2:
            _name = "FENCE";
            _code_text = "D";
            break;
        
        case 3:
            _name = "BARREL";
            _code_text = "E";
            _shop_price = 220;
            break;
        
        case 4:
            _name = "BOTTLE 1";
            _code_text = "F";
            _shop_price = 120;
            break;
        
        case 5:
            _name = "BOTTLE 2";
            _code_text = "G";
            break;
        
        case 7:
            _name = "BOARD 1";
            _code_text = "H";
            break;
        
        case 8:
            _name = "SHIELD";
            _code_text = "I";
            break;
        
        case 9:
            _name = "SWORD";
            _code_text = "J";
            break;
        
        case 11:
            _name = "BONE 1";
            _code_text = "K";
            _shop_price = 200;
            break;
        
        case 12:
            _name = "BONE 2";
            _code_text = "L";
            break;
        
        case 13:
            _name = "BONE 3";
            _code_text = "M";
            break;
        
        case 10:
            _name = "ROPE";
            _code_text = "M";
            break;
        
        case 14:
            _name = "BOARD 2";
            _code_text = "M";
            break;
        
        case 15:
            _name = "KUNAI";
            _code_text = "M";
            _shop_price = 300;
            break;
        
        case 16:
            _name = "CROWN";
            _code_text = "M";
            break;
        
        case 17:
            _name = "BOARD 3";
            _code_text = "M";
            _shop_price = 330;
            break;
        
        case 18:
            _name = "BONE 4";
            _code_text = "M";
            break;
        
        case 19:
            _name = "BONE 5";
            _code_text = "M";
            _shop_price = 350;
            break;
        
        case 20:
            _name = "CRATE 3";
            _code_text = "M";
            break;
        
        case 22:
            _name = "SPIKE 1";
            _code_text = "M";
            _shop_price = 380;
            break;
        
        case 23:
            _name = "SPIKE 2";
            _code_text = "M";
            break;
        
        case 24:
            _name = "PORTRAIT";
            _code_text = "M";
            break;
        
        case 25:
            _name = "BUCKET";
            _code_text = "M";
            break;
        
        case 26:
            _name = "PILLORY";
            _code_text = "M";
            break;
        
        case 21:
            _name = "CHAINS 1";
            _code_text = "M";
            break;
        
        case 27:
            _name = "CHAINS 2";
            _code_text = "M";
            break;
        
        case 28:
            _name = "FLAG";
            _code_text = "M";
            break;
        
        case 29:
            _name = "SACK 1";
            _code_text = "M";
            break;
        
        case 30:
            _name = "ROCK 1";
            _code_text = "M";
            _shop_price = 250;
            break;
        
        case 31:
            _name = "ROCK 2";
            _code_text = "M";
            break;
        
        case 32:
            _name = "HAY 1";
            _code_text = "M";
            break;
        
        case 33:
            _name = "HAY 2";
            _code_text = "M";
            _shop_price = 230;
            break;
        
        case 34:
            _name = "EGG 1";
            _code_text = "M";
            break;
        
        case 35:
            _name = "EGG 2";
            _code_text = "M";
            break;
        
        case 36:
            _name = "LAMP";
            _code_text = "M";
            _shop_price = 370;
            break;
        
        case 38:
            _name = "BEACON";
            _code_text = "M";
            _shop_price = 450;
            break;
        
        case 47:
            _name = "PLAQUE";
            _code_text = "M";
            break;
    }
    
    var _data = {};
    _data.text_type = _name;
    _data.code_text = _code_text;
    _data.shop_price = _shop_price;
    return _data;
}

function scr_create_slot_category_button()
{
    scr_create_button_slot(interact_type, button_num);
    
    switch (global.val.language)
    {
        case 0:
            switch (button_num)
            {
                case 0:
                    button_text = "BREED";
                    break;
                
                case 1:
                    button_text = "UTILITY";
                    break;
                
                case 2:
                    button_text = "PLEASURE";
                    break;
            }
            
            break;
        
        case 9:
            switch (button_num)
            {
                case 0:
                    button_text = "交配";
                    break;
                
                case 1:
                    button_text = "功用";
                    break;
                
                case 2:
                    button_text = "愉悅";
                    break;
            }
            
            break;
        
        case 2:
            switch (button_num)
            {
                case 0:
                    button_text = "交配";
                    break;
                
                case 1:
                    button_text = "功用";
                    break;
                
                case 2:
                    button_text = "愉悦";
                    break;
            }
            
            break;
        
        case 1:
            switch (button_num)
            {
                case 0:
                    button_text = "繁殖";
                    break;
                
                case 1:
                    button_text = "機能";
                    break;
                
                case 2:
                    button_text = "快楽";
                    break;
            }
            
            break;
        
        case 3:
            switch (button_num)
            {
                case 0:
                    button_text = "번식";
                    break;
                
                case 1:
                    button_text = "다목적";
                    break;
                
                case 2:
                    button_text = "유흥";
                    break;
            }
            
            break;
        
        case 7:
            switch (button_num)
            {
                case 0:
                    button_text = "РАЗМН.";
                    break;
                
                case 1:
                    button_text = "ВСПОМОГ.";
                    break;
                
                case 2:
                    button_text = "УДОВОЛЬСТВ.";
                    break;
            }
            
            break;
        
        case 4:
            switch (button_num)
            {
                case 0:
                    button_text = "CRUCE";
                    break;
                
                case 1:
                    button_text = "UTILIDAD";
                    break;
                
                case 2:
                    button_text = "PLACER";
                    break;
            }
            
            break;
        
        case 6:
            switch (button_num)
            {
                case 0:
                    button_text = "REPRODUCTION";
                    break;
                
                case 1:
                    button_text = "UTILITAIRE";
                    break;
                
                case 2:
                    button_text = "PLAISIR";
                    break;
            }
            
            break;
        
        case 8:
            switch (button_num)
            {
                case 0:
                    button_text = "ZÜCHTEN";
                    break;
                
                case 1:
                    button_text = "WERKZEUG*";
                    break;
                
                case 2:
                    button_text = "VERGNÜGEN";
                    break;
            }
            
            break;
        
        case 5:
            switch (button_num)
            {
                case 0:
                    button_text = "PROCRIAR";
                    break;
                
                case 1:
                    button_text = "UTILIDADES";
                    break;
                
                case 2:
                    button_text = "PRAZER";
                    break;
            }
            
            break;
    }
}

function scr_create_big_slot_category_button()
{
    scr_create_button_slot(interact_type, button_num);
    
    switch (global.val.language)
    {
        case 0:
            switch (button_num)
            {
                case 0:
                    button_text = "BREED";
                    break;
                
                case 1:
                    button_text = "UTILITY";
                    break;
                
                case 2:
                    button_text = "SPECIAL";
                    break;
            }
            
            break;
        
        case 9:
            switch (button_num)
            {
                case 0:
                    button_text = "交配";
                    break;
                
                case 1:
                    button_text = "功用";
                    break;
                
                case 2:
                    button_text = "特殊";
                    break;
            }
            
            break;
        
        case 2:
            switch (button_num)
            {
                case 0:
                    button_text = "交配";
                    break;
                
                case 1:
                    button_text = "功用";
                    break;
                
                case 2:
                    button_text = "特殊";
                    break;
            }
            
            break;
        
        case 1:
            switch (button_num)
            {
                case 0:
                    button_text = "繁殖";
                    break;
                
                case 1:
                    button_text = "機能";
                    break;
                
                case 2:
                    button_text = "特別";
                    break;
            }
            
            break;
        
        case 3:
            switch (button_num)
            {
                case 0:
                    button_text = "번식";
                    break;
                
                case 1:
                    button_text = "다목적";
                    break;
                
                case 2:
                    button_text = "특수";
                    break;
            }
            
            break;
        
        case 7:
            switch (button_num)
            {
                case 0:
                    button_text = "РАЗМН.";
                    break;
                
                case 1:
                    button_text = "ВСПОМОГ.";
                    break;
                
                case 2:
                    button_text = "СПЕЦ.";
                    break;
            }
            
            break;
        
        case 4:
            switch (button_num)
            {
                case 0:
                    button_text = "CRUCE";
                    break;
                
                case 1:
                    button_text = "UTILIDAD";
                    break;
                
                case 2:
                    button_text = "ESPECIAL";
                    break;
            }
            
            break;
        
        case 6:
            switch (button_num)
            {
                case 0:
                    button_text = "REPRODUCTION";
                    break;
                
                case 1:
                    button_text = "UTILITAIRE";
                    break;
                
                case 2:
                    button_text = "SPÉCIAL";
                    break;
            }
            
            break;
        
        case 8:
            switch (button_num)
            {
                case 0:
                    button_text = "ZÜCHTEN";
                    break;
                
                case 1:
                    button_text = "WERKZEUG*";
                    break;
                
                case 2:
                    button_text = "SPEZIAL";
                    break;
            }
            
            break;
        
        case 5:
            switch (button_num)
            {
                case 0:
                    button_text = "PROCRIAR";
                    break;
                
                case 1:
                    button_text = "UTILIDADES";
                    break;
                
                case 2:
                    button_text = "ESPECIAL";
                    break;
            }
            
            break;
    }
}

function scr_create_tent_category_button()
{
    scr_create_button_slot(interact_type, button_num);
    
    switch (global.val.language)
    {
        case 0:
            switch (button_num)
            {
                case 0:
                    button_text = "BREED";
                    break;
                
                case 1:
                    button_text = "UTILITY";
                    break;
            }
            
            break;
        
        case 9:
            switch (button_num)
            {
                case 0:
                    button_text = "交配";
                    break;
                
                case 1:
                    button_text = "功用";
                    break;
            }
            
            break;
        
        case 2:
            switch (button_num)
            {
                case 0:
                    button_text = "交配";
                    break;
                
                case 1:
                    button_text = "功用";
                    break;
            }
            
            break;
        
        case 1:
            switch (button_num)
            {
                case 0:
                    button_text = "繁殖";
                    break;
                
                case 1:
                    button_text = "機能";
                    break;
            }
            
            break;
        
        case 3:
            switch (button_num)
            {
                case 0:
                    button_text = "번식";
                    break;
                
                case 1:
                    button_text = "다목적";
                    break;
            }
            
            break;
        
        case 7:
            switch (button_num)
            {
                case 0:
                    button_text = "РАЗМН.";
                    break;
                
                case 1:
                    button_text = "ВСПОМОГ.";
                    break;
            }
            
            break;
        
        case 4:
            switch (button_num)
            {
                case 0:
                    button_text = "CRUCE";
                    break;
                
                case 1:
                    button_text = "UTILIDAD";
                    break;
            }
            
            break;
        
        case 6:
            switch (button_num)
            {
                case 0:
                    button_text = "REPRODUCTION";
                    break;
                
                case 1:
                    button_text = "UTILITAIRE";
                    break;
            }
            
            break;
        
        case 8:
            switch (button_num)
            {
                case 0:
                    button_text = "ZÜCHTEN";
                    break;
                
                case 1:
                    button_text = "WERKZEUG*";
                    break;
            }
            
            break;
        
        case 5:
            switch (button_num)
            {
                case 0:
                    button_text = "PROCRIAR";
                    break;
                
                case 1:
                    button_text = "UTILIDADES";
                    break;
            }
            
            break;
    }
}

