function scr_slot_h_state_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        scr_set_slot_spr_part(1);
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
    }
    
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    
    switch (slot_data.anim_struct.sp_state)
    {
        case 0:
            slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
            
            if (slot_data.anim_struct.sp_index >= 3)
            {
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_state = 1;
                    slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                }
            }
            
            break;
        
        case 1:
            slot_data.anim_struct.sp_timer -= global.w_spd;
            
            if (slot_data.anim_struct.sp_timer <= 0)
            {
                slot_data.anim_struct.sp_timer = 0;
                slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 6)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    slot_data.anim_struct.sp_state = 2;
                    scr_create_sp_drip(slot_data, depth - 1, true);
                }
            }
            
            break;
        
        case 2:
            slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
            slot_data.anim_struct.sp_timer -= global.w_spd;
            
            if (slot_data.anim_struct.sp_timer <= 0)
            {
                slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                scr_create_sp_drip(slot_data, depth - 1, false);
            }
            
            break;
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_base_start()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.anim_spd *= 2;
        slot_data.h_loop = choose(2, 3, 4);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
                scr_set_mon_spr_data(mon_data.slot_id, 0);
        }
    }
    
    var _tired_timer = unit_data.tired_c;
    _tired_timer = max(0, _tired_timer - global.w_spd);
    
    if (_tired_timer <= 0)
        slot_data.anim_struct.anim_spd = 1/30;
    
    unit_data.tired_c = _tired_timer;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end && --slot_data.h_loop < 0)
    {
        slot_data.mon_timer[0] = 60;
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_h_base_sloop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
                scr_set_mon_spr_data(mon_data.slot_id, 2);
        }
        
        slot_data.mon_timer[0] = irandom_range(360, 420);
        spawn_part[0] = true;
        spawn_stream = true;
        
        if (slot_data.anim_struct.sp_state != -1 && floor(slot_data.anim_struct.sp_index) != 7)
        {
            slot_data.anim_struct.sp_index = 0;
            slot_data.anim_struct.sp_timer = 0;
            slot_data.anim_struct.sp_state = -1;
            scr_create_sp_drip(slot_data, depth - 1, true);
        }
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        scr_create_sq_effect(2, 0.3, 35, slot_data.slot_floor, 0);
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end && irandom_range(0, 100) < 15)
        scr_create_sp_drip(slot_data, depth - 1, false);
    
    slot_data.mon_timer[0] -= global.w_spd;
    
    if (slot_data.mon_timer[0] <= 0 && animation_end)
    {
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_h_base_floop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 11;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        slot_data.mon_timer[0] = irandom_range(360, 420);
        unit_data.tired_c = 980;
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        scr_create_sq_effect(2, 0.5, 60, slot_data.slot_floor, 0);
    }
    
    scr_animation_end(true, 4);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end && irandom_range(0, 100) < 15)
        scr_create_sp_drip(slot_data, depth - 1, false);
    
    slot_data.mon_timer[0] -= global.w_spd;
    
    if (slot_data.mon_timer[0] <= 0 && floor(slot_data.anim_struct.index) == 1)
    {
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
        slot_data.mon_timer[0] = 30;
    }
}

function scr_slot_h_base_ej()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.index = 2;
        scr_set_slot_spr_part(3);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
                scr_set_mon_spr_data(mon_data.slot_id, 3);
        }
        
        slot_data.mon_timer[0] = irandom_range(30, 60);
        slot_data.h_loop = irandom_range(5, 7);
        scr_create_sq_effect(slot_data.anim_struct.index, 0.7, 100, slot_data.slot_floor, 0);
        scr_play_ej_sfx();
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 5);
    
    switch (floor(slot_data.anim_struct.index))
    {
        case 0:
            slot_data.anim_struct.index = 2;
            break;
        
        case 3:
            slot_data.anim_struct.anim_spd = 0;
            slot_data.mon_timer[0] -= global.w_spd;
            
            if (slot_data.mon_timer[0] <= 0)
            {
                if (--slot_data.h_loop <= 0)
                {
                    scr_unit_removal(true, false, false, false, -1);
                    scr_check_frog_unit_swap(slot_data.h_type);
                }
                else
                {
                    if (slot_data.h_loop == 1)
                        slot_data.mon_timer[0] = irandom_range(120, 180);
                    else
                        slot_data.mon_timer[0] = irandom_range(45, 90);
                    
                    slot_data.anim_struct.index = 4;
                    slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                }
            }
            
            break;
    }
    
    scr_mon_frame(slot_data.anim_struct.index);
}

function scr_slot_h_base_ej_2()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 6;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.index = 2;
        scr_set_slot_spr_part(3);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
                scr_set_mon_spr_data(mon_data.slot_id, 3);
        }
        
        slot_data.mon_timer[0] = irandom_range(30, 60);
        slot_data.h_loop = irandom_range(5, 7);
        scr_play_ej_sfx();
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 5);
    
    switch (floor(slot_data.anim_struct.index))
    {
        case 3:
            slot_data.anim_struct.anim_spd = 0;
            slot_data.mon_timer[0] -= global.w_spd;
            
            if (slot_data.mon_timer[0] <= 0)
            {
                if (--slot_data.h_loop <= 0)
                {
                    scr_unit_removal(true, false, false, false, -1);
                    scr_check_frog_unit_swap(slot_data.h_type);
                }
                else
                {
                    if (slot_data.h_loop == 1)
                        slot_data.mon_timer[0] = irandom_range(120, 180);
                    else
                        slot_data.mon_timer[0] = irandom_range(45, 90);
                    
                    slot_data.anim_struct.index = 2;
                    slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                }
            }
            
            break;
    }
    
    scr_mon_frame(slot_data.anim_struct.index);
}

function scr_slot_h_birth_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(1);
    }
    
    var _inf = false;
    var _prop_num = array_length(slot_data.prop);
    
    for (var i = 0; i < _prop_num; i++)
    {
        if (slot_data.prop[i].prop_type == 40)
            _inf = true;
    }
    
    if (unit_data.preg != -1 && !_inf)
    {
        slot_data.anim_struct.char_state = 1;
        slot_data.anim_struct.ff = true;
        slot_data.h_step = 0;
    }
    
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, 2);
}

function scr_slot_birth_spawn_loop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 1;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        slot_data.h_wait = 3;
        var _data = 
        {
            mon_type: unit_data.preg,
            class: unit_data.class,
            lvl: unit_data.lvl
        };
        scr_create_prop(id, 40, _data, -1);
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 2);
    
    if (animation_end)
    {
        if (--slot_data.h_wait <= 0)
        {
            slot_data.anim_struct.index = 1;
            slot_data.h_step++;
            slot_data.h_wait = 60;
        }
    }
    
    var _index = slot_data.anim_struct.index + (max(0, unit_data.skin) * 6);
    var _prop_num = array_length(slot_data.prop);
    
    for (var i = 0; i < _prop_num; i++)
    {
        if (slot_data.prop[i].prop_type == 40)
            slot_data.prop[i].prop_id.image_index = _index;
    }
}

function scr_slot_birth_spawn_ej()
{
    var _auto = true;
    
    switch (slot_data.h_type)
    {
        case 5:
            _auto = false;
            break;
    }
    
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        unit_data.tired_c = 980;
        slot_data.anim_struct.index = 0;
        unit_data.milk = true;
        
        if (unit_data.class != 13 || (unit_data.class == 13 && irandom_range(1, 100) >= 40))
        {
            unit_data.preg = -1;
            
            if (unit_data.preg_c != -1)
            {
                unit_data.preg_c = max(0, unit_data.preg_c - 1);
                
                if (floor(unit_data.preg_c) == 0)
                    scr_check_softlock();
            }
        }
        
        _prop_num = array_length(slot_data.prop);
        
        for (var i = 0; i < _prop_num; i++)
        {
            if (slot_data.prop[i].prop_type == 40)
            {
                slot_data.prop[i].prop_id.prop_data.spawn = !_auto;
                slot_data.prop[i].prop_id.mask_index = slot_data.prop[i].prop_id.sprite_index;
                slot_data.prop[i].prop_id.image_index++;
                i = _prop_num;
            }
        }
    }
    
    var _next = false;
    var _prop_num = array_length(slot_data.prop);
    
    for (var i = 0; i < _prop_num; i++)
    {
        if (slot_data.prop[i].prop_type == 40)
        {
            with (slot_data.prop[i].prop_id)
            {
                image_index += (0.13333333333333333 * global.w_spd);
                
                if ((floor(image_index + 1) % 6) == 0)
                {
                    _next = true;
                    
                    if (_auto)
                    {
                        scr_mon_birth(prop_data.mon_data, slot_id);
                        array_delete(slot_id.slot_data.prop, i, 1);
                        instance_destroy();
                        i = _prop_num; // prop array was shrunk; exit loop
                    }
                    else
                    {
                        hover = false;
                    }
                }
            }
        }
    }
    
    if (_next)
    {
        if (!_auto)
        {
            _prop_num = array_length(slot_data.prop);
            
            for (var i = 0; i < _prop_num; i++)
            {
                if (slot_data.prop[i].prop_type == 40)
                    slot_data.prop[i].prop_id.image_index = 5 + (max(0, unit_data.skin) * 6);
            }
            
            slot_data.anim_struct.char_state = 0;
            slot_data.anim_struct.ff = true;
            scr_check_frog_unit_swap(slot_data.h_type);
        }
        else if (unit_data.preg != -1)
        {
            slot_data.anim_struct.char_state = 1;
            slot_data.anim_struct.ff = true;
            slot_data.h_step = 0;
        }
        else
        {
            slot_data.anim_struct.char_state = 0;
            slot_data.anim_struct.ff = true;
            scr_check_frog_unit_swap(slot_data.h_type);
        }
    }
}

function scr_slot_display_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        scr_set_slot_spr_part(1);
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
    }
    
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 2);
    var _inst_list = ds_list_create();
    var _num = instance_place_list(x, y, obj_mon, _inst_list, false);
    
    if (_num > 0)
    {
        for (var i = 0; i < _num; i++)
        {
            var _display = false;
            var _mon = ds_list_find_value(_inst_list, i);
            
            if (_mon.mon_data.task == 0 && !_mon.mon_data.display)
            {
                if (irandom_range(1, 100) >= 50)
                {
                    _display = true;
                    scr_mood_value_set(0.25);
                }
                
                with (_mon)
                {
                    mon_data.display = true;
                    
                    if (_display)
                    {
                        mon_data.mood_type = 3;
                        mon_data.mood_timer = 180;
                    }
                }
            }
        }
    }
    
    ds_list_destroy(_inst_list);
}

function scr_slot_h_base_wait()
{
    if (slot_data.anim_struct.ff)
        slot_data.anim_struct.ff = false;
    
    slot_data.mon_timer[0] = max(0, slot_data.mon_timer[0] - global.w_spd);
    
    if (slot_data.mon_timer[0] <= 0)
    {
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_non_h_base_wait()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.ff = false;
    }
    
    slot_data.h_wait = max(0, slot_data.h_wait - global.w_spd);
    
    if (slot_data.h_wait <= 0)
    {
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_h_milk_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(1);
    }
    
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, 2);
    
    if (unit_data.milk)
        scr_slot_call_mon(false);
}

function scr_slot_h_milk_loop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 7;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        h_unit_list[0].visible = false;
        slot_data.mon_timer[0] = 0;
        slot_data.h_loop = 3;
        slot_data.milk_step = 0;
    }
    
    var _max_wait = 60;
    var _old_index = floor(slot_data.anim_struct.index);
    slot_data.anim_struct.index = min(4, slot_data.anim_struct.index + (slot_data.anim_struct.anim_spd * global.w_spd));
    var _new_index = floor(slot_data.anim_struct.index);
    var _exit = false;
    
    switch (_old_index)
    {
        case 0:
            if (_old_index != _new_index)
            {
                if (slot_data.milk_step == 1)
                {
                    slot_data.anim_struct.index = 3;
                    h_unit_list[0].mon_data.index = 4;
                }
                else
                {
                    h_unit_list[0].mon_data.index = 1;
                }
            }
            
            break;
        
        case 1:
            if (_old_index != _new_index)
            {
                if (slot_data.milk_step == 1)
                {
                    slot_data.anim_struct.index = 0;
                    h_unit_list[0].mon_data.index = 3;
                }
                else
                {
                    h_unit_list[0].mon_data.index = 2;
                }
            }
            
            break;
        
        case 2:
            slot_data.anim_struct.anim_spd = 0;
            
            if (slot_data.mon_timer[0] >= 5 && slot_data.milk_step != -1)
            {
                scr_create_prop(id, 39, -1, -1);
                slot_data.milk_step = -1;
                scr_play_milk_sfx();
            }
            
            slot_data.mon_timer[0] += global.w_spd;
            
            if (slot_data.mon_timer[0] >= _max_wait)
            {
                slot_data.mon_timer[0] = 0;
                slot_data.milk_step = 1;
                slot_data.anim_struct.index = 1;
                slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                h_unit_list[0].mon_data.index = 1;
            }
            
            break;
        
        case 3:
            if (_old_index != _new_index)
            {
                if (slot_data.milk_step == 0)
                {
                    if (--slot_data.h_loop <= 0)
                    {
                        _exit = true;
                    }
                    else
                    {
                        slot_data.anim_struct.index = 0;
                        h_unit_list[0].mon_data.index = 0;
                    }
                }
                else
                {
                    h_unit_list[0].mon_data.index = 5;
                }
            }
            
            break;
        
        case 4:
            slot_data.anim_struct.anim_spd = 0;
            
            if (slot_data.mon_timer[0] >= 5 && slot_data.milk_step != -1)
            {
                scr_create_prop(id, 39, -1, -1);
                slot_data.milk_step = -1;
                scr_play_milk_sfx();
            }
            
            slot_data.mon_timer[0] += global.w_spd;
            
            if (slot_data.mon_timer[0] >= _max_wait)
            {
                slot_data.mon_timer[0] = 0;
                slot_data.milk_step = 0;
                slot_data.anim_struct.index = 3;
                slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                h_unit_list[0].mon_data.index = 4;
            }
            
            break;
    }
    
    if (_exit)
    {
        h_unit_list[0].mon_data.milk_full = true;
        scr_unit_removal(false, false, false, false, -1);
        var _m_lvl = unit_data.lvl;
        
        if (unit_data.class >= 8)
        {
            if (unit_data.class == 8)
                _m_lvl = 4;
            else
                _m_lvl = 1;
            
            if (unit_data.class == 9)
                unit_data.scr_wait = 0;
        }
        
        scr_add_milk_item(_m_lvl, 1);
        scr_icon_pop_up_create(x + (image_xscale * 0.5), y - 50, 1, 1, false);
        unit_data.milk = false;
        slot_data.anim_struct.char_state = 0;
        slot_data.anim_struct.ff = true;
        slot_data.mon_timer[0] = 0;
        slot_data.h_loop = 0;
        scr_check_frog_unit_swap(slot_data.h_type);
    }
}

function scr_slot_cow_state_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        scr_set_slot_spr_part(1);
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 4;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.milk_index = 0;
        slot_data.anim_struct.milk_spd = 9;
        slot_data.anim_struct.milk_timer = 600;
    }
    
    var _tired_timer = unit_data.tired_c;
    _tired_timer = max(0, _tired_timer - global.w_spd);
    
    if (_tired_timer <= 0)
        slot_data.anim_struct.anim_spd = 0.04666666666666666;
    
    unit_data.tired_c = _tired_timer;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    
    if (animation_end)
    {
        slot_data.anim_struct.blink_timer = irandom_range(10, 20);
        
        if (irandom_range(0, 100) > 70)
            slot_data.anim_struct.blink_index = 0;
        else
            slot_data.anim_struct.blink_index = -1;
    }
    
    if (slot_data.anim_struct.blink_index != -1)
    {
        slot_data.anim_struct.blink_timer = max(0, slot_data.anim_struct.blink_timer - 1);
        
        if (slot_data.anim_struct.blink_timer == 0)
            slot_data.anim_struct.blink_index = -1;
    }
    
    scr_slot_cow_milking();
    scr_slot_call_mon(true);
}

function scr_slot_cow_state_loop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.blink_index = -1;
        scr_set_slot_spr_part(2);
        
        if (slot_data.mon_placement[1] != -1)
        {
            with (slot_data.mon_placement[1])
                scr_set_mon_spr_data(mon_data.slot_id, 2);
        }
        
        slot_data.mon_timer[1] = irandom_range(360, 420);
        unit_data.tired_c = 980;
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
        scr_play_slap_sfx(2);
    
    scr_animation_end(true, 5);
    scr_mon_frame(slot_data.anim_struct.index);
    scr_slot_cow_milking();
    slot_data.mon_timer[1] -= global.w_spd;
    
    if (slot_data.mon_timer[1] <= 0 && animation_end)
    {
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_cow_state_floop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 11;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        slot_data.mon_timer[1] = irandom_range(360, 420);
        unit_data.tired_c = 980;
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
        scr_play_slap_sfx(2);
    
    scr_animation_end(true, 4);
    scr_mon_frame(slot_data.anim_struct.index);
    scr_slot_cow_milking();
    slot_data.mon_timer[1] -= global.w_spd;
    
    if (slot_data.mon_timer[1] <= 0 && animation_end)
    {
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_cow_state_ej()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.index = 2;
        scr_set_slot_spr_part(3);
        
        if (slot_data.mon_placement[1] != -1)
        {
            with (slot_data.mon_placement[1])
                scr_set_mon_spr_data(mon_data.slot_id, 3);
        }
        
        slot_data.mon_timer[1] = irandom_range(30, 60);
        slot_data.h_loop = irandom_range(5, 7);
        scr_play_ej_sfx();
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 5);
    
    switch (floor(slot_data.anim_struct.index))
    {
        case 0:
            slot_data.anim_struct.index = 2;
            break;
        
        case 3:
            slot_data.anim_struct.anim_spd = 0;
            slot_data.mon_timer[1] -= global.w_spd;
            
            if (slot_data.mon_timer[1] <= 0)
            {
                if (--slot_data.h_loop <= 0)
                {
                    scr_unit_removal(true, false, false, false, -1);
                    scr_check_frog_unit_swap(slot_data.h_type);
                }
                else
                {
                    if (slot_data.h_loop == 1)
                        slot_data.mon_timer[1] = irandom_range(120, 180);
                    else
                        slot_data.mon_timer[1] = irandom_range(45, 90);
                    
                    slot_data.anim_struct.index = 4;
                    slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                }
            }
            
            break;
    }
    
    scr_mon_frame(slot_data.anim_struct.index);
    scr_slot_cow_milking();
}

function scr_slot_drink_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        scr_set_slot_spr_part(1);
        slot_data.anim_struct.index = 0;
        slot_data.h_step = 0;
        slot_data.mon_timer = [0, 0];
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
    }
    
    var _h = h_unit_list;
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 2);
    
    for (var i = 0; i < array_length(slot_data.mon_placement); i++)
        slot_data.mon_placement[i] = -1;
}

function scr_slot_h_drink_loop()
{
    if (slot_data.anim_struct.ff)
    {
        var _id = id;
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 7;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.index = 0;
        scr_set_slot_spr_part(2);
        
        for (var i = 0; i < 2; i++)
        {
            if (slot_data.mon_placement[i] != -1 && slot_data.mon_placement[i].mon_data.spr_data.spr_type == -1)
            {
                with (slot_data.mon_placement[i])
                {
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
                    other.slot_data.mon_timer[i] = 400;
                    other.slot_data.mon_index[i] = 0;
                    mon_data.task = 5;
                }
            }
        }
    }
    
    var _h = h_unit_list;
    
    if (slot_data.mon_placement[0] != -1)
    {
        slot_data.mon_timer[0] = max(0, slot_data.mon_timer[0] - global.w_spd);
        slot_data.mon_index[0] = floor(slot_data.mon_timer[0] / 50);
        
        if ((slot_data.mon_index[0] % 2) == 0)
        {
            slot_data.mon_index[0] = 1;
            slot_data.anim_struct.index = 1;
        }
        else
        {
            slot_data.mon_index[0] = 0;
            slot_data.anim_struct.index = 0;
        }
        
        if (slot_data.mon_timer[0] == 0)
        {
            slot_data.mon_timer[0] = -1;
            scr_unit_removal(false, false, false, false, -1);

            var _old_dn0 = slot_data.drink_num;
            if (--slot_data.drink_num <= 0)
            {
                slot_data.drink_num = 0;
                unit_data.milk = false;
            }
            if (global.gnx_debug_verbose)
            {
                var _gfd0 = file_text_open_append(GNX_LOG);
                file_text_write_string(_gfd0, "[DRINK] place=0 drink_num=" + string(_old_dn0) + "→" + string(slot_data.drink_num) + " milk=" + string(unit_data.milk));
                file_text_writeln(_gfd0);
                file_text_close(_gfd0);
            }
        }
        else
        {
            slot_data.mon_placement[0].mon_data.index = slot_data.mon_index[0];
        }
    }
    
    if (slot_data.mon_placement[1] != -1)
    {
        slot_data.mon_timer[1] = max(0, slot_data.mon_timer[1] - global.w_spd);
        slot_data.mon_index[1] = floor(slot_data.mon_timer[1] / 50) % 2;
        slot_data.anim_struct.index = slot_data.mon_index[1];
        
        if (slot_data.mon_timer[1] == 0)
        {
            slot_data.mon_timer[1] = -1;
            scr_unit_removal(false, false, false, false, -1);

            var _old_dn1 = slot_data.drink_num;
            if (--slot_data.drink_num <= 0)
            {
                slot_data.drink_num = 0;
                unit_data.milk = false;
            }
            if (global.gnx_debug_verbose)
            {
                var _gfd1 = file_text_open_append(GNX_LOG);
                file_text_write_string(_gfd1, "[DRINK] place=1 drink_num=" + string(_old_dn1) + "→" + string(slot_data.drink_num) + " milk=" + string(unit_data.milk));
                file_text_writeln(_gfd1);
                file_text_close(_gfd1);
            }
        }
        else
        {
            slot_data.mon_placement[1].mon_data.index = slot_data.mon_index[1];
        }
    }
    
    if ((slot_data.mon_timer[0] + slot_data.mon_timer[1]) == 0)
    {
        slot_data.anim_struct.char_state = 0;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_clean_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.h_wait = 0;
        slot_data.anim_struct.ff = false;
    }
    
    slot_data.h_wait += global.w_spd;
    
    if (slot_data.h_wait >= 90)
    {
        slot_data.h_wait = 0;
        scr_check_clean_range(slot_range);
    }
}

function scr_slot_utility_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 7;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
        scr_play_tent_sfx(2);
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
}

function scr_slot_recover_idle()
{
    scr_slot_utility_idle();
    scr_unit_preg_generate(1);
    slot_data.h_wait += global.w_spd;
    
    if (slot_data.h_wait >= 60 && unit_data.preg_c >= unit_data.preg_c_max)
    {
        slot_data.h_wait = 0;
        scr_check_frog_unit_swap(slot_data.h_type);
    }
}

function scr_slot_carry_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.h_wait = 0;
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.index = 0;
        
        if (unit_data != -1)
            scr_set_slot_spr_part(1);
    }
    
    slot_data.h_wait += global.w_spd;
    
    if (slot_data.h_wait >= 90 && (slot_head_id == -1 || obj_control.hold_id != slot_head_id))
    {
        slot_data.h_wait = 0;
        scr_spawn_carry_mon_task(slot_range);
    }
}

function scr_slot_carry_load()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.h_wait = 0;
        slot_data.anim_struct.ff = false;
        
        if (unit_data != -1)
            scr_set_slot_spr_part(1);
    }
    
    slot_data.h_wait += global.w_spd;
    
    if (slot_data.h_wait >= 60)
    {
        slot_data.h_wait = 0;
        var _floor = slot_data.slot_floor;
        var _x = floor(x + (image_xscale * 0.5));
        var _y = y;
        var _slot_pos = ds_list_find_index(global.slot_list[_floor], id);
        var _door = scr_find_nearest_door(_x, _y, _floor);
        _x = _door.x + floor(_door.image_xscale * 0.5);
        _y = _door.y;
        var _mon = scr_create_mon(1, _x, _y, _floor, _slot_pos, 1);
        array_push(h_unit_list, _mon);
        
        with (_mon)
        {
            mon_data.mood_type = 1;
            mon_data.mood_timer = 180;
            scr_mood_value_set(-0.25);
        }
        
        global.val.nest_num[2]++;
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_carry_active()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        
        if (unit_data != -1)
            scr_set_slot_spr_part(1);
    }
}

function scr_slot_patrol_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        
        if (unit_data != -1)
            scr_set_slot_spr_part(1);
    }
    
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_slot_call_mon(false);
}

function scr_slot_patrol_active()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        
        if (unit_data != -1)
            scr_set_slot_spr_part(1);
    }
}

function scr_slot_h_tent_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        scr_set_slot_spr_part(1);
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        
        if (unit_data.preg != -1)
        {
            slot_data.anim_struct.char_state = 1;
            slot_data.anim_struct.ff = true;
            slot_data.h_step = 3;
        }
    }
    
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    
    if (unit_data.tired_c == 0)
    {
        slot_data.anim_struct.char_state = 1;
        slot_data.anim_struct.ff = true;
        slot_data.h_step = 0;
    }
    
    switch (slot_data.anim_struct.sp_state)
    {
        case 0:
            slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
            
            if (slot_data.anim_struct.sp_index >= 3)
            {
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_state = 1;
                    slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                }
            }
            
            break;
        
        case 1:
            slot_data.anim_struct.sp_timer -= global.w_spd;
            
            if (slot_data.anim_struct.sp_timer <= 0)
            {
                slot_data.anim_struct.sp_timer = 0;
                slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 6)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    slot_data.anim_struct.sp_state = 2;
                    scr_create_sp_drip(slot_data, depth - 1, true);
                }
            }
            
            break;
        
        case 2:
            slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
            slot_data.anim_struct.sp_timer -= global.w_spd;
            
            if (slot_data.anim_struct.sp_timer <= 0)
            {
                slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                scr_create_sp_drip(slot_data, depth - 1, false);
            }
            
            break;
    }
}

function scr_slot_h_tent_sloop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        slot_data.h_wait = irandom_range(360, 420);
        spawn_part[0] = true;
        spawn_stream = true;
        
        if (slot_data.anim_struct.sp_state != -1 && floor(slot_data.anim_struct.sp_index) != 7)
        {
            slot_data.anim_struct.sp_index = 0;
            slot_data.anim_struct.sp_timer = 0;
            slot_data.anim_struct.sp_state = -1;
            scr_create_sp_drip(slot_data, depth - 1, true);
        }
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_tent_sfx(2);
        scr_create_sq_effect(2, 0.3, 35, slot_data.slot_floor, 0);
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end && irandom_range(0, 100) < 15)
        scr_create_sp_drip(slot_data, depth - 1, false);
    
    slot_data.h_wait -= global.w_spd;
    
    if (slot_data.h_wait <= 0 && animation_end)
    {
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_h_tent_floop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 7;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        slot_data.h_wait = irandom_range(360, 420);
        unit_data.tired_c = 980;
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_tent_sfx(2);
        scr_create_sq_effect(2, 0.5, 60, slot_data.slot_floor, 0);
    }
    
    scr_animation_end(true, 4);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end && irandom_range(0, 100) < 15)
        scr_create_sp_drip(slot_data, depth - 1, false);
    
    slot_data.h_wait -= global.w_spd;
    
    if (slot_data.h_wait <= 0 && floor(slot_data.anim_struct.index) == 1)
    {
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
        slot_data.h_wait = 30;
    }
}

function scr_slot_h_tent_ej()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.index = 2;
        scr_set_slot_spr_part(3);
        slot_data.h_wait = irandom_range(30, 60);
        slot_data.h_loop = irandom_range(5, 7);
        scr_create_sq_effect(slot_data.anim_struct.index, 0.7, 100, slot_data.slot_floor, 0);
        scr_play_ej_sfx();
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 5);
    
    switch (floor(slot_data.anim_struct.index))
    {
        case 0:
            slot_data.anim_struct.index = 2;
            break;
        
        case 3:
            slot_data.anim_struct.anim_spd = 0;
            slot_data.h_wait -= global.w_spd;
            
            if (slot_data.h_wait <= 0)
            {
                if (--slot_data.h_loop <= 0)
                {
                    if (floor(unit_data.preg_c) != 0)
                    {
                        if (unit_data.preg == -1)
                        {
                            if (irandom_range(0, 100) <= unit_data.preg_prd || unit_data.class == 12)
                            {
                                unit_data.preg = 2;
                                unit_data.preg_prd = 10;
                                slot_data.h_step++;
                            }
                            else
                            {
                                unit_data.preg_prd += 10;
                                slot_data.anim_struct.char_state = 0;
                                slot_data.anim_struct.sp_state = 0;
                            }
                        }
                        else
                        {
                            slot_data.h_step++;
                        }
                    }
                    else
                    {
                        slot_data.anim_struct.sp_state = 0;
                        slot_data.anim_struct.char_state = 0;
                        scr_check_frog_unit_swap(slot_data.h_type);
                    }
                    
                    slot_data.anim_struct.ff = true;
                }
                else
                {
                    if (slot_data.h_loop == 1)
                        slot_data.h_wait = irandom_range(120, 180);
                    else
                        slot_data.h_wait = irandom_range(45, 90);
                    
                    slot_data.anim_struct.index = 4;
                    slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                }
            }
            
            break;
    }
    
    scr_mon_frame(slot_data.anim_struct.index);
}

function scr_slot_h_tent_birth()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(4);
        slot_data.h_wait = 3;
        var _data = 
        {
            mon_type: unit_data.preg,
            class: unit_data.class,
            lvl: unit_data.lvl
        };
        scr_create_prop(id, 40, _data, -1);
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 2);
    
    if (animation_end)
    {
        if (--slot_data.h_wait <= 0)
        {
            slot_data.anim_struct.index = 1;
            slot_data.h_step++;
            slot_data.anim_struct.ff = true;
            slot_data.h_wait = 60;
        }
    }
    
    var _birth_end_index = 6;
    
    if (slot_data.h_type == 27 || slot_data.h_type == 28)
        _birth_end_index = 5;
    
    var _index = slot_data.anim_struct.index + (max(0, unit_data.skin) * _birth_end_index);
    var _prop_num = array_length(slot_data.prop);
    
    for (var i = 0; i < _prop_num; i++)
    {
        if (slot_data.prop[i].prop_type == 40)
        {
            slot_data.prop[i].prop_id.image_index = _index;
            i = _prop_num;
        }
    }
}

function scr_slot_h_tent_birth_ej()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        unit_data.tired_c = 980;
        slot_data.anim_struct.index = 0;
        unit_data.milk = true;
        
        if (unit_data.class != 13 || (unit_data.class == 13 && irandom_range(1, 100) >= 40))
        {
            unit_data.preg = -1;
            
            if (unit_data.preg_c != -1)
            {
                unit_data.preg_c = max(0, unit_data.preg_c - 1);
                
                if (floor(unit_data.preg_c) == 0)
                    scr_check_softlock();
            }
        }
        
        _prop_num = array_length(slot_data.prop);
        
        for (var i = 0; i < _prop_num; i++)
        {
            if (slot_data.prop[i].prop_type == 40)
            {
                slot_data.prop[i].prop_id.image_index++;
                i = _prop_num;
            }
        }
    }
    
    var _next = false;
    var _birth_end_index = 6;
    
    if (slot_data.h_type == 27 || slot_data.h_type == 28)
        _birth_end_index = 5;
    
    var _prop_num = array_length(slot_data.prop);
    
    for (var i = 0; i < _prop_num; i++)
    {
        if (slot_data.prop[i].prop_type == 40)
        {
            with (slot_data.prop[i].prop_id)
            {
                image_index += (0.13333333333333333 * global.w_spd);
                
                if (image_index >= ((max(0, other.unit_data.skin) + 1) * _birth_end_index))
                {
                    _next = true;
                    scr_mon_birth(prop_data.mon_data, slot_id);
                    array_delete(slot_id.slot_data.prop, i, 1);
                    instance_destroy();
                }
            }
            
            i = _prop_num;
        }
    }
    
    if (_next)
    {
        if (unit_data.preg != -1)
        {
            slot_data.anim_struct.char_state = 1;
            slot_data.anim_struct.ff = true;
            slot_data.h_step = 3;
        }
        else
        {
            slot_data.anim_struct.char_state = 0;
            slot_data.anim_struct.ff = true;
        }
        
        scr_check_frog_unit_swap(slot_data.h_type);
    }
}

function scr_slot_h_milk_2_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(1);
    }
    
    if (unit_data.milk)
    {
        slot_data.anim_struct.char_state = 1;
        slot_data.anim_struct.ff = true;
    }
    else
    {
        unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
        slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
        scr_animation_end(true, slot_data.anim_struct.frame_c);
        slot_data.h_wait += global.w_spd;
        
        if (slot_data.h_wait >= 60)
        {
            slot_data.h_wait = 0;
            scr_check_frog_unit_swap(slot_data.h_type);
        }
    }
}

function scr_slot_h_milk_2_loop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 7;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        slot_data.h_wait = 900;
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
        scr_play_tent_sfx(2);
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    slot_data.h_wait -= global.w_spd;
    
    if (slot_data.h_wait <= 0)
    {
        slot_data.milk_num--;
        slot_data.h_wait = 900;
        var _m_lvl = unit_data.lvl;
        
        if (unit_data.class >= 8)
        {
            if (unit_data.class == 8)
                _m_lvl = 4;
            else
                _m_lvl = 1;
        }
        
        scr_add_milk_item(_m_lvl, 1);
        scr_icon_pop_up_create(x + (image_xscale * 0.5), y - 50, 1, 1, false);
        
        if (slot_data.milk_num == 0)
        {
            slot_data.anim_struct.char_state = 0;
            slot_data.anim_struct.ff = true;
            unit_data.milk = false;
            
            if (unit_data.class == 9)
                unit_data.scr_wait = 0;
            
            scr_check_frog_unit_swap(slot_data.h_type);
        }
    }
}

function scr_slot_h_gb_1_sloop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
        
        slot_data.set_timer = 300;
        
        for (var i = 0; i < array_length(spawn_part); i++)
            spawn_part[i] = true;
        
        spawn_stream = true;
        
        if (slot_data.anim_struct.sp_state != -1 && floor(slot_data.anim_struct.sp_index) != 7)
        {
            slot_data.anim_struct.sp_index = 0;
            slot_data.anim_struct.sp_timer = 0;
            slot_data.anim_struct.sp_state = -1;
            scr_create_sp_drip(slot_data, depth - 1, true);
        }
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        
        if (slot_data.mon_placement[0] != -1)
        {
            var _dist = 15;
            var _flip = slot_data.mod_index[6];
            var _scale = ((_flip * 2) - 1) * -1;
            scr_create_sq_effect_pos((sign(_flip) * 77) + (_dist * _scale), -14, 2, 0.5, 60, slot_data.slot_floor, 0, 0);
        }
        
        if (slot_data.mon_placement[1] != -1)
        {
            var _dist = 14;
            var _flip = slot_data.mod_index[6];
            var _scale = ((_flip * 2) - 1) * -1;
            scr_create_sq_effect_pos((sign(_flip) * 77) + (_dist * _scale), -12, 2, 0.5, 60, slot_data.slot_floor, 240, 1);
        }
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end)
    {
        if (slot_data.mon_placement[2] != -1 && irandom_range(0, 100) < 15)
        {
            var _dist = 54;
            var _flip = slot_data.mod_index[6];
            var _scale = ((_flip * 2) - 1) * -1;
            scr_create_sp_drip_pos((sign(_flip) * 77) + (_dist * _scale), -15, slot_data, depth - 1, false);
        }
    }
    
    for (var i = 0; i < slot_data.max_mon_num; i++)
    {
        if (slot_data.mon_placement[i] != -1)
        {
            slot_data.mon_timer[i] += global.w_spd;
            
            if (slot_data.mon_timer[i] >= slot_data.set_timer && floor(slot_data.anim_struct.index) == 1)
            {
                slot_data.h_step++;
                slot_data.anim_struct.ff = true;
                i = slot_data.max_mon_num;
            }
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_gb_1_floop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 11;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.set_timer += 300;
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
        
        unit_data.tired_c = 980;
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        
        if (slot_data.mon_placement[0] != -1)
        {
            var _dist = 15;
            var _flip = slot_data.mod_index[6];
            var _scale = ((_flip * 2) - 1) * -1;
            scr_create_sq_effect_pos((sign(_flip) * 77) + (_dist * _scale), -14, 2, 0.5, 60, slot_data.slot_floor, 0, 0);
        }
        
        if (slot_data.mon_placement[1] != -1)
        {
            var _dist = 14;
            var _flip = slot_data.mod_index[6];
            var _scale = ((_flip * 2) - 1) * -1;
            scr_create_sq_effect_pos((sign(_flip) * 77) + (_dist * _scale), -12, 2, 0.5, 60, slot_data.slot_floor, 240, 1);
        }
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end)
    {
        if (slot_data.mon_placement[2] != -1 && irandom_range(0, 100) < 15)
        {
            var _dist = 54;
            var _flip = slot_data.mod_index[6];
            var _scale = ((_flip * 2) - 1) * -1;
            scr_create_sp_drip_pos((sign(_flip) * 77) + (_dist * _scale), -15, slot_data, depth - 1, false);
        }
    }
    
    var _boot = false;
    
    for (var i = 0; i < slot_data.max_mon_num; i++)
    {
        if (slot_data.mon_placement[i] != -1)
        {
            slot_data.mon_timer[i] += global.w_spd;
            
            if (slot_data.mon_timer[i] >= slot_data.set_timer && floor(slot_data.anim_struct.index) == 1)
            {
                slot_data.h_step++;
                slot_data.anim_struct.ff = true;
                i = slot_data.max_mon_num;
            }
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_gb_1_ej()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.index = 2;
        slot_data.set_timer = irandom_range(30, 60);
        slot_data.h_loop = irandom_range(5, 7);
        scr_play_slap_sfx(2);
        
        if (slot_data.mon_placement[0] != -1)
        {
            var _dist = 15;
            var _flip = slot_data.mod_index[6];
            var _scale = ((_flip * 2) - 1) * -1;
            scr_create_sq_effect_pos((sign(_flip) * 77) + (_dist * _scale), -14, 2, 0.5, 60, slot_data.slot_floor, 0, 0);
        }
        
        if (slot_data.mon_placement[1] != -1)
        {
            var _dist = 14;
            var _flip = slot_data.mod_index[6];
            var _scale = ((_flip * 2) - 1) * -1;
            scr_create_sq_effect_pos((sign(_flip) * 77) + (_dist * _scale), -12, 2, 0.5, 60, slot_data.slot_floor, 240, 1);
        }
        
        scr_play_ej_sfx();
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 5);
    
    switch (floor(slot_data.anim_struct.index))
    {
        case 0:
            slot_data.anim_struct.index = 2;
            break;
        
        case 3:
            slot_data.anim_struct.anim_spd = 0;
            slot_data.set_timer -= global.w_spd;
            
            if (slot_data.set_timer <= 0)
            {
                if (--slot_data.h_loop <= 0)
                {
                    scr_unit_removal(true, false, false, false, -1);
                    scr_check_frog_unit_swap(slot_data.h_type);
                }
                else
                {
                    if (slot_data.h_loop == 1)
                        slot_data.set_timer = irandom_range(120, 180);
                    else
                        slot_data.set_timer = irandom_range(45, 90);
                    
                    slot_data.anim_struct.index = 4;
                    slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                }
            }
            
            break;
    }
    
    scr_mon_frame(slot_data.anim_struct.index);
    scr_slot_call_mon(true);
}

function scr_slot_h_lilith_idle()
{
    candle_index += (global.w_spd * 0.16);
    
    if (candle_index >= 4)
        candle_index -= 4;
}

function scr_slot_h_giant_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        scr_set_slot_spr_part(1);
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
    }
    
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    
    switch (slot_data.anim_struct.sp_state)
    {
        case 0:
            slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
            
            if (slot_data.anim_struct.sp_index >= 3)
            {
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_state = 1;
                    slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                }
            }
            
            break;
        
        case 1:
            slot_data.anim_struct.sp_timer -= global.w_spd;
            
            if (slot_data.anim_struct.sp_timer <= 0)
            {
                slot_data.anim_struct.sp_timer = 0;
                slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 6)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    slot_data.anim_struct.sp_state = 2;
                    
                    if (!slot_data.mod_index[1])
                        scr_create_sp_drip(slot_data, depth - 1, true);
                }
            }
            
            break;
        
        case 2:
            slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
            slot_data.anim_struct.sp_timer -= global.w_spd;
            
            if (slot_data.anim_struct.sp_timer <= 0)
            {
                slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                
                if (!slot_data.mod_index[1])
                    scr_create_sp_drip(slot_data, depth - 1, false);
            }
            
            break;
    }
    
    if (!slot_data.mod_index[1])
        scr_slot_call_mon(true);
}

function scr_slot_h_giant_birth()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(4);
        slot_data.h_wait = 3;
        var _data = 
        {
            mon_type: unit_data.preg,
            class: unit_data.class,
            lvl: unit_data.lvl
        };
        scr_create_prop(id, 40, _data, -1);
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 2);
    
    if (animation_end)
    {
        if (--slot_data.h_wait <= 0)
        {
            slot_data.anim_struct.index = 1;
            slot_data.h_step++;
            slot_data.anim_struct.ff = true;
            slot_data.h_wait = 60;
        }
    }
    
    var _birth_end_index = 6;
    var _index = slot_data.anim_struct.index;
    var _prop_num = array_length(slot_data.prop);
    
    for (var i = 0; i < _prop_num; i++)
    {
        if (slot_data.prop[i].prop_type == 40)
        {
            slot_data.prop[i].prop_id.image_index = _index;
            i = _prop_num;
        }
    }
}

function scr_slot_h_giant_birth_ej()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        unit_data.tired_c = 980;
        slot_data.anim_struct.index = 0;
        unit_data.preg = -1;
        
        if (unit_data.preg_c != -1)
            unit_data.preg_c = max(0, unit_data.preg_c - 1);
        
        _prop_num = array_length(slot_data.prop);
        
        for (var i = 0; i < _prop_num; i++)
        {
            if (slot_data.prop[i].prop_type == 40)
            {
                slot_data.prop[i].prop_id.image_index++;
                i = _prop_num;
            }
        }
    }
    
    var _next = false;
    var _birth_end_index = 6;
    var _prop_num = array_length(slot_data.prop);
    
    for (var i = 0; i < _prop_num; i++)
    {
        if (slot_data.prop[i].prop_type == 40)
        {
            with (slot_data.prop[i].prop_id)
            {
                image_index += (0.13333333333333333 * global.w_spd);
                
                if (image_index >= _birth_end_index)
                {
                    _next = true;
                    scr_mon_birth(prop_data.mon_data, slot_id);
                    
                    with (slot_id)
                    {
                        var _num = array_length(slot_data.prop);
                        
                        for (i = 0; i < _num; i++)
                        {
                            if (slot_data.prop[i].prop_type == 40)
                                array_delete(slot_data.prop, i, 1);
                        }
                    }
                    
                    instance_destroy();
                }
            }
            
            i = _prop_num;
        }
    }
    
    if (_next)
    {
        slot_data.h_step = 0;
        slot_data.h_wait = 0;
        slot_data.h_loop = 0;
        slot_data.anim_struct.char_state = 0;
        slot_data.anim_struct.ff = true;
        slot_data.h_wait = irandom_range(240, 360);
        scr_check_frog_unit_swap(slot_data.h_type);
    }
}

function scr_slot_h_gb_2_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        scr_set_slot_spr_part(1);
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
    }
    
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    
    for (var i = 0; i < array_length(slot_data.sp_place); i++)
    {
        var _pos = slot_data.sp_place[i];
        
        switch (slot_data.anim_struct.sp_state)
        {
            case 0:
                slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 3)
                {
                    slot_data.anim_struct.sp_timer -= global.w_spd;
                    
                    if (slot_data.anim_struct.sp_timer <= 0)
                    {
                        slot_data.anim_struct.sp_state = 1;
                        slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                    }
                }
                
                break;
            
            case 1:
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = 0;
                    slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                    
                    if (slot_data.anim_struct.sp_index >= 6)
                    {
                        slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                        slot_data.anim_struct.sp_state = 2;
                        scr_create_sp_drip_pos(slot_data.sp_x, slot_data.sp_y[_pos], slot_data, depth - 1, true);
                    }
                }
                
                break;
            
            case 2:
                slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    scr_create_sp_drip_pos(slot_data.sp_x, slot_data.sp_y[_pos], slot_data, depth - 1, false);
                }
                
                break;
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_gb_2_sloop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
        
        slot_data.set_timer = 300;
        
        for (var i = 0; i < array_length(spawn_part); i++)
            spawn_part[i] = true;
        
        spawn_stream = true;
        
        if (slot_data.anim_struct.sp_state != -1 && floor(slot_data.anim_struct.sp_index) != 7)
        {
            slot_data.anim_struct.sp_index = 0;
            slot_data.anim_struct.sp_timer = 0;
            scr_create_sp_drip(slot_data, depth - 1, true);
        }
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        
        if (slot_data.mon_placement[0] != -1)
            scr_create_sq_effect_pos(slot_data.sq_x, slot_data.sq_y[0], 2, 0.5, 60, slot_data.slot_floor, 90, 0);
        
        if (slot_data.mon_placement[1] != -1)
            scr_create_sq_effect_pos(slot_data.sq_x, slot_data.sq_y[1], 2, 0.5, 60, slot_data.slot_floor, 270, 1);
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    for (var i = 0; i < slot_data.max_mon_num; i++)
    {
        if (slot_data.mon_placement[i] != -1)
        {
            slot_data.mon_timer[i] += global.w_spd;
            
            if (slot_data.mon_timer[i] >= slot_data.set_timer && floor(slot_data.anim_struct.index) == 1)
            {
                slot_data.h_step++;
                slot_data.anim_struct.ff = true;
                i = slot_data.max_mon_num;
            }
        }
    }
    
    for (var i = 0; i < array_length(slot_data.sp_place); i++)
    {
        var _pos = slot_data.sp_place[i];
        
        switch (slot_data.anim_struct.sp_state)
        {
            case 0:
                slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 3)
                {
                    slot_data.anim_struct.sp_timer -= global.w_spd;
                    
                    if (slot_data.anim_struct.sp_timer <= 0)
                    {
                        slot_data.anim_struct.sp_state = 1;
                        slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                    }
                }
                
                break;
            
            case 1:
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = 0;
                    slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                    slot_data.anim_struct.sp_state = 2;
                    
                    if (slot_data.anim_struct.sp_index >= 6)
                    {
                        slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                        scr_create_sp_drip_pos(slot_data.sp_x, slot_data.sp_y[_pos], slot_data, depth - 1, true);
                    }
                }
                
                break;
            
            case 2:
                slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    scr_create_sp_drip_pos(slot_data.sp_x, slot_data.sp_y[_pos], slot_data, depth - 1, false);
                }
                
                break;
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_gb_2_floop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 11;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.set_timer += 300;
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
        
        unit_data.tired_c = 980;
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        
        if (slot_data.mon_placement[0] != -1)
            scr_create_sq_effect_pos(slot_data.sq_x, slot_data.sq_y[0], 2, 0.5, 60, slot_data.slot_floor, 90, 0);
        
        if (slot_data.mon_placement[1] != -1)
            scr_create_sq_effect_pos(slot_data.sq_x, slot_data.sq_y[1], 2, 0.5, 60, slot_data.slot_floor, 270, 1);
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end)
    {
    }
    
    var _boot = false;
    
    for (var i = 0; i < slot_data.max_mon_num; i++)
    {
        if (slot_data.mon_placement[i] != -1)
        {
            slot_data.mon_timer[i] += global.w_spd;
            
            if (slot_data.mon_timer[i] >= slot_data.set_timer && floor(slot_data.anim_struct.index) == 1)
            {
                slot_data.h_step++;
                slot_data.anim_struct.ff = true;
                i = slot_data.max_mon_num;
            }
        }
    }
    
    for (var i = 0; i < array_length(slot_data.sp_place); i++)
    {
        var _pos = slot_data.sp_place[i];
        
        switch (slot_data.anim_struct.sp_state)
        {
            case 0:
                slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 3)
                {
                    slot_data.anim_struct.sp_timer -= global.w_spd;
                    
                    if (slot_data.anim_struct.sp_timer <= 0)
                    {
                        slot_data.anim_struct.sp_state = 1;
                        slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                    }
                }
                
                break;
            
            case 1:
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = 0;
                    slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                    slot_data.anim_struct.sp_state = 2;
                    
                    if (slot_data.anim_struct.sp_index >= 6)
                    {
                        slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                        scr_create_sp_drip_pos(slot_data.sp_x, slot_data.sp_y[_pos], slot_data, depth - 1, true);
                    }
                }
                
                break;
            
            case 2:
                slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    scr_create_sp_drip_pos(slot_data.sp_x, slot_data.sp_y[_pos], slot_data, depth - 1, false);
                }
                
                break;
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_gb_2_ej()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.index = 2;
        slot_data.set_timer = irandom_range(30, 60);
        slot_data.h_loop = irandom_range(5, 7);
        scr_play_slap_sfx(2);
        
        if (slot_data.mon_placement[0] != -1)
            scr_create_sq_effect_pos(38.5, -13, 2, 0.5, 60, slot_data.slot_floor, 270, 0);
        
        if (slot_data.mon_placement[1] != -1)
            scr_create_sq_effect_pos(38.5, -16, 2, 0.5, 60, slot_data.slot_floor, 270, 1);
        
        scr_play_ej_sfx();
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 5);
    
    switch (floor(slot_data.anim_struct.index))
    {
        case 0:
            slot_data.anim_struct.index = 2;
            break;
        
        case 3:
            slot_data.anim_struct.anim_spd = 0;
            slot_data.set_timer -= global.w_spd;
            
            if (slot_data.set_timer <= 0)
            {
                if (--slot_data.h_loop <= 0)
                {
                    scr_unit_removal(true, false, false, false, -1);
                    scr_check_frog_unit_swap(slot_data.h_type);
                }
                else
                {
                    if (slot_data.h_loop == 1)
                        slot_data.set_timer = irandom_range(120, 180);
                    else
                        slot_data.set_timer = irandom_range(45, 90);
                    
                    slot_data.anim_struct.index = 4;
                    slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                }
            }
            
            break;
    }
    
    scr_mon_frame(slot_data.anim_struct.index);
    
    for (var i = 0; i < array_length(slot_data.sp_place); i++)
    {
        var _pos = slot_data.sp_place[i];
        
        switch (slot_data.anim_struct.sp_state)
        {
            case 0:
                slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 3)
                {
                    slot_data.anim_struct.sp_timer -= global.w_spd;
                    
                    if (slot_data.anim_struct.sp_timer <= 0)
                    {
                        slot_data.anim_struct.sp_state = 1;
                        slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                    }
                }
                
                break;
            
            case 1:
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = 0;
                    slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                    slot_data.anim_struct.sp_state = 2;
                    
                    if (slot_data.anim_struct.sp_index >= 6)
                    {
                        slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                        scr_create_sp_drip_pos(slot_data.sp_x, slot_data.sp_y[_pos], slot_data, depth - 1, true);
                    }
                }
                
                break;
            
            case 2:
                slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    scr_create_sp_drip_pos(slot_data.sp_x, slot_data.sp_y[_pos], slot_data, depth - 1, false);
                }
                
                break;
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_gb_3_sloop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
        
        slot_data.set_timer = 300;
        
        for (var i = 0; i < array_length(spawn_part); i++)
            spawn_part[i] = true;
        
        spawn_stream = true;
        
        if (slot_data.anim_struct.sp_state != -1 && floor(slot_data.anim_struct.sp_index) != 7)
        {
            slot_data.anim_struct.sp_index = 0;
            slot_data.anim_struct.sp_timer = 0;
            slot_data.anim_struct.sp_state = -1;
            scr_create_sp_drip(slot_data, depth - 1, true);
        }
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        scr_create_sq_effect_pos(38.5, -18, 2, 0.5, 60, slot_data.slot_floor, 270, 0);
        
        if (slot_data.mon_placement[1] != -1)
            scr_create_sq_effect_pos(38.5, -25, 2, 0.5, 60, slot_data.slot_floor, 270, 1);
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    for (var i = 0; i < slot_data.max_mon_num; i++)
    {
        if (slot_data.mon_placement[i] != -1)
        {
            slot_data.mon_timer[i] += global.w_spd;
            
            if (slot_data.mon_timer[i] >= slot_data.set_timer && floor(slot_data.anim_struct.index) == 1)
            {
                slot_data.h_step++;
                slot_data.anim_struct.ff = true;
                i = slot_data.max_mon_num;
            }
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_gb_3_floop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 11;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.set_timer += 300;
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
        
        unit_data.tired_c = 980;
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        scr_create_sq_effect_pos(38.5, -18, 2, 0.5, 60, slot_data.slot_floor, 270, 0);
        
        if (slot_data.mon_placement[1] != -1)
            scr_create_sq_effect_pos(38.5, -25, 2, 0.5, 60, slot_data.slot_floor, 270, 1);
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end)
    {
    }
    
    var _boot = false;
    
    for (var i = 0; i < slot_data.max_mon_num; i++)
    {
        if (slot_data.mon_placement[i] != -1)
        {
            slot_data.mon_timer[i] += global.w_spd;
            
            if (slot_data.mon_timer[i] >= slot_data.set_timer && floor(slot_data.anim_struct.index) == 1)
            {
                slot_data.h_step++;
                slot_data.anim_struct.ff = true;
                i = slot_data.max_mon_num;
            }
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_gb_3_ej()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.index = 2;
        slot_data.set_timer = irandom_range(30, 60);
        slot_data.h_loop = irandom_range(5, 7);
        scr_play_slap_sfx(2);
        scr_create_sq_effect_pos(38.5, -18, 2, 0.5, 60, slot_data.slot_floor, 270, 0);
        
        if (slot_data.mon_placement[1] != -1)
            scr_create_sq_effect_pos(38.5, -25, 2, 0.5, 60, slot_data.slot_floor, 270, 1);
        
        scr_play_ej_sfx();
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 5);
    
    switch (floor(slot_data.anim_struct.index))
    {
        case 0:
            slot_data.anim_struct.index = 2;
            break;
        
        case 3:
            slot_data.anim_struct.anim_spd = 0;
            slot_data.set_timer -= global.w_spd;
            
            if (slot_data.set_timer <= 0)
            {
                if (--slot_data.h_loop <= 0)
                {
                    scr_unit_removal(true, false, false, false, -1);
                    scr_check_frog_unit_swap(slot_data.h_type);
                }
                else
                {
                    if (slot_data.h_loop == 1)
                        slot_data.set_timer = irandom_range(120, 180);
                    else
                        slot_data.set_timer = irandom_range(45, 90);
                    
                    slot_data.anim_struct.index = 4;
                    slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                }
            }
            
            break;
    }
    
    scr_mon_frame(slot_data.anim_struct.index);
    scr_slot_call_mon(true);
}

function scr_slot_h_r_shrine_idle()
{
    slot_data.h_wait += global.w_spd;
    
    if (slot_data.h_wait >= 3000)
    {
        slot_data.h_wait = 0;
        var _food = 0;
        _food = (global.val.add_range + 1) * 3;
        global.val.food += _food;
        scr_icon_pop_up_create(x + (image_xscale * 0.5), y - 50, _food, 4, false);
    }
}

function scr_slot_h_clone_idle()
{
    if (slot_data.anim_struct.ff)
        slot_data.anim_struct.ff = false;
    
    slot_data.clone_wait -= global.w_spd;
    
    if (slot_data.clone_wait <= 0)
    {
        slot_data.clone_wait = 0;
        scr_create_slot_head(false, id);
    }
}

function scr_slot_h_big_start()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        scr_set_slot_spr_part(0);
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.anim_spd *= 2;
        slot_data.h_loop = choose(2, 3, 4);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
                scr_set_mon_spr_data(mon_data.slot_id, 0);
        }
    }
    
    var _tired_timer = unit_data.tired_c;
    _tired_timer = max(0, _tired_timer - global.w_spd);
    
    if (_tired_timer <= 0)
        slot_data.anim_struct.anim_spd = 1/30;
    
    unit_data.tired_c = _tired_timer;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end && --slot_data.h_loop < 0)
    {
        slot_data.mon_timer[0] = 60;
        slot_data.h_step++;
        slot_data.anim_struct.ff = true;
    }
}

function scr_slot_h_chain_idle()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        scr_set_slot_spr_part(1);
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 2;
        slot_data.anim_struct.spr_spd = 1 * (sign(unit_data.tired_c) + 1);
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
    }
    
    unit_data.tired_c = scr_tired_timer(unit_data.tired_c, 1, 60);
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    
    for (var i = 0; i < array_length(slot_data.sp_place); i++)
    {
        var _pos = slot_data.sp_place[i];
        
        switch (slot_data.anim_struct.sp_state)
        {
            case 0:
                slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 3)
                {
                    slot_data.anim_struct.sp_timer -= global.w_spd;
                    
                    if (slot_data.anim_struct.sp_timer <= 0)
                    {
                        slot_data.anim_struct.sp_state = 1;
                        slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                    }
                }
                
                break;
            
            case 1:
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = 0;
                    slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                    
                    if (slot_data.anim_struct.sp_index >= 6)
                    {
                        slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                        slot_data.anim_struct.sp_state = 2;
                        scr_create_sp_drip_pos(slot_data.sp_x[_pos], slot_data.sp_y[_pos], slot_data, depth - 1, true);
                    }
                }
                
                break;
            
            case 2:
                slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    scr_create_sp_drip_pos(slot_data.sp_x[_pos], slot_data.sp_y[_pos], slot_data, depth - 1, false);
                }
                
                break;
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_chain_sloop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.index = 0;
        slot_data.anim_struct.frame_c = 5;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
        
        slot_data.set_timer = 300;
        
        for (var i = 0; i < array_length(spawn_part); i++)
            spawn_part[i] = true;
        
        spawn_stream = true;
        
        if (slot_data.anim_struct.sp_state != -1 && floor(slot_data.anim_struct.sp_index) != 7)
        {
            slot_data.anim_struct.sp_index = 0;
            slot_data.anim_struct.sp_timer = 0;
        }
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        
        if (slot_data.mon_placement[0] != -1)
            scr_create_sq_effect_pos(slot_data.sq_x[0], slot_data.sq_y[0], 2, 0.5, 60, slot_data.slot_floor, 90, 0);
        
        if (slot_data.mon_placement[1] != -1)
            scr_create_sq_effect_pos(slot_data.sq_x[1], slot_data.sq_y[1], 2, 0.5, 60, slot_data.slot_floor, 270, 1);
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    for (var i = 0; i < slot_data.max_mon_num; i++)
    {
        if (slot_data.mon_placement[i] != -1)
        {
            slot_data.mon_timer[i] += global.w_spd;
            
            if (slot_data.mon_timer[i] >= slot_data.set_timer && floor(slot_data.anim_struct.index) == 1)
            {
                slot_data.h_step++;
                slot_data.anim_struct.ff = true;
                i = slot_data.max_mon_num;
            }
        }
    }
    
    for (var i = 0; i < array_length(slot_data.sp_place); i++)
    {
        var _pos = slot_data.sp_place[i];
        
        switch (slot_data.anim_struct.sp_state)
        {
            case 0:
                slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 3)
                {
                    slot_data.anim_struct.sp_timer -= global.w_spd;
                    
                    if (slot_data.anim_struct.sp_timer <= 0)
                    {
                        slot_data.anim_struct.sp_state = 1;
                        slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                    }
                }
                
                break;
            
            case 1:
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = 0;
                    slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                    slot_data.anim_struct.sp_state = 2;
                    
                    if (slot_data.anim_struct.sp_index >= 6)
                    {
                        slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                        scr_create_sp_drip_pos(slot_data.sp_x[_pos], slot_data.sp_y[_pos], slot_data, depth - 1, true);
                    }
                }
                
                break;
            
            case 2:
                slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    scr_create_sp_drip_pos(slot_data.sp_x[_pos], slot_data.sp_y[_pos], slot_data, depth - 1, false);
                }
                
                break;
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_chain_floop()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 11;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.set_timer += 300;
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
        
        unit_data.tired_c = 980;
    }
    
    var _old_index = slot_data.anim_struct.index;
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    
    if (floor(_old_index) != floor(slot_data.anim_struct.index))
    {
        scr_play_slap_sfx(2);
        
        if (slot_data.mon_placement[0] != -1)
            scr_create_sq_effect_pos(slot_data.sq_x[0], slot_data.sq_y[0], 2, 0.5, 60, slot_data.slot_floor, 90, 0);
        
        if (slot_data.mon_placement[1] != -1)
            scr_create_sq_effect_pos(slot_data.sq_x[1], slot_data.sq_y[1], 2, 0.5, 60, slot_data.slot_floor, 270, 1);
    }
    
    scr_animation_end(true, slot_data.anim_struct.frame_c);
    scr_mon_frame(slot_data.anim_struct.index);
    
    if (animation_end)
    {
    }
    
    var _boot = false;
    
    for (var i = 0; i < slot_data.max_mon_num; i++)
    {
        if (slot_data.mon_placement[i] != -1)
        {
            slot_data.mon_timer[i] += global.w_spd;
            
            if (slot_data.mon_timer[i] >= slot_data.set_timer && floor(slot_data.anim_struct.index) == 1)
            {
                slot_data.h_step++;
                slot_data.anim_struct.ff = true;
                i = slot_data.max_mon_num;
            }
        }
    }
    
    for (var i = 0; i < array_length(slot_data.sp_place); i++)
    {
        var _pos = slot_data.sp_place[i];
        
        switch (slot_data.anim_struct.sp_state)
        {
            case 0:
                slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 3)
                {
                    slot_data.anim_struct.sp_timer -= global.w_spd;
                    
                    if (slot_data.anim_struct.sp_timer <= 0)
                    {
                        slot_data.anim_struct.sp_state = 1;
                        slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                    }
                }
                
                break;
            
            case 1:
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = 0;
                    slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                    slot_data.anim_struct.sp_state = 2;
                    
                    if (slot_data.anim_struct.sp_index >= 6)
                    {
                        slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                        scr_create_sp_drip_pos(slot_data.sp_x[_pos], slot_data.sp_y[_pos], slot_data, depth - 1, true);
                    }
                }
                
                break;
            
            case 2:
                slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    scr_create_sp_drip_pos(slot_data.sp_x[_pos], slot_data.sp_y[_pos], slot_data, depth - 1, false);
                }
                
                break;
        }
    }
    
    scr_slot_call_mon(true);
}

function scr_slot_h_chain_ej()
{
    if (slot_data.anim_struct.ff)
    {
        slot_data.anim_struct.ff = false;
        slot_data.anim_struct.spr_spd = 9;
        slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
        slot_data.anim_struct.index = 2;
        slot_data.set_timer = irandom_range(30, 60);
        slot_data.h_loop = irandom_range(5, 7);
        scr_play_slap_sfx(2);
        
        if (slot_data.mon_placement[0] != -1)
            scr_create_sq_effect_pos(38.5, -13, 2, 0.5, 60, slot_data.slot_floor, 270, 0);
        
        if (slot_data.mon_placement[1] != -1)
            scr_create_sq_effect_pos(38.5, -16, 2, 0.5, 60, slot_data.slot_floor, 270, 1);
        
        scr_play_ej_sfx();
        scr_set_slot_spr_part(2);
        var _num = array_length(h_unit_list);
        
        for (var i = 0; i < _num; i++)
        {
            with (h_unit_list[i])
            {
                if (mon_data.mon_state == 1)
                    scr_set_mon_spr_data(mon_data.slot_id, 2);
            }
        }
    }
    
    slot_data.anim_struct.index += slot_data.anim_struct.anim_spd * global.w_spd;
    scr_animation_end(false, 5);
    
    switch (floor(slot_data.anim_struct.index))
    {
        case 0:
            slot_data.anim_struct.index = 2;
            break;
        
        case 3:
            slot_data.anim_struct.anim_spd = 0;
            slot_data.set_timer -= global.w_spd;
            
            if (slot_data.set_timer <= 0)
            {
                if (--slot_data.h_loop <= 0)
                {
                    scr_unit_removal(true, false, false, false, -1);
                    scr_check_frog_unit_swap(slot_data.h_type);
                }
                else
                {
                    if (slot_data.h_loop == 1)
                        slot_data.set_timer = irandom_range(120, 180);
                    else
                        slot_data.set_timer = irandom_range(45, 90);
                    
                    slot_data.anim_struct.index = 4;
                    slot_data.anim_struct.anim_spd = slot_data.anim_struct.spr_spd / 60;
                }
            }
            
            break;
    }
    
    scr_mon_frame(slot_data.anim_struct.index);
    
    for (var i = 0; i < array_length(slot_data.sp_place); i++)
    {
        var _pos = slot_data.sp_place[i];
        
        switch (slot_data.anim_struct.sp_state)
        {
            case 0:
                slot_data.anim_struct.sp_index = min(3, slot_data.anim_struct.sp_index + (0.08333333333333333 * global.w_spd));
                
                if (slot_data.anim_struct.sp_index >= 3)
                {
                    slot_data.anim_struct.sp_timer -= global.w_spd;
                    
                    if (slot_data.anim_struct.sp_timer <= 0)
                    {
                        slot_data.anim_struct.sp_state = 1;
                        slot_data.anim_struct.sp_timer = irandom_range(20, 40);
                    }
                }
                
                break;
            
            case 1:
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = 0;
                    slot_data.anim_struct.sp_index = min(6, slot_data.anim_struct.sp_index + (0.13333333333333333 * global.w_spd));
                    slot_data.anim_struct.sp_state = 2;
                    
                    if (slot_data.anim_struct.sp_index >= 6)
                    {
                        slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                        scr_create_sp_drip_pos(slot_data.sp_x[_pos], slot_data.sp_y[_pos], slot_data, depth - 1, true);
                    }
                }
                
                break;
            
            case 2:
                slot_data.anim_struct.sp_index = min(8, slot_data.anim_struct.sp_index + (0.16666666666666666 * global.w_spd));
                slot_data.anim_struct.sp_timer -= global.w_spd;
                
                if (slot_data.anim_struct.sp_timer <= 0)
                {
                    slot_data.anim_struct.sp_timer = irandom_range(120, 360);
                    scr_create_sp_drip_pos(slot_data.sp_x[_pos], slot_data.sp_y[_pos], slot_data, depth - 1, false);
                }
                
                break;
        }
    }
    
    scr_slot_call_mon(true);
}

