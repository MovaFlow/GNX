// GNX: full replacement of s_sfx.gml
// Vanilla functions preserved verbatim. GNX adds 6 positional audio playback functions
// gated behind global.gnx_has_sounds. When no mod provides sounds.json, playback functions
// either no-op (moan/orgasm) or play vanilla sounds only (slap/tent/ej/milk).

function scr_play_moan_sfx()
{
    if (!global.gnx_has_sounds) exit;
    var _ud = unit_data;
    if (!is_struct(_ud)) exit;
    scr_gnx_check_voice(_ud);  // lazily assign voice for units from pre-sound saves
    if (!variable_struct_exists(_ud, "moan_voice") || _ud.moan_voice == -1) exit;

    var _diceroll = irandom(99) + 1;
    var _sfx = -1;
    var _pitch = _ud.moan_pitch;
    var _vol = 0;
    var _size = obj_camera.zoom_num;

    if (scr_gnx_is_bj_cell(slot_data))
    {
        // BJ cells: slurp/gag or bj_moan
        var _frq = min(global.val.moan_frq, 10);
        if (_diceroll > _frq)
        {
            // slurp/gag at bj_vol
            var _pool_len = array_length(global.gnx_sfx_bj_slurp) + array_length(global.gnx_sfx_bj_gag);
            if (_pool_len == 0) exit;
            var _pick = irandom(_pool_len - 1);
            if (_pick < array_length(global.gnx_sfx_bj_slurp))
                _sfx = global.gnx_sfx_bj_slurp[_pick];
            else
                _sfx = global.gnx_sfx_bj_gag[_pick - array_length(global.gnx_sfx_bj_slurp)];
            _vol = ((global.val.bj_vol * global.muffle) / (_size * _size)) * 0.1;
        }
        else
        {
            // bj moan at moan_vol
            if (array_length(global.gnx_sfx_bj_moan) == 0) exit;
            _sfx = global.gnx_sfx_bj_moan[irandom(array_length(global.gnx_sfx_bj_moan) - 1)];
            _vol = ((global.val.moan_vol * global.muffle) / (_size * _size)) * 0.1;
        }
    }
    else
    {
        // Normal cells: voice bank roll
        if (_diceroll > global.val.moan_frq) exit;
        var _bank_name = _ud.moan_voice;
        var _bank = ds_map_find_value(global.gnx_voice_banks, _bank_name);
        if (!is_array(_bank) || array_length(_bank) == 0) exit;
        _sfx = _bank[irandom(array_length(_bank) - 1)];
        _vol = ((global.val.moan_vol * global.muffle) / (_size * _size)) * 0.1;
    }

    if (_sfx == -1) exit;
    var _x = floor(x + 22.5);
    var _y = y - 24;
    slot_sfx = audio_play_sound_at(_sfx, _x, _y, 0, 220 * _size, 300 * _size, 10 * _size, false, 1, _vol, random(0.1), _pitch);
}

function scr_play_orgasm_sfx()
{
    if (!global.gnx_has_sounds) exit;
    var _ud = unit_data;
    if (!is_struct(_ud)) exit;
    scr_gnx_check_voice(_ud);  // lazily assign voice for units from pre-sound saves
    if (!variable_struct_exists(_ud, "moan_pitch")) exit;

    var _diceroll = irandom(99) + 1;
    if (_diceroll > global.val.orgasm_frq) exit;

    var _sfx = -1;
    var _pitch = _ud.moan_pitch;
    var _size = obj_camera.zoom_num;

    if (scr_gnx_is_bj_cell(slot_data))
    {
        if (array_length(global.gnx_sfx_bj_breathe) == 0) exit;
        _sfx = global.gnx_sfx_bj_breathe[irandom(array_length(global.gnx_sfx_bj_breathe) - 1)];
        _pitch = clamp(_pitch, 0.95, 1.05);
    }
    else
    {
        if (array_length(global.gnx_sfx_orgasm) == 0) exit;
        _sfx = global.gnx_sfx_orgasm[irandom(array_length(global.gnx_sfx_orgasm) - 1)];
        _pitch += 0.05;
    }

    if (_sfx == -1) exit;
    var _vol = ((global.val.moan_vol * global.muffle) / (_size * _size)) * 0.1;
    var _x = floor(x + 22.5);
    var _y = y - 24;
    slot_sfx = audio_play_sound_at(_sfx, _x, _y, 0, 220 * _size, 300 * _size, 10 * _size, false, 1, _vol, 0, _pitch);
}

function scr_play_slap_sfx(arg0)
{
    if (floor(slot_data.anim_struct.index) == arg0)
    {
        scr_play_moan_sfx();
        var _sfx = choose(snd_slap_1, snd_slap_2, snd_slap_3);
        var _pitch = random_range(0.8, 1);
        var _size = obj_camera.zoom_num;
        var _vol_setting = global.gnx_has_sounds ? global.val.plap_vol : global.val.sfx_vol;
        var _vol = ((_vol_setting * global.muffle) / (_size * _size)) * 0.1;
        var _x = floor(x + 22.5);
        var _y = y - 24;
        slot_sfx = audio_play_sound_at(_sfx, _x, _y, 0, 220 * _size, 300 * _size, 10 * _size, false, 1, _vol, 0, _pitch);
    }
}

function scr_play_get_coin_sfx(arg0, arg1)
{
    var _size = obj_camera.zoom_num;
    var _vol = ((global.val.sfx_vol * global.muffle) / (_size * _size)) * 0.1;
    audio_play_sound_at(snd_get_coin, arg0, arg1, 0, 220 * _size, 300 * _size, 10 * _size, false, 1, _vol);
}

function scr_play_tent_sfx(arg0)
{
    if (floor(slot_data.anim_struct.index) == arg0)
    {
        scr_play_moan_sfx();
        var _sfx = choose(snd_slap_1, snd_slap_2, snd_slap_3);
        var _pitch = random_range(0.8, 1);
        var _size = obj_camera.zoom_num;
        var _vol_setting = global.gnx_has_sounds ? global.val.plap_vol : global.val.sfx_vol;
        var _vol = ((_vol_setting * global.muffle) / (_size * _size)) * 0.1;
        var _x = floor(x + 22.5);
        var _y = y - 24;
        slot_sfx = audio_play_sound_at(_sfx, _x, _y, 0, 220 * _size, 300 * _size, 10 * _size, false, 1, _vol, 0, _pitch);
    }
}

function scr_play_ej_sfx()
{
    scr_play_orgasm_sfx();
    var _sfx = choose(snd_ej_1, snd_ej_2);
    var _pitch = random_range(0.8, 1);
    var _size = obj_camera.zoom_num;
    var _vol_setting = global.gnx_has_sounds ? global.val.ej_vol : global.val.sfx_vol;
    var _vol = ((_vol_setting * global.muffle) / (_size * _size)) * 0.2;
    var _x = x + 22;
    var _y = y - 24;
    slot_sfx = audio_play_sound_at(_sfx, _x, _y, 0, 220 * _size, 300 * _size, 10 * _size, false, 1, _vol, 0, _pitch);
}

function scr_play_milk_sfx()
{
    var _sfx = choose(snd_milk_sfx_1);
    var _pitch = random_range(0.8, 1);
    var _size = obj_camera.zoom_num;
    var _vol = ((global.val.sfx_vol * global.muffle) / (_size * _size)) * 0.1;
    var _x = x + 22;
    var _y = y - 24;
    slot_sfx = audio_play_sound_at(_sfx, _x, _y, 0, 220 * _size, 300 * _size, 10 * _size, false, 1, _vol);
}

function scr_sfx_play(arg0)
{
    var _sfx = -1;
    switch (arg0)
    {
        case UnknownEnum.Value_0:
            _sfx = snd_click;
            break;
        case UnknownEnum.Value_1:
            _sfx = snd_fail_click;
            break;
        case UnknownEnum.Value_18:
            _sfx = choose(snd_click_1, snd_click_2);
            break;
        case UnknownEnum.Value_2:
            _sfx = choose(snd_click_1, snd_click_2);
            break;
        case UnknownEnum.Value_3:
            _sfx = snd_mail_click;
            break;
        case UnknownEnum.Value_4:
            _sfx = choose(snd_build_1, snd_build_2, snd_build_3);
            break;
        case UnknownEnum.Value_5:
            _sfx = choose(snd_coin_1, snd_coin_2);
            break;
        case UnknownEnum.Value_6:
            _sfx = snd_get_coin;
            break;
        case UnknownEnum.Value_8:
            _sfx = snd_trade_ration;
            break;
        case UnknownEnum.Value_7:
            _sfx = choose(snd_upgrade_1, snd_upgrade_2);
            break;
        case UnknownEnum.Value_12:
            _sfx = choose(snd_mod_1, snd_mod_2);
            break;
        case UnknownEnum.Value_13:
            _sfx = choose(snd_mod_cloth_1, snd_mod_cloth_2);
            break;
        case UnknownEnum.Value_14:
            _sfx = snd_demolish_1;
            break;
        case UnknownEnum.Value_11:
            _sfx = snd_button_fall;
            break;
        case UnknownEnum.Value_15:
            _sfx = snd_click;
            break;
        case UnknownEnum.Value_16:
            _sfx = snd_raid;
            break;
        case UnknownEnum.Value_17:
            _sfx = snd_button_fall;
            break;
        case UnknownEnum.Value_20:
            _sfx = choose(snd_unit_ins_1, snd_unit_ins_2);
            break;
        case UnknownEnum.Value_9:
            _sfx = snd_drink;
            break;
        case UnknownEnum.Value_21:
            _sfx = snd_save_write;
            break;
        case UnknownEnum.Value_22:
            _sfx = snd_save_trash;
            break;
        case UnknownEnum.Value_24:
            _sfx = snd_trade;
            break;
        case UnknownEnum.Value_23:
            _sfx = snd_shop;
            break;
    }
    if (_sfx != -1)
    {
        audio_play_sound(_sfx, 1, 0, global.val.sfx_vol);
    }
}

function scr_sfx_button_play()
{
    switch (interact_type)
    {
        case UnknownEnum.Value_0:
            scr_sfx_play(UnknownEnum.Value_18);
            break;
        case UnknownEnum.Value_1:
            scr_sfx_play(UnknownEnum.Value_5);
            scr_sfx_play(UnknownEnum.Value_4);
            break;
        case UnknownEnum.Value_2:
            scr_sfx_play(UnknownEnum.Value_18);
            break;
        case UnknownEnum.Value_19:
            scr_sfx_play(UnknownEnum.Value_2);
            break;
        case UnknownEnum.Value_34:
            scr_sfx_play(UnknownEnum.Value_2);
            break;
        case UnknownEnum.Value_3:
            scr_sfx_play(UnknownEnum.Value_18);
            break;
        case UnknownEnum.Value_4:
            scr_sfx_play(UnknownEnum.Value_18);
            break;
        case UnknownEnum.Value_5:
            scr_sfx_play(UnknownEnum.Value_18);
            break;
        case UnknownEnum.Value_10:
            scr_sfx_play(UnknownEnum.Value_5);
            scr_sfx_play(UnknownEnum.Value_4);
            break;
        case UnknownEnum.Value_12:
            scr_sfx_play(UnknownEnum.Value_5);
            scr_sfx_play(UnknownEnum.Value_4);
            break;
        case UnknownEnum.Value_11:
            scr_sfx_play(UnknownEnum.Value_5);
            scr_sfx_play(UnknownEnum.Value_4);
            break;
        case UnknownEnum.Value_13:
            scr_sfx_play(UnknownEnum.Value_5);
            scr_sfx_play(UnknownEnum.Value_4);
            break;
        case UnknownEnum.Value_14:
            scr_sfx_play(UnknownEnum.Value_5);
            scr_sfx_play(UnknownEnum.Value_4);
            break;
        case UnknownEnum.Value_15:
            scr_sfx_play(UnknownEnum.Value_5);
            scr_sfx_play(UnknownEnum.Value_4);
            break;
        case UnknownEnum.Value_16:
            scr_sfx_play(UnknownEnum.Value_5);
            scr_sfx_play(UnknownEnum.Value_4);
            break;
        case UnknownEnum.Value_17:
            scr_sfx_play(UnknownEnum.Value_5);
            scr_sfx_play(UnknownEnum.Value_4);
            break;
        case UnknownEnum.Value_26:
            scr_sfx_play(UnknownEnum.Value_12);
            break;
        case UnknownEnum.Value_27:
            scr_sfx_play(UnknownEnum.Value_13);
            break;
        case UnknownEnum.Value_36:
            scr_sfx_play(UnknownEnum.Value_14);
            break;
        case UnknownEnum.Value_37:
            scr_sfx_play(UnknownEnum.Value_1);
            break;
        case UnknownEnum.Value_31:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_38:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_63:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_62:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_32:
            switch (button_num)
            {
                case UnknownEnum.Value_4:
                    scr_sfx_play(UnknownEnum.Value_0);
                    break;
                case UnknownEnum.Value_2:
                    scr_sfx_play(UnknownEnum.Value_0);
                    break;
                case UnknownEnum.Value_3:
                    scr_sfx_play(UnknownEnum.Value_0);
                    break;
                case UnknownEnum.Value_0:
                    scr_sfx_play(UnknownEnum.Value_16);
                    break;
            }
            break;
        case UnknownEnum.Value_33:
            break;
        case UnknownEnum.Value_29:
            scr_sfx_play(UnknownEnum.Value_18);
            break;
        case UnknownEnum.Value_41:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_43:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_44:
            scr_sfx_play(UnknownEnum.Value_0);
            scr_sfx_play(UnknownEnum.Value_24);
            break;
        case UnknownEnum.Value_59:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_45:
            scr_sfx_play(UnknownEnum.Value_0);
            scr_sfx_play(UnknownEnum.Value_23);
            break;
        case UnknownEnum.Value_39:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_35:
            scr_sfx_play(UnknownEnum.Value_18);
            break;
        case UnknownEnum.Value_30:
            scr_sfx_play(UnknownEnum.Value_18);
            break;
        case UnknownEnum.Value_47:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_51:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_54:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_55:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
        case UnknownEnum.Value_58:
            scr_sfx_play(UnknownEnum.Value_0);
            break;
    }
}

enum UnknownEnum
{
    Value_0,
    Value_1,
    Value_2,
    Value_3,
    Value_4,
    Value_5,
    Value_6,
    Value_7,
    Value_8,
    Value_9,
    Value_10,
    Value_11,
    Value_12,
    Value_13,
    Value_14,
    Value_15,
    Value_16,
    Value_17,
    Value_18,
    Value_19,
    Value_20,
    Value_21,
    Value_22,
    Value_23,
    Value_24,
    Value_26 = 26,
    Value_27,
    Value_29 = 29,
    Value_30,
    Value_31,
    Value_32,
    Value_33,
    Value_34,
    Value_35,
    Value_36,
    Value_37,
    Value_38,
    Value_39,
    Value_41 = 41,
    Value_43 = 43,
    Value_44,
    Value_45,
    Value_47 = 47,
    Value_51 = 51,
    Value_54 = 54,
    Value_55,
    Value_58 = 58,
    Value_59,
    Value_62 = 62,
    Value_63
}
