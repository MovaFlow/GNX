function scr_draw_mon_slot(arg0)
{
    // GNX: skip draw if goblin is off-screen vertically
    var _cam = view_camera[0];
    var _vy = camera_get_view_y(_cam);
    if (y < _vy - 200 || y > _vy + camera_get_view_height(_cam) + 200)
    {
        if (global.gnx_perf_enabled) global.gnx_perf_mons_culled++;
        return;
    }
    if (global.gnx_perf_enabled) global.gnx_perf_mons_drawn++;

    var _mon_spr = mon_spr;
    var _spr_data = mon_data.spr_data;
    
    if (_mon_spr.body_b != -1)
    {
        var _row_type = 0;
        
        if (_spr_data.h_type == 18 || _spr_data.h_type == 19 || _spr_data.h_type == 38)
            _row_type = mon_data.placement_num;
        else
            _row_type = _spr_data.h_type - _spr_data.spr_row_pos - 1;
        
        var _base_frame_c = _spr_data.base_frame_c;
        var _mon_frame_c = _spr_data.mon_frame_c;
        var _mon_index = (_row_type * _base_frame_c) + mon_data.index;
        _mon_index -= _spr_data.start_frame;
        
        if (mon_data.mon_type != 3 || mon_data.slot_id.slot_data.h_type == 39 || mon_data.slot_id.slot_data.h_type == 37)
        {
            var _mon_alpha_c = global.mon_alpha_c[mon_data.mon_type];
            var _x = x;
            var _y = y;
            var _x_flip = abs(sign(image_xscale - 1) * _spr_data.slot_width);
            var _x_hand_flip = abs(sign(_spr_data.hand_xscale - 1) * _spr_data.slot_width);
            
            if (_mon_spr.pen != -1)
                gnx_draw_sprite_ext(_mon_spr.pen, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, 1);
            
            switch (global.val.alpha_type)
            {
                case 0:
                    if (_mon_spr.head_b != -1)
                    {
                        gnx_draw_sprite_ext(_mon_spr.head_b, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                        
                        if (_mon_spr.head_l != -1)
                            gnx_draw_sprite_ext(_mon_spr.head_l, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                    }
                    
                    if (_mon_spr.hand_b != -1)
                    {
                        gnx_draw_sprite_ext(_mon_spr.hand_b, _mon_index, _x + _x_hand_flip, _y, _spr_data.hand_xscale, 1, 0, c_white, global.val.mon_alpha);
                        
                        if (_mon_spr.hand_l != -1)
                            gnx_draw_sprite_ext(_mon_spr.hand_l, _mon_index, _x + _x_hand_flip, _y, _spr_data.hand_xscale, 1, 0, c_white, global.val.mon_alpha);
                    }
                    
                    gnx_draw_sprite_ext(_mon_spr.body_b, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                    
                    if (_mon_spr.body_l != -1)
                        gnx_draw_sprite_ext(_mon_spr.body_l, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                    
                    break;
                
                case 2:
                    gpu_set_fog(true, _mon_alpha_c, 0, 0);
                    
                    if (_mon_spr.head_b != -1)
                    {
                        gnx_draw_sprite_ext(_mon_spr.head_b, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                        
                        if (_mon_spr.head_l != -1)
                            gnx_draw_sprite_ext(_mon_spr.head_l, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                    }
                    
                    if (_mon_spr.hand_b != -1)
                    {
                        gnx_draw_sprite_ext(_mon_spr.hand_b, _mon_index, _x + _x_hand_flip, _y, _spr_data.hand_xscale, 1, 0, c_white, global.val.mon_alpha);
                        
                        if (_mon_spr.hand_l != -1)
                            gnx_draw_sprite_ext(_mon_spr.hand_l, _mon_index, _x + _x_hand_flip, _y, _spr_data.hand_xscale, 1, 0, c_white, global.val.mon_alpha);
                    }
                    
                    gnx_draw_sprite_ext(_mon_spr.body_b, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                    
                    if (_mon_spr.body_l != -1)
                        gnx_draw_sprite_ext(_mon_spr.body_l, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                    
                    gpu_set_fog(false, c_white, 0, 0);
                    break;
                
                case 1:
                    gpu_set_fog(true, _mon_alpha_c, 0, 0);
                    
                    if (_mon_spr.head_b != -1)
                        gnx_draw_sprite_ext(_mon_spr.head_b, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                    
                    if (_mon_spr.hand_b != -1)
                        gnx_draw_sprite_ext(_mon_spr.hand_b, _mon_index, _x + _x_hand_flip, _y, _spr_data.hand_xscale, 1, 0, c_white, global.val.mon_alpha);
                    
                    gnx_draw_sprite_ext(_mon_spr.body_b, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, global.val.mon_alpha);
                    gpu_set_fog(false, c_white, 0, 0);
                    
                    if (_mon_spr.head_b != -1 && _mon_spr.head_l != -1)
                        gnx_draw_sprite_ext(_mon_spr.head_l, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, 1);
                    
                    if (_mon_spr.hand_b != -1 && _mon_spr.hand_l != -1)
                        gnx_draw_sprite_ext(_mon_spr.hand_l, _mon_index, _x + _x_hand_flip, _y, _spr_data.hand_xscale, 1, 0, c_white, 1);
                    
                    if (_mon_spr.body_l != -1)
                        gnx_draw_sprite_ext(_mon_spr.body_l, _mon_index, _x + _x_flip, _y, image_xscale, 1, 0, c_white, 1);
                    
                    break;
            }
            
            if (_mon_spr.prop != -1)
            {
                _x = x + _spr_data.prop_shift_x;
                _y = y + _spr_data.prop_shift_y;
                
                switch (global.val.crate_alpha_type)
                {
                    case 0:
                        gnx_draw_sprite_ext(_mon_spr.prop, mon_data.index, _x + sign(_x_flip), _y, image_xscale, 1, 0, c_white, global.val.crate_alpha);
                        gnx_draw_sprite_ext(_mon_spr.prop_l, mon_data.index, _x + sign(_x_flip), _y, image_xscale, 1, 0, c_white, global.val.crate_alpha);
                        break;
                    
                    case 2:
                        gpu_set_fog(true, _mon_alpha_c, 0, 0);
                        gnx_draw_sprite_ext(_mon_spr.prop, mon_data.index, _x + sign(_x_flip), _y, image_xscale, 1, 0, c_white, global.val.crate_alpha);
                        gnx_draw_sprite_ext(_mon_spr.prop_l, mon_data.index, _x + sign(_x_flip), _y, image_xscale, 1, 0, c_white, global.val.crate_alpha);
                        gpu_set_fog(false, c_white, 0, 0);
                        break;
                    
                    case 1:
                        gpu_set_fog(true, _mon_alpha_c, 0, 0);
                        gnx_draw_sprite_ext(_mon_spr.prop, mon_data.index, _x + sign(_x_flip), _y, image_xscale, 1, 0, c_white, global.val.crate_alpha);
                        gpu_set_fog(false, c_white, 0, 0);
                        gnx_draw_sprite_ext(_mon_spr.prop_l, mon_data.index, _x + sign(_x_flip), _y, image_xscale, 1, 0, c_white, 1);
                        break;
                }
            }
        }
        else
        {
            gnx_draw_sprite_ext(_mon_spr.body_b, _mon_index, x, y, image_xscale, 1, 0, c_white, 1);
        }
        
        if (arg0 && mon_data.slot_id.hover)
            scr_draw_highlight(scr_mon_draw);
    }
    
    if (global.mask_collision)
        draw_sprite_ext(sprite_index, 0, x, y, image_xscale, image_yscale, image_angle, image_blend, 0.5);
}

function scr_draw_hobgoblin_carry(arg0)
{
    var _cam = view_camera[0];
    var _vy = camera_get_view_y(_cam);
    if (y < _vy - 200 || y > _vy + camera_get_view_height(_cam) + 200)
    {
        if (global.gnx_perf_enabled) global.gnx_perf_mons_culled++;
        return;
    }
    if (global.gnx_perf_enabled) global.gnx_perf_mons_drawn++;

    var _shift_y = 0;
    
    switch (floor(image_index))
    {
        case 1:
            _shift_y = 1;
            break;
        
        case 3:
            _shift_y = -1;
            break;
        
        case 5:
            _shift_y = 1;
            break;
        
        case 7:
            _shift_y = -1;
            break;
    }
    
    var _test = image_speed;
    draw_sprite_ext(spr_hobgoblin_log, 0, x, (y - 48) + _shift_y, image_xscale, image_yscale, image_angle, image_blend, 1);
    draw_sprite_ext(spr_carry, image_index, x + 45, y, image_xscale, image_yscale, image_angle, image_blend, 1);
    
    if (mon_data.carry_start_id == -1 && mon_data.carry_end_id != -1)
    {
        var _spr_slot = mon_data.slot_id.spr_slot;
        var _slot_data = mon_data.slot_id.slot_data;
        var _unit_data = mon_data.slot_id.unit_data;
        var _final_index = max(0, _unit_data.skin) * 2;
        var _hair_index = max(0, _unit_data.hair) * 2;
        var _dist = 39;
        var _x = floor(x - (_dist * image_xscale));
        var _num = array_length(_spr_slot);
        
        for (var i = 0; i < _num; i++)
        {
            var _replace = false;
            var _spr = _spr_slot[i][1];
            
            if (_spr != -1)
            {
                var _type = _spr_slot[i][0];
                var _c_spr = _spr_slot[i][3];
                var _index = _slot_data.mod_index[i];
                
                if (_c_spr != -1 && _index == 0)
                    _replace = _spr_slot[i][4];
                
                switch (_type)
                {
                    case 10:
                        if (_index != -1)
                        {
                            gnx_draw_sprite_ext(_c_spr, _final_index, _x, (y - 1) + _shift_y, image_xscale, image_yscale, image_angle, image_blend, 1);
                            var _hair_spr = _spr_slot[i][5];
                            
                            if (_hair_spr != -1)
                                gnx_draw_sprite_ext(_hair_spr, _hair_index, _x, (y - 1) + _shift_y, image_xscale, image_yscale, image_angle, image_blend, 1);
                        }
                        
                        break;
                    
                    case 6:
                        if (_index == 0 && _c_spr != -1)
                            gnx_draw_sprite_ext(_c_spr, _final_index, _x, (y - 1) + _shift_y, image_xscale, image_yscale, image_angle, image_blend, 1);
                        
                        break;
                    
                    case 8:
                        if (_index != -1 && !_replace)
                            gnx_draw_sprite_ext(_spr, _final_index, _x, (y - 1) + _shift_y, image_xscale, image_yscale, image_angle, image_blend, 1);
                        
                        if (_index == 0 && _c_spr != -1)
                            gnx_draw_sprite_ext(_c_spr, _final_index, _x, (y - 1) + _shift_y, image_xscale, image_yscale, image_angle, image_blend, 1);
                        
                        break;
                    
                    case 11:
                        if (_index == 0)
                            gnx_draw_sprite(_spr, _final_index, x, y);
                        
                        break;
                }
            }
        }
    }
    
    draw_sprite_ext(spr_carry, image_index + 4, x - 45, y, image_xscale, image_yscale, image_angle, image_blend, 1);
}

function scr_tent_draw()
{
    var _cam = view_camera[0];
    var _vy = camera_get_view_y(_cam);
    if (y < _vy - 200 || y > _vy + camera_get_view_height(_cam) + 200)
    {
        if (global.gnx_perf_enabled) global.gnx_perf_mons_culled++;
        return;
    }
    if (global.gnx_perf_enabled) global.gnx_perf_mons_drawn++;

    var _row_type = mon_data.h_type - 26 - 1;
    image_index = (_row_type * 5) + mon_data.index;
    draw_sprite(spr_type, image_index, x, y);
}

function scr_draw_orgre_patrol(arg0)
{
    var _cam = view_camera[0];
    var _vy = camera_get_view_y(_cam);
    if (y < _vy - 200 || y > _vy + camera_get_view_height(_cam) + 200)
    {
        if (global.gnx_perf_enabled) global.gnx_perf_mons_culled++;
        return;
    }
    if (global.gnx_perf_enabled) global.gnx_perf_mons_drawn++;

    var _patrol_spr = spr_patrol;
    if (spr_unit != -1 && variable_struct_exists(spr_unit, "patrol_spr") && spr_unit.patrol_spr != -1)
        _patrol_spr = spr_unit.patrol_spr;
    gnx_draw_sprite_ext(_patrol_spr, image_index, x, y, image_xscale, image_yscale, image_angle, image_blend, 1);
    
    if (spr_unit != -1)
    {
        var _skin = spr_unit.skin;
        var _hair = spr_unit.hair;
        var _hair_c = spr_unit.hair_c;
        var _spr_c = 8;
        if (spr_unit.base != -1)
            gnx_draw_sprite_ext(spr_unit.base, image_index + (_spr_c * _skin), x, y, image_xscale, image_yscale, image_angle, image_blend, 1);

        if (spr_unit.head != -1)
            gnx_draw_sprite_ext(spr_unit.head, image_index + (_spr_c * _skin), x, y, image_xscale, image_yscale, image_angle, image_blend, 1);
        
        if (spr_unit.hair != -1)
            gnx_draw_sprite_ext(spr_unit.hair, image_index + (_spr_c * _hair_c), x, y, image_xscale, image_yscale, image_angle, image_blend, 1);
        
        if (spr_unit.hand != -1)
            gnx_draw_sprite_ext(spr_unit.hand, image_index + (_spr_c * _skin), x, y, image_xscale, image_yscale, image_angle, image_blend, 1);
    }
}
